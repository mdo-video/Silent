plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Il numero di build arriva da GitHub (-PbuildNumber=...): cresce a ogni compilazione,
// cosi' l'app capisce quando c'e' una versione piu' nuova.
val buildNumber = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 3

android {
    namespace = "com.mdovideo.silent"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mdovideo.silent"
        minSdk = 26
        targetSdk = 34
        versionCode = buildNumber
        versionName = "2.2"
    }

    // Chiave di firma fissa: serve per poter aggiornare l'app sopra la versione gia' installata
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("silent-key.jks")
            storeType = "jks"
            storePassword = "silent123"
            keyAlias = "silent"
            keyPassword = "silent123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
}
