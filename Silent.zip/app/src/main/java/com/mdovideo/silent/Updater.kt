package com.mdovideo.silent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Aggiornamento dell'app dalle release GitHub (OTA). */
object Updater {
    private const val API = "https://api.github.com/repos/mdo-video/Silent/releases/latest"
    private const val APK_NAME = "Silent.apk"

    class Info(val build: Int, val url: String, val size: Long, val sha256: String?)

    sealed class Result {
        class Newer(val info: Info) : Result()
        object UpToDate : Result()
        class Error(val msg: String) : Result()
    }

    @Suppress("DEPRECATION")
    fun currentBuild(ctx: Context): Int {
        return try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
        } catch (e: Exception) {
            0
        }
    }

    /** Da chiamare fuori dal thread principale. */
    fun check(ctx: Context): Result {
        return try {
            val conn = URL(API).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "Silent-App")
            val code = conn.responseCode
            if (code == 404) return Result.Error("Nessuna release ancora su GitHub")
            if (code != 200) return Result.Error("GitHub ha risposto $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(body)
            val build = j.optString("tag_name").filter { it.isDigit() }.toIntOrNull()
                ?: return Result.Error("Versione non riconosciuta")
            var url: String? = null
            var size = 0L
            var sha: String? = null
            val assets = j.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name") == APK_NAME) {
                        url = a.optString("browser_download_url")
                        size = a.optLong("size")
                        // GitHub pubblica l'hash dell'asset nel campo "digest" (es. "sha256:abc...")
                        sha = a.optString("digest").removePrefix("sha256:").lowercase().takeIf { it.length == 64 }
                    }
                }
            }
            if (url == null) return Result.Error("Nessun APK nella release")
            if (build > currentBuild(ctx)) Result.Newer(Info(build, url, size, sha)) else Result.UpToDate
        } catch (e: Exception) {
            Result.Error(e.message ?: "Errore di rete")
        }
    }

    /** Scarica l'APK nella cache. Da chiamare fuori dal thread principale. */
    fun download(ctx: Context, info: Info, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        val file = File(dir, "Silent.apk")
        if (file.exists()) file.delete()
        val conn = URL(info.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 20000
        conn.setRequestProperty("User-Agent", "Silent-App")
        if (conn.responseCode != 200) throw RuntimeException("Download: risposta ${conn.responseCode}")
        val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else info.size
        var got = 0L
        var lastPct = -1
        conn.inputStream.use { input ->
            file.outputStream().use { out ->
                val buf = ByteArray(32768)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    got += n
                    if (total > 0) {
                        val pct = (got * 100 / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                }
            }
        }
        // Controllo di integrita': se GitHub dichiara l'hash, il file scaricato deve combaciare
        val expected = info.sha256
        if (expected != null) {
            val md = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { ins ->
                val b = ByteArray(65536)
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    md.update(b, 0, n)
                }
            }
            val got = md.digest().joinToString("") { "%02x".format(it) }
            if (got != expected) {
                file.delete()
                throw RuntimeException("controllo SHA-256 non superato, file scartato")
            }
        }
        return file
    }

    /** Apre l'installazione. Ritorna un messaggio se serve un'azione dell'utente, altrimenti null. */
    fun install(ctx: Context, file: File): String? {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Consenti a Silent di installare app, poi tocca di nuovo Aggiorna"
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return null
    }
}
