package com.mdovideo.silent

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("silent", Context.MODE_PRIVATE)

    var threshold: Int
        get() = sp.getInt("threshold", 40)
        set(v) = sp.edit().putInt("threshold", v).apply()

    var delaySec: Int
        get() = sp.getInt("delay", 5)
        set(v) = sp.edit().putInt("delay", v).apply()

    var onlyIfPlaying: Boolean
        get() = sp.getBoolean("onlyIfPlaying", true)
        set(v) = sp.edit().putBoolean("onlyIfPlaying", v).apply()

    var useToggle: Boolean
        get() = sp.getBoolean("useToggle", false)
        set(v) = sp.edit().putBoolean("useToggle", v).apply()
}
