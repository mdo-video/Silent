package com.mdovideo.silent

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("silent", Context.MODE_PRIVATE)

    /** "tablet" = microfono del tablet, "pc" = flusso audio ricevuto dal PC via Wi-Fi. */
    var source: String
        get() = sp.getString("source", "tablet") ?: "tablet"
        set(v) = sp.edit().putString("source", v).apply()

    var threshold: Int
        get() = sp.getInt("threshold", 40)
        set(v) = sp.edit().putInt("threshold", v).apply()

    var delaySec: Int
        get() = sp.getInt("delay", 5)
        set(v) = sp.edit().putInt("delay", v).apply()

    var onlyIfPlaying: Boolean
        get() = sp.getBoolean("onlyIfPlaying", true)
        set(v) = sp.edit().putBoolean("onlyIfPlaying", v).apply()

    var useToggle: Boolean
        get() = sp.getBoolean("useToggle", false)
        set(v) = sp.edit().putBoolean("useToggle", v).apply()

    /** Ascolta solo un microfono esterno (USB o a cavo), mai quello del tablet. */
    var externalOnly: Boolean
        get() = sp.getBoolean("externalOnly", false)
        set(v) = sp.edit().putBoolean("externalOnly", v).apply()

    /** Con il microfono interno impara il volume del tablet e lo ignora. */
    var antiEcho: Boolean
        get() = sp.getBoolean("antiEcho", true)
        set(v) = sp.edit().putBoolean("antiEcho", v).apply()

    /** Sperimentale: cancellazione dell'eco di sistema sul microfono interno. */
    var systemEcho: Boolean
        get() = sp.getBoolean("systemEcho", false)
        set(v) = sp.edit().putBoolean("systemEcho", v).apply()

    /** Durata minima (ms) che un suono deve avere prima di mettere in pausa: ignora i "din" brevi. */
    var minSoundMs: Int
        get() = sp.getInt("minSoundMs", 300)
        set(v) = sp.edit().putInt("minSoundMs", v).apply()

    /** PIN di abbinamento con Silent PC. Vuoto = nessuna protezione. */
    var pin: String
        get() = sp.getString("pin", "") ?: ""
        set(v) = sp.edit().putString("pin", v).apply()

    /** true se l'ascolto era acceso: serve a riprenderlo se Android chiude il servizio. */
    var wasListening: Boolean
        get() = sp.getBoolean("wasListening", false)
        set(v) = sp.edit().putBoolean("wasListening", v).apply()

    /** Notifica giornaliera con il report del tempo di lavoro. */
    var reportEnabled: Boolean
        get() = sp.getBoolean("reportEnabled", true)
        set(v) = sp.edit().putBoolean("reportEnabled", v).apply()

    /** Ora (0-23) in cui arriva il report giornaliero. */
    var reportHour: Int
        get() = sp.getInt("reportHour", 20)
        set(v) = sp.edit().putInt("reportHour", v).apply()
}
