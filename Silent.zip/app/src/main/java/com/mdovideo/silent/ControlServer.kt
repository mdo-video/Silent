package com.mdovideo.silent

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Canale di controllo UDP (porta 5006) con l'app Windows:
 * - manda a tutta la rete un "beacon" ogni 2 s, cosi' il PC trova il tablet senza IP;
 * - manda lo stato (livello, soglia, testo...) a ogni PC collegato;
 * - riceve i comandi: set, start, stop, test_pause, test_play, hello, bye.
 */
class ControlServer(
    private val ctx: Context,
    private val prefs: Prefs,
    private val host: Host
) {
    interface Host {
        fun remoteStart(source: String?)
        fun remoteStop()
        fun remoteTest(pause: Boolean)
    }

    companion object {
        const val PORT = 5006
        private const val PEER_TTL = 8000L
        private const val STATUS_EVERY = 100L
        private const val BEACON_EVERY = 2000L
        private val COMMANDS = setOf("hello", "bye", "set", "start", "stop", "test_pause", "test_play", "get_report")
    }

    private class Peer(val addr: InetAddress, var port: Int, var lastSeen: Long)

    @Volatile private var active = false
    @Volatile private var socket: DatagramSocket? = null
    private var recvThread: Thread? = null
    private var sendThread: Thread? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private val peers = ConcurrentHashMap<String, Peer>()
    private val sendLock = Any()

    fun start() {
        if (active) return
        active = true
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mcLock = wm.createMulticastLock("silent:ctl").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } catch (e: Exception) {
        }
        recvThread = Thread { recvLoop() }.also { it.isDaemon = true; it.start() }
        sendThread = Thread { sendLoop() }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        active = false
        try {
            socket?.close()
        } catch (e: Exception) {
        }
        try {
            mcLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        mcLock = null
        peers.clear()
        SilentState.controlPeers = 0
    }

    private fun recvLoop() {
        val buf = ByteArray(2048)
        while (active) {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(PORT))
                    soTimeout = 500
                }
                socket = s
                val p = DatagramPacket(buf, buf.size)
                while (active) {
                    try {
                        p.length = buf.size
                        s.receive(p)
                        handlePacket(p)
                    } catch (e: SocketTimeoutException) {
                    }
                }
            } catch (e: Exception) {
                if (active) {
                    try {
                        Thread.sleep(1000)
                    } catch (ie: InterruptedException) {
                    }
                }
            } finally {
                socket = null
                try {
                    s?.close()
                } catch (e: Exception) {
                }
            }
        }
    }

    /**
     * true se i pacchetti audio di [addr] sono ammessi: senza PIN tutti, con PIN solo il PC
     * che ha mandato di recente un comando con il PIN giusto.
     */
    fun isAuthorized(addr: InetAddress): Boolean {
        if (prefs.pin.isEmpty()) return true
        val ip = addr.hostAddress ?: return false
        val peer = peers[ip] ?: return false
        return SystemClock.elapsedRealtime() - peer.lastSeen <= PEER_TTL
    }

    private fun handlePacket(p: DatagramPacket) {
        val j = try {
            JSONObject(String(p.data, 0, p.length, Charsets.UTF_8))
        } catch (e: Exception) {
            return
        }
        val cmd = j.optString("cmd")
        if (cmd !in COMMANDS) return  // ignora anche i miei stessi beacon
        val ip = p.address.hostAddress ?: return
        // Con il PIN attivo ogni comando deve portare il PIN giusto, altrimenti viene ignorato
        val pin = prefs.pin
        if (pin.isNotEmpty()) {
            val given = j.optString("pin")
            if (!MessageDigest.isEqual(given.toByteArray(Charsets.UTF_8), pin.toByteArray(Charsets.UTF_8))) return
        }
        val now = SystemClock.elapsedRealtime()
        if (cmd == "bye") {
            peers.remove(ip)
        } else {
            val peer = peers[ip]
            if (peer == null) peers[ip] = Peer(p.address, p.port, now)
            else {
                peer.port = p.port
                peer.lastSeen = now
            }
        }
        SilentState.controlPeers = peers.size
        when (cmd) {
            "set" -> applySettings(j)
            "start" -> host.remoteStart(if (j.has("source")) j.optString("source") else null)
            "stop" -> host.remoteStop()
            "test_pause" -> host.remoteTest(true)
            "test_play" -> host.remoteTest(false)
            "get_report" -> sendReport(p.address, p.port)
        }
    }

    /** Il PC chiede il registro del lavoro (ultimi 30 giorni, in secondi). */
    private fun sendReport(addr: InetAddress, port: Int) {
        val s = socket ?: return
        try {
            WorkLog.init(ctx)
            WorkLog.flush()
            val arr = JSONArray()
            for ((d, w, p) in WorkLog.daysData(30)) {
                arr.put(JSONArray().put(d).put(w).put(p))
            }
            val o = JSONObject()
            o.put("type", "report")
            o.put("name", deviceName())
            o.put("today", WorkLog.today())
            o.put("days", arr)
            val data = o.toString().toByteArray(Charsets.UTF_8)
            send(s, data, addr, port)
        } catch (e: Exception) {
        }
    }

    private fun applySettings(j: JSONObject) {
        try {
            if (j.has("threshold")) prefs.threshold = j.getInt("threshold").coerceIn(0, 100)
            if (j.has("delay")) prefs.delaySec = j.getInt("delay").coerceIn(1, 60)
            if (j.has("minMs")) prefs.minSoundMs = j.getInt("minMs").coerceIn(0, 1000)
            if (j.has("onlyPlaying")) prefs.onlyIfPlaying = j.getBoolean("onlyPlaying")
            if (j.has("toggle")) prefs.useToggle = j.getBoolean("toggle")
        } catch (e: Exception) {
        }
        SilentState.settingsRev++
    }

    private fun sendLoop() {
        var lastBeacon = 0L
        while (active) {
            val s = socket
            if (s != null) {
                val now = SystemClock.elapsedRealtime()
                peers.entries.removeIf { now - it.value.lastSeen > PEER_TTL }
                SilentState.controlPeers = peers.size
                if (peers.isNotEmpty()) {
                    val data = statusJson().toByteArray(Charsets.UTF_8)
                    for (peer in peers.values) send(s, data, peer.addr, peer.port)
                }
                if (now - lastBeacon >= BEACON_EVERY) {
                    lastBeacon = now
                    val data = beaconJson().toByteArray(Charsets.UTF_8)
                    for (b in broadcastTargets()) send(s, data, b, PORT)
                }
            }
            try {
                Thread.sleep(STATUS_EVERY)
            } catch (e: InterruptedException) {
            }
        }
    }

    private fun send(s: DatagramSocket, data: ByteArray, addr: InetAddress, port: Int) {
        try {
            synchronized(sendLock) { s.send(DatagramPacket(data, data.size, addr, port)) }
        } catch (e: Exception) {
        }
    }

    private fun broadcastTargets(): List<InetAddress> {
        val out = LinkedHashSet<InetAddress>()
        try {
            out.add(InetAddress.getByName("255.255.255.255"))
        } catch (e: Exception) {
        }
        try {
            val all = NetworkInterface.getNetworkInterfaces()
            if (all != null) {
                for (ni in all) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) {
                        val b = ia.broadcast
                        if (b != null) out.add(b)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out.toList()
    }

    private fun deviceName(): String = Build.MODEL ?: "Tablet"

    private fun beaconJson(): String {
        val o = JSONObject()
        o.put("type", "beacon")
        o.put("name", deviceName())
        o.put("build", Updater.currentBuild(ctx))
        o.put("lock", prefs.pin.isNotEmpty())
        return o.toString()
    }

    private fun statusJson(): String {
        val running = SilentState.running
        var color = "grey"
        var icon = "play"
        val text: String
        when {
            !running -> text = "Fermo"
            prefs.suspended -> {
                icon = "pause"
                text = "Sospeso: tocca il cerchio per riattivare"
            }
            SilentState.waiting ->
                text = if (prefs.source == "pc") "In attesa del flusso dal PC" else "Collega il microfono esterno"
            SilentState.calibrating -> {
                color = "green"
                text = "Imparo il volume del tablet..."
            }
            SilentState.sound -> {
                color = "orange"
                icon = "pause"
                val left = SilentState.restartInMs
                text = if (left > 0) "Audio finito: riparto tra ${(left / 1000) + 1} s"
                else "Audio rilevato: video in pausa"
            }
            else -> {
                color = "green"
                text = "Silenzio: video attivo"
            }
        }
        val set = JSONObject()
        set.put("threshold", prefs.threshold)
        set.put("delay", prefs.delaySec)
        set.put("minMs", prefs.minSoundMs)
        set.put("onlyPlaying", prefs.onlyIfPlaying)
        set.put("toggle", prefs.useToggle)
        set.put("source", prefs.source)
        set.put("suspended", prefs.suspended)

        val o = JSONObject()
        o.put("type", "status")
        o.put("name", deviceName())
        o.put("build", Updater.currentBuild(ctx))
        o.put("running", running)
        o.put("level", if (running) SilentState.level else 0)
        o.put("threshold", if (running) SilentState.effectiveThreshold else prefs.threshold)
        o.put("text", text)
        o.put("color", color)
        o.put("icon", icon)
        o.put("action", SilentState.lastAction)
        o.put("input", if (running) SilentState.inputLabel else "-")
        o.put("set", set)
        return o.toString()
    }
}
