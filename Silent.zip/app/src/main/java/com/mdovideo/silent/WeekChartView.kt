package com.mdovideo.silent

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Grafico a barre degli ultimi 7 giorni: ogni barra e' impilata, arancione = lavoro,
 * grigio = riproduzione. Il giorno piu' vecchio e' a sinistra, oggi a destra.
 */
class WeekChartView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var data: List<Triple<String, Long, Long>> = emptyList()

    private val dp = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity

    private val workPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.orange)
    }
    private val playPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.track)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.grey)
        textSize = 11f * sp
        textAlign = Paint.Align.CENTER
    }
    private val todayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.white)
        textSize = 11f * sp
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(ctx, R.color.white)
        textSize = 10f * sp
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val initials = arrayOf("D", "L", "M", "M", "G", "V", "S")

    /** [days] = come WorkLog.daysData(7): oggi per primo, valori in secondi. */
    fun setData(days: List<Triple<String, Long, Long>>) {
        val ordered = days.reversed()
        if (ordered == data) return
        data = ordered
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = (150f * dp).toInt()
        setMeasuredDimension(
            resolveSize(suggestedMinimumWidth, widthMeasureSpec),
            resolveSize(h, heightMeasureSpec)
        )
    }

    private fun initialOf(day: String): String {
        return try {
            val cal = java.util.Calendar.getInstance()
            cal.time = dayFmt.parse(day) ?: return "?"
            initials[cal.get(java.util.Calendar.DAY_OF_WEEK) - 1]
        } catch (e: Exception) {
            "?"
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        val labelH = 18f * dp
        val valueH = 14f * dp
        val chartTop = valueH
        val chartBottom = h - labelH
        val chartH = chartBottom - chartTop
        // scala: almeno 1 ora, cosi' un giorno quasi vuoto non diventa una barra gigante
        val biggest = maxOf(3600L, data.maxOf { it.second + it.third })
        val slot = w / data.size
        val barW = slot * 0.56f
        val radius = 6f * dp

        for ((i, d) in data.withIndex()) {
            val cx = slot * i + slot / 2f
            val left = cx - barW / 2f
            val right = cx + barW / 2f
            val total = d.second + d.third
            val isToday = i == data.size - 1

            // base tenue per i giorni senza dati: si vede che il giorno esiste
            if (total == 0L) {
                rect.set(left, chartBottom - 3f * dp, right, chartBottom)
                canvas.drawRoundRect(rect, 2f * dp, 2f * dp, playPaint)
            } else {
                val totalH = chartH * total / biggest.toFloat()
                val playH = totalH * d.third / total.toFloat()
                val top = chartBottom - totalH
                // barra intera (riproduzione) e sopra il pezzo di lavoro
                rect.set(left, top, right, chartBottom)
                canvas.drawRoundRect(rect, radius, radius, playPaint)
                if (d.second > 0L) {
                    val workTop = top
                    val workBottom = top + (totalH - playH)
                    rect.set(left, workTop, right, maxOf(workBottom, workTop + 3f * dp))
                    canvas.drawRoundRect(rect, radius, radius, workPaint)
                }
                if (d.second > 0L) {
                    val hours = d.second / 3600f
                    canvas.drawText("%.1fh".format(Locale.US, hours), cx, top - 3f * dp, valuePaint)
                }
            }
            canvas.drawText(initialOf(d.first), cx, h - 4f * dp, if (isToday) todayPaint else labelPaint)
        }
    }
}
