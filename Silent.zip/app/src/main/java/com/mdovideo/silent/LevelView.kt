package com.mdovideo.silent

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Barra del livello audio con linea della soglia. */
class LevelView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var level: Int = 0
        set(v) {
            field = v
            invalidate()
        }

    var threshold: Int = 40
        set(v) {
            field = v
            invalidate()
        }

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#232C42") }
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        canvas.drawRoundRect(0f, 0f, w, h, r, r, trackPaint)
        if (level > 0) {
            barPaint.color = if (level >= threshold) Color.parseColor("#FF9F43") else Color.parseColor("#2ED573")
            val fw = maxOf(w * level / 100f, h)
            canvas.drawRoundRect(0f, 0f, fw, h, r, r, barPaint)
        }
        val x = w * threshold / 100f
        canvas.drawRect(x - 3f, 0f, x + 3f, h, linePaint)
    }
}
