package com.mdovideo.silent

/** Stato condiviso tra servizio di ascolto e schermata. */
object SilentState {
    @Volatile var running = false
    @Volatile var level = 0
    @Volatile var sound = false
    @Volatile var pausedByMe = false
    @Volatile var restartInMs = -1L
    @Volatile var inputLabel = "-"
    @Volatile var lastAction = ""
    @Volatile var external = false
    @Volatile var waiting = false
    @Volatile var calibrating = false
    @Volatile var ownLevel = 0
    @Volatile var effectiveThreshold = 40
    @Volatile var pcConnected = false
    /** Quante app Windows stanno comandando il tablet in questo momento. */
    @Volatile var controlPeers = 0
    /** Cresce quando il PC cambia le impostazioni: la schermata si riallinea. */
    @Volatile var settingsRev = 0
    /** true se in questo momento c'è una riproduzione in corso (non sto lavorando). */
    @Volatile var playingNow = false

    fun reset() {
        level = 0
        sound = false
        pausedByMe = false
        restartInMs = -1L
        lastAction = ""
        external = false
        waiting = false
        calibrating = false
        ownLevel = 0
        pcConnected = false
        playingNow = false
    }
}
