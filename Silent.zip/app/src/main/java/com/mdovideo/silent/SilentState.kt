package com.mdovideo.silent

/** Stato condiviso tra servizio di ascolto e schermata. */
object SilentState {
    @Volatile var running = false
    @Volatile var level = 0
    @Volatile var sound = false
    @Volatile var pausedByMe = false
    @Volatile var restartInMs = -1L
    @Volatile var inputLabel = "-"
    @Volatile var lastAction = ""

    fun reset() {
        level = 0
        sound = false
        pausedByMe = false
        restartInMs = -1L
        lastAction = ""
    }
}
