package com.mdovideo.silent

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Registro del tempo di lavoro.
 * Con l'ascolto attivo: riproduzione in pausa = lavoro, riproduzione in play = non lavoro.
 * I totali sono salvati per giorno (ultimi 90 giorni).
 */
object WorkLog {
    private const val KEEP_DAYS = 90

    /** Tipi di tempo registrati. */
    const val WORK = 0   // stai lavorando: audio dal PC (o video in pausa da Silent)
    const val PLAY = 1   // c'e' una riproduzione in corso: non stai lavorando
    const val IDLE = 2   // nessuna riproduzione e nessun audio dal PC: non conta ne' come lavoro ne' come riproduzione

    private var sp: SharedPreferences? = null
    private val work = HashMap<String, Long>()
    private val play = HashMap<String, Long>()
    private val idle = HashMap<String, Long>()
    private var dirty = false

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val prefs = ctx.applicationContext.getSharedPreferences("worklog", Context.MODE_PRIVATE)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -KEEP_DAYS)
        val cutoff = dayKey(cal.timeInMillis)
        val ed = prefs.edit()
        for ((k, v) in prefs.all) {
            if (v !is Long || k.length < 3) continue
            val day = k.substring(2)
            if (day < cutoff) {
                ed.remove(k)
                continue
            }
            if (k.startsWith("w_")) work[day] = v
            else if (k.startsWith("p_")) play[day] = v
            else if (k.startsWith("i_")) idle[day] = v
        }
        ed.apply()
        sp = prefs
    }

    fun dayKey(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

    fun today(): String = dayKey(System.currentTimeMillis())

    /** Aggiunge [ms] millisecondi al tipo [kind]: WORK, PLAY oppure IDLE. */
    @Synchronized
    fun add(kind: Int, ms: Long) {
        if (ms <= 0L) return
        val day = today()
        val m = when (kind) {
            PLAY -> play
            WORK -> work
            else -> idle
        }
        m[day] = (m[day] ?: 0L) + ms
        dirty = true
    }

    @Synchronized
    fun flush() {
        val prefs = sp ?: return
        if (!dirty) return
        val ed = prefs.edit()
        for ((d, v) in work) ed.putLong("w_$d", v)
        for ((d, v) in play) ed.putLong("p_$d", v)
        for ((d, v) in idle) ed.putLong("i_$d", v)
        ed.apply()
        dirty = false
    }

    @Synchronized
    fun workMs(day: String): Long = work[day] ?: 0L

    @Synchronized
    fun playMs(day: String): Long = play[day] ?: 0L

    @Synchronized
    fun idleMs(day: String): Long = idle[day] ?: 0L

    fun fmt(ms: Long): String {
        val totalMin = ms / 60_000L
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 -> "${h}h ${m}m"
            totalMin > 0 -> "${m}m"
            else -> "${ms / 1000L}s"
        }
    }

    fun pct(w: Long, p: Long): Int {
        val tot = w + p
        return if (tot <= 0L) 0 else (w * 100L / tot).toInt()
    }

    fun summary(day: String): String {
        val w = workMs(day)
        val p = playMs(day)
        val i = idleMs(day)
        val extra = if (i > 0L) " · Inattivo ${fmt(i)}" else ""
        return "Lavoro ${fmt(w)} · Riproduzione ${fmt(p)} · ${pct(w, p)}% lavoro$extra"
    }

    /** Una riga per ognuno degli ultimi [days] giorni, oggi per primo. */
    fun weekText(days: Int = 7): String {
        val df = SimpleDateFormat("EEE dd/MM", Locale.ITALY)
        val cal = Calendar.getInstance()
        val sb = StringBuilder()
        for (i in 0 until days) {
            val t = cal.timeInMillis
            val key = dayKey(t)
            val w = workMs(key)
            val p = playMs(key)
            val label = if (i == 0) "Oggi" else df.format(Date(t))
            if (sb.isNotEmpty()) sb.append('\n')
            if (w + p == 0L) {
                sb.append("$label: nessun dato")
            } else {
                sb.append("$label: lavoro ${fmt(w)} · play ${fmt(p)} (${pct(w, p)}%)")
            }
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return sb.toString()
    }

    /** Dati per il report sul PC: (giorno, secondi di lavoro, secondi di riproduzione), oggi per primo. */
    fun daysData(days: Int): List<Triple<String, Long, Long>> {
        val out = ArrayList<Triple<String, Long, Long>>()
        val cal = Calendar.getInstance()
        for (i in 0 until days) {
            val key = dayKey(cal.timeInMillis)
            out.add(Triple(key, workMs(key) / 1000L, playMs(key) / 1000L))
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return out
    }

    /** Testo del report da condividere. */
    fun reportText(): String {
        val day = today()
        val w = workMs(day)
        val p = playMs(day)
        return "Silent - report di oggi\n" +
            "Lavoro: ${fmt(w)}\n" +
            "Riproduzione (non lavoro): ${fmt(p)}\n" +
            "Inattivo (nessun audio): ${fmt(idleMs(day))}\n" +
            "Quota di lavoro: ${pct(w, p)}%\n\n" +
            "Ultimi 7 giorni:\n" + weekText()
    }
}
