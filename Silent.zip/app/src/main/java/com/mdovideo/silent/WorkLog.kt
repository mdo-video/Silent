package com.mdovideo.silent

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Registro del tempo di lavoro.
 * Con l'ascolto attivo: riproduzione in pausa = lavoro, riproduzione in play = non lavoro.
 * I totali sono salvati per giorno (ultimi 90 giorni).
 */
object WorkLog {
    private const val KEEP_DAYS = 90

    private var sp: SharedPreferences? = null
    private val work = HashMap<String, Long>()
    private val play = HashMap<String, Long>()
    private var dirty = false

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        val prefs = ctx.applicationContext.getSharedPreferences("worklog", Context.MODE_PRIVATE)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -KEEP_DAYS)
        val cutoff = dayKey(cal.timeInMillis)
        val ed = prefs.edit()
        for ((k, v) in prefs.all) {
            if (v !is Long || k.length < 3) continue
            val day = k.substring(2)
            if (day < cutoff) {
                ed.remove(k)
                continue
            }
            if (k.startsWith("w_")) work[day] = v
            else if (k.startsWith("p_")) play[day] = v
        }
        ed.apply()
        sp = prefs
    }

    fun dayKey(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

    fun today(): String = dayKey(System.currentTimeMillis())

    /** Aggiunge [ms] millisecondi a "riproduzione" (playing = true) oppure a "lavoro". */
    @Synchronized
    fun add(playing: Boolean, ms: Long) {
        if (ms <= 0L) return
        val day = today()
        val m = if (playing) play else work
        m[day] = (m[day] ?: 0L) + ms
        dirty = true
    }

    @Synchronized
    fun flush() {
        val prefs = sp ?: return
        if (!dirty) return
        val ed = prefs.edit()
        for ((d, v) in work) ed.putLong("w_$d", v)
        for ((d, v) in play) ed.putLong("p_$d", v)
        ed.apply()
        dirty = false
    }

    @Synchronized
    fun workMs(day: String): Long = work[day] ?: 0L

    @Synchronized
    fun playMs(day: String): Long = play[day] ?: 0L

    fun fmt(ms: Long): String {
        val totalMin = ms / 60_000L
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 -> "${h}h ${m}m"
            totalMin > 0 -> "${m}m"
            else -> "${ms / 1000L}s"
        }
    }

    fun pct(w: Long, p: Long): Int {
        val tot = w + p
        return if (tot <= 0L) 0 else (w * 100L / tot).toInt()
    }

    fun summary(day: String): String {
        val w = workMs(day)
        val p = playMs(day)
        return "Lavoro ${fmt(w)} · Riproduzione ${fmt(p)} · ${pct(w, p)}% lavoro"
    }

    /** Una riga per ognuno degli ultimi [days] giorni, oggi per primo. */
    fun weekText(days: Int = 7): String {
        val df = SimpleDateFormat("EEE dd/MM", Locale.ITALY)
        val cal = Calendar.getInstance()
        val sb = StringBuilder()
        for (i in 0 until days) {
            val t = cal.timeInMillis
            val key = dayKey(t)
            val w = workMs(key)
            val p = playMs(key)
            val label = if (i == 0) "Oggi" else df.format(Date(t))
            if (sb.isNotEmpty()) sb.append('\n')
            if (w + p == 0L) {
                sb.append("$label: nessun dato")
            } else {
                sb.append("$label: lavoro ${fmt(w)} · play ${fmt(p)} (${pct(w, p)}%)")
            }
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return sb.toString()
    }

    /** Testo del report da condividere. */
    fun reportText(): String {
        val day = today()
        val w = workMs(day)
        val p = playMs(day)
        return "Silent - report di oggi\n" +
            "Lavoro: ${fmt(w)}\n" +
            "Riproduzione (non lavoro): ${fmt(p)}\n" +
            "Quota di lavoro: ${pct(w, p)}%\n\n" +
            "Ultimi 7 giorni:\n" + weekText()
    }
}
