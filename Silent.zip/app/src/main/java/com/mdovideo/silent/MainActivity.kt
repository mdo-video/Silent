package com.mdovideo.silent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var circle: FrameLayout
    private lateinit var statusIcon: ImageView
    private lateinit var statusText: TextView
    private lateinit var inputText: TextView
    private lateinit var levelView: LevelView
    private lateinit var levelText: TextView
    private lateinit var thresholdLabel: TextView
    private lateinit var delayLabel: TextView
    private lateinit var startButton: Button

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 80)
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMic()) {
                startListening()
            } else {
                Toast.makeText(this, "Serve il permesso del microfono", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        val root = findViewById<View>(R.id.root)
        val density = resources.displayMetrics.density
        val widthDp = resources.displayMetrics.widthPixels / density
        if (widthDp > 700f) {
            val pad = ((widthDp - 600f) / 2f * density).toInt()
            root.setPadding(pad, root.paddingTop, pad, root.paddingBottom)
        }

        circle = findViewById(R.id.circle)
        statusIcon = findViewById(R.id.statusIcon)
        statusText = findViewById(R.id.statusText)
        inputText = findViewById(R.id.inputText)
        levelView = findViewById(R.id.levelView)
        levelText = findViewById(R.id.levelText)
        thresholdLabel = findViewById(R.id.thresholdLabel)
        delayLabel = findViewById(R.id.delayLabel)
        startButton = findViewById(R.id.startButton)

        val thresholdSeek = findViewById<SeekBar>(R.id.thresholdSeek)
        val delaySeek = findViewById<SeekBar>(R.id.delaySeek)
        val switchOnly = findViewById<SwitchCompat>(R.id.switchOnlyPlaying)
        val switchToggle = findViewById<SwitchCompat>(R.id.switchToggle)

        thresholdSeek.progress = prefs.threshold
        delaySeek.progress = prefs.delaySec - 1
        switchOnly.isChecked = prefs.onlyIfPlaying
        switchToggle.isChecked = prefs.useToggle
        updateLabels()

        thresholdSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.threshold = p
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.delaySec = p + 1
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        switchOnly.setOnCheckedChangeListener { _, checked -> prefs.onlyIfPlaying = checked }
        switchToggle.setOnCheckedChangeListener { _, checked -> prefs.useToggle = checked }

        startButton.setOnClickListener {
            if (SilentState.running) {
                stopService(Intent(this, ListenService::class.java))
            } else {
                requestAndStart()
            }
        }
        findViewById<Button>(R.id.testPause).setOnClickListener {
            MediaKeys.pause(this, prefs.useToggle)
        }
        findViewById<Button>(R.id.testPlay).setOnClickListener {
            MediaKeys.play(this, prefs.useToggle)
        }
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestAndStart() {
        if (hasMic()) {
            startListening()
            return
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun startListening() {
        ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
    }

    private fun updateLabels() {
        thresholdLabel.text = "Soglia audio: ${prefs.threshold}"
        delayLabel.text = "Ritardo ripartenza: ${prefs.delaySec} s"
    }

    private fun refresh() {
        val running = SilentState.running
        levelView.threshold = prefs.threshold
        levelView.level = if (running) SilentState.level else 0
        levelText.text = "Livello ${if (running) SilentState.level else 0} · soglia ${prefs.threshold}"
        inputText.text = if (running) "Ingresso: ${SilentState.inputLabel}" else "Ingresso: -"
        startButton.text = if (running) "Ferma ascolto" else "Avvia ascolto"

        val color: Int
        val icon: Int
        val text: String
        when {
            !running -> {
                color = Color.parseColor("#6B7690")
                icon = R.drawable.ic_play
                text = "Fermo"
            }
            SilentState.sound -> {
                color = Color.parseColor("#FF9F43")
                icon = R.drawable.ic_pause
                val left = SilentState.restartInMs
                text = if (left > 0) {
                    "Audio finito: riparto tra ${(left / 1000) + 1} s"
                } else {
                    "Audio rilevato: video in pausa"
                }
            }
            else -> {
                color = Color.parseColor("#2ED573")
                icon = R.drawable.ic_play
                text = "Silenzio: video attivo"
            }
        }
        circle.backgroundTintList = ColorStateList.valueOf(color)
        statusIcon.setImageResource(icon)
        val action = SilentState.lastAction
        statusText.text = if (running && action.isNotEmpty()) "$text\n($action)" else text
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
