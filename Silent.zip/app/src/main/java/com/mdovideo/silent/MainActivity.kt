package com.mdovideo.silent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    companion object {
        // Sopravvivono alla rotazione dello schermo (l'activity viene ricreata)
        private var updChecked = false
        private var cachedUpdate: Updater.Info? = null
    }

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var circle: FrameLayout
    private lateinit var statusIcon: ImageView
    private lateinit var statusText: TextView
    private lateinit var inputText: TextView
    private lateinit var levelView: LevelView
    private lateinit var levelText: TextView
    private lateinit var thresholdLabel: TextView
    private lateinit var delayLabel: TextView
    private lateinit var minSoundLabel: TextView
    private lateinit var minSoundSeek: SeekBar
    private lateinit var batteryButton: Button
    private lateinit var startButton: Button
    private lateinit var bgButton: Button
    private var lastTint = 0
    private lateinit var sourceGroup: RadioGroup
    private lateinit var radioTablet: RadioButton
    private lateinit var radioPc: RadioButton
    private lateinit var pcInfo: TextView
    private lateinit var ipInfo: TextView
    private lateinit var settingsPanel: View
    private lateinit var settingsButton: Button
    private lateinit var micOptions: View
    private lateinit var workState: TextView
    private lateinit var workToday: TextView
    private lateinit var playToday: TextView
    private lateinit var weekText: TextView
    private lateinit var reportHourLabel: TextView
    private lateinit var thresholdSeek: SeekBar
    private lateinit var delaySeek: SeekBar
    private lateinit var switchOnly: SwitchCompat
    private lateinit var switchToggle: SwitchCompat
    private lateinit var updText: TextView
    private lateinit var updButton: Button
    private var lastWorkUi = 0L
    private var lastRev = 0
    private var pendingUpdate: Updater.Info? = null
    private var updBusy = false

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 80)
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (prefs.source == "pc" || hasMic()) {
                startListening()
            } else {
                Toast.makeText(this, "Serve il permesso del microfono", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        val root = findViewById<View>(R.id.root)
        val density = resources.displayMetrics.density
        val widthDp = resources.displayMetrics.widthPixels / density
        val portrait = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
        // Verticale: colonna centrale larga al massimo 600dp. Orizzontale (tre colonne): tutto lo schermo.
        if (portrait && widthDp > 700f) {
            val pad = ((widthDp - 600f) / 2f * density).toInt()
            root.setPadding(pad, root.paddingTop, pad, root.paddingBottom)
        }

        circle = findViewById(R.id.circle)
        statusIcon = findViewById(R.id.statusIcon)
        statusText = findViewById(R.id.statusText)
        inputText = findViewById(R.id.inputText)
        levelView = findViewById(R.id.levelView)
        levelText = findViewById(R.id.levelText)
        thresholdLabel = findViewById(R.id.thresholdLabel)
        delayLabel = findViewById(R.id.delayLabel)
        startButton = findViewById(R.id.startButton)
        bgButton = findViewById(R.id.bgButton)
        bgButton.setOnClickListener { startInBackground() }
        sourceGroup = findViewById(R.id.sourceGroup)
        radioTablet = findViewById(R.id.radioTablet)
        radioPc = findViewById(R.id.radioPc)
        pcInfo = findViewById(R.id.pcInfo)
        ipInfo = findViewById(R.id.ipInfo)
        settingsPanel = findViewById(R.id.settingsPanel)
        settingsButton = findViewById(R.id.settingsButton)
        settingsButton.setOnClickListener {
            val open = settingsPanel.visibility != View.VISIBLE
            settingsPanel.visibility = if (open) View.VISIBLE else View.GONE
            settingsButton.text = if (open) "Chiudi impostazioni" else "Impostazioni"
            if (open) updatePcInfo()
        }
        micOptions = findViewById(R.id.micOptions)
        workState = findViewById(R.id.workState)
        workToday = findViewById(R.id.workToday)
        playToday = findViewById(R.id.playToday)
        weekText = findViewById(R.id.weekText)
        reportHourLabel = findViewById(R.id.reportHourLabel)

        WorkLog.init(this)
        ReportScheduler.schedule(this)

        val switchReport = findViewById<SwitchCompat>(R.id.switchReport)
        val reportHourSeek = findViewById<SeekBar>(R.id.reportHourSeek)
        switchReport.isChecked = prefs.reportEnabled
        reportHourSeek.progress = prefs.reportHour
        reportHourSeek.isEnabled = prefs.reportEnabled
        updateReportLabel()
        switchReport.setOnCheckedChangeListener { _, checked ->
            prefs.reportEnabled = checked
            reportHourSeek.isEnabled = checked
            ReportScheduler.schedule(this)
        }
        reportHourSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.reportHour = p
                updateReportLabel()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                ReportScheduler.schedule(this@MainActivity)
            }
        })
        findViewById<Button>(R.id.shareReport).setOnClickListener {
            WorkLog.flush()
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "Silent - report di oggi")
                .putExtra(Intent.EXTRA_TEXT, WorkLog.reportText())
            startActivity(Intent.createChooser(send, "Condividi report"))
        }

        thresholdSeek = findViewById(R.id.thresholdSeek)
        delaySeek = findViewById(R.id.delaySeek)
        minSoundLabel = findViewById(R.id.minSoundLabel)
        minSoundSeek = findViewById(R.id.minSoundSeek)
        val switchExternal = findViewById<SwitchCompat>(R.id.switchExternal)
        val switchAntiEcho = findViewById<SwitchCompat>(R.id.switchAntiEcho)
        val switchSystemEcho = findViewById<SwitchCompat>(R.id.switchSystemEcho)
        switchOnly = findViewById(R.id.switchOnlyPlaying)
        switchToggle = findViewById(R.id.switchToggle)

        thresholdSeek.progress = prefs.threshold
        delaySeek.progress = prefs.delaySec - 1
        minSoundSeek.progress = prefs.minSoundMs / 50
        switchExternal.isChecked = prefs.externalOnly
        switchAntiEcho.isChecked = prefs.antiEcho
        switchSystemEcho.isChecked = prefs.systemEcho
        switchOnly.isChecked = prefs.onlyIfPlaying
        switchToggle.isChecked = prefs.useToggle
        updateLabels()

        thresholdSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.threshold = p
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.delaySec = p + 1
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        minSoundSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.minSoundMs = p * 50
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        switchExternal.setOnCheckedChangeListener { _, checked -> prefs.externalOnly = checked }
        switchAntiEcho.setOnCheckedChangeListener { _, checked -> prefs.antiEcho = checked }
        switchSystemEcho.setOnCheckedChangeListener { _, checked ->
            prefs.systemEcho = checked
            if (SilentState.running) {
                Toast.makeText(this, "Ferma e riavvia l'ascolto per applicarlo", Toast.LENGTH_SHORT).show()
            }
        }
        switchOnly.setOnCheckedChangeListener { _, checked -> prefs.onlyIfPlaying = checked }
        switchToggle.setOnCheckedChangeListener { _, checked -> prefs.useToggle = checked }

        sourceGroup.check(if (prefs.source == "pc") R.id.radioPc else R.id.radioTablet)
        applySourceUi()
        sourceGroup.setOnCheckedChangeListener { _, id ->
            prefs.source = if (id == R.id.radioPc) "pc" else "tablet"
            applySourceUi()
        }

        startButton.setOnClickListener {
            if (SilentState.running) {
                startService(
                    Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP)
                )
            } else {
                requestAndStart()
            }
        }
        updText = findViewById(R.id.updText)
        updButton = findViewById(R.id.updButton)
        updText.text = "Versione ${Updater.currentBuild(this)}"
        updButton.setOnClickListener { onUpdateClick() }
        lastRev = SilentState.settingsRev
        // Dopo una rotazione non rifaccio il controllo: ripristino quello gia' fatto
        if (!updChecked) {
            updChecked = true
            checkUpdates()
        } else {
            restoreUpdateUi()
        }

        // Servizio "a riposo": il PC trova il tablet e lo comanda anche senza premere Avvia
        try {
            ContextCompat.startForegroundService(
                this, Intent(this, ListenService::class.java).setAction(ListenService.ACTION_IDLE)
            )
        } catch (e: Exception) {
        }

        findViewById<Button>(R.id.testPause).setOnClickListener {
            MediaKeys.pause(this, prefs.useToggle)
        }
        findViewById<Button>(R.id.testPlay).setOnClickListener {
            MediaKeys.play(this, prefs.useToggle)
        }

        // PIN di abbinamento con il PC (vuoto = nessuna protezione)
        val pinEdit = findViewById<EditText>(R.id.pinEdit)
        pinEdit.setText(prefs.pin)
        pinEdit.doAfterTextChanged { prefs.pin = it?.toString()?.trim() ?: "" }

        // Esclusione dal risparmio energetico: Android non chiude piu' Silent a schermo spento
        batteryButton = findViewById(R.id.batteryButton)
        batteryButton.setOnClickListener {
            if (isBatteryExempt()) {
                Toast.makeText(this, "Silent e' gia' escluso dal risparmio energetico", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e2: Exception) {
                    }
                }
            }
        }
    }

    private fun isBatteryExempt(): Boolean =
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun updateBatteryButton() {
        batteryButton.text = if (isBatteryExempt()) "Batteria: Silent non viene chiuso \u2713"
        else "Non far chiudere Silent (batteria)"
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    /** Fa partire l'ascolto e porta l'app in secondo piano: poi si comanda dal PC. */
    private fun startInBackground() {
        if (SilentState.running) {
            moveTaskToBack(true)
            return
        }
        val needMic = prefs.source != "pc" && !hasMic()
        val needNotif = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        requestAndStart()
        // se Android sta chiedendo un permesso resto qui, altrimenti vado in secondo piano
        if (!needMic && !needNotif) moveTaskToBack(true)
    }

    private fun requestAndStart() {
        val pc = prefs.source == "pc"
        val perms = mutableListOf<String>()
        if (!pc && !hasMic()) perms.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isEmpty()) {
            startListening()
        } else {
            permLauncher.launch(perms.toTypedArray())
        }
    }

    private fun startListening() {
        ContextCompat.startForegroundService(
            this, Intent(this, ListenService::class.java).setAction(ListenService.ACTION_START)
        )
    }

    private fun applySourceUi() {
        val pc = prefs.source == "pc"
        micOptions.visibility = if (pc) View.GONE else View.VISIBLE
        pcInfo.visibility = if (pc) View.VISIBLE else View.GONE
        if (pc) {
            updatePcInfo()
        }
    }

    private fun updatePcInfo() {
        val linked = if (SilentState.controlPeers > 0) "PC collegato e in controllo" else "Apri Silent PC sul computer: ti trova da solo"
        if (pcInfo.text.toString() != linked) pcInfo.text = linked
        val ip = "IP del tablet: ${localIp()}\n$linked"
        if (ipInfo.text.toString() != ip) ipInfo.text = ip
    }

    // ---- aggiornamenti
    private fun checkUpdates() {
        if (updBusy) return
        updBusy = true
        updButton.isEnabled = false
        updText.text = "Controllo aggiornamenti..."
        Thread {
            val r = Updater.check(this)
            runOnUiThread {
                updBusy = false
                updButton.isEnabled = true
                when (r) {
                    is Updater.Result.Newer -> {
                        pendingUpdate = r.info
                        cachedUpdate = r.info
                        updText.text = "Disponibile la build ${r.info.build} (hai la ${Updater.currentBuild(this)})"
                        updButton.text = "Aggiorna ora"
                    }
                    is Updater.Result.UpToDate -> {
                        pendingUpdate = null
                        cachedUpdate = null
                        updText.text = "Sei aggiornato (build ${Updater.currentBuild(this)})"
                        updButton.text = "Controlla aggiornamenti"
                    }
                    is Updater.Result.Error -> {
                        pendingUpdate = null
                        cachedUpdate = null
                        updText.text = "Aggiornamenti: ${r.msg}"
                        updButton.text = "Riprova"
                    }
                }
            }
        }.start()
    }

    private fun restoreUpdateUi() {
        val info = cachedUpdate
        pendingUpdate = info
        if (info != null) {
            updText.text = "Disponibile la build ${info.build} (hai la ${Updater.currentBuild(this)})"
            updButton.text = "Aggiorna ora"
        } else {
            updText.text = "Versione ${Updater.currentBuild(this)}"
        }
    }

    private fun onUpdateClick() {
        val info = pendingUpdate
        if (info == null) {
            checkUpdates()
            return
        }
        if (updBusy) return
        updBusy = true
        updButton.isEnabled = false
        Thread {
            try {
                val file = Updater.download(this, info) { pct ->
                    runOnUiThread { updText.text = "Scarico l'aggiornamento... $pct%" }
                }
                runOnUiThread {
                    updBusy = false
                    updButton.isEnabled = true
                    val msg = Updater.install(this, file)
                    updText.text = msg ?: "Conferma l'installazione sullo schermo"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    updBusy = false
                    updButton.isEnabled = true
                    updText.text = "Download non riuscito: ${e.message}"
                }
            }
        }.start()
    }

    /** Il PC ha cambiato le impostazioni: riallineo cursori e interruttori. */
    private fun syncFromPrefs() {
        thresholdSeek.progress = prefs.threshold
        delaySeek.progress = prefs.delaySec - 1
        minSoundSeek.progress = prefs.minSoundMs / 50
        switchOnly.isChecked = prefs.onlyIfPlaying
        switchToggle.isChecked = prefs.useToggle
        val wantPc = prefs.source == "pc"
        if ((sourceGroup.checkedRadioButtonId == R.id.radioPc) != wantPc) {
            sourceGroup.check(if (wantPc) R.id.radioPc else R.id.radioTablet)
        }
        updateLabels()
    }

    private fun localIp(): String {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return "non connesso al Wi-Fi"
            for (ni in all) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: "-"
                }
            }
        } catch (e: Exception) {
        }
        return "non connesso al Wi-Fi"
    }

    private fun updateReportLabel() {
        reportHourLabel.text = "Orario report: %02d:00".format(prefs.reportHour)
    }

    private fun updateWorkCard(running: Boolean) {
        val sec = System.currentTimeMillis() / 1000L
        if (sec == lastWorkUi) return
        lastWorkUi = sec
        val day = WorkLog.today()
        val w = WorkLog.workMs(day)
        val p = WorkLog.playMs(day)
        workState.text = when {
            !running -> "Ascolto fermo: il tempo non viene registrato"
            SilentState.workKind == WorkLog.PLAY -> "In riproduzione: non stai lavorando"
            SilentState.workKind == WorkLog.WORK -> "Stai lavorando (audio dal PC)"
            else -> "Inattivo: nessun audio da un po', non conta come lavoro"
        }
        workToday.text = "Lavoro oggi: ${WorkLog.fmt(w)}"
        val idleMs = WorkLog.idleMs(day)
        val idleTxt = if (idleMs > 0L) " · inattivo ${WorkLog.fmt(idleMs)}" else ""
        playToday.text = "Riproduzione oggi: ${WorkLog.fmt(p)} · ${WorkLog.pct(w, p)}% lavoro$idleTxt"
        weekText.text = WorkLog.weekText()
    }

    private fun updateLabels() {
        thresholdLabel.text = "Soglia audio: ${prefs.threshold}"
        delayLabel.text = "Ritardo ripartenza: ${prefs.delaySec} s"
        minSoundLabel.text = "Durata minima suono: ${prefs.minSoundMs} ms"
    }

    private fun refresh() {
        val rev = SilentState.settingsRev
        if (rev != lastRev) {
            lastRev = rev
            syncFromPrefs()
        }
        if (prefs.source == "pc" || settingsPanel.visibility == View.VISIBLE) updatePcInfo()
        val running = SilentState.running
        radioTablet.isEnabled = !running
        radioPc.isEnabled = !running
        val threshold = if (running) SilentState.effectiveThreshold else prefs.threshold
        levelView.threshold = threshold
        levelView.level = if (running) SilentState.level else 0
        val tabletInfo = if (running && !SilentState.external && SilentState.ownLevel > 0 && prefs.antiEcho) {
            " · tablet ${SilentState.ownLevel}"
        } else {
            ""
        }
        levelText.text = "Livello ${if (running) SilentState.level else 0} · soglia $threshold$tabletInfo"
        inputText.text = if (running) "Ingresso: ${SilentState.inputLabel}" else "Ingresso: -"
        startButton.text = if (running) "Ferma ascolto" else "Avvia ascolto"
        bgButton.text = if (running) "Metti in background" else "Avvia in background"
        // verde = attivo, arancione = fermo (come i tasti dell'app Windows)
        val tint = if (running) 0xFF2ED573.toInt() else 0xFFFF9F43.toInt()
        if (tint != lastTint) {
            lastTint = tint
            startButton.backgroundTintList = android.content.res.ColorStateList.valueOf(tint)
        }

        val color: Int
        val icon: Int
        val text: String
        when {
            !running -> {
                color = Color.parseColor("#6B7690")
                icon = R.drawable.ic_play
                text = "Fermo"
            }
            SilentState.waiting -> {
                color = Color.parseColor("#6B7690")
                icon = R.drawable.ic_play
                text = if (prefs.source == "pc") "In attesa del flusso dal PC" else "Collega il microfono esterno"
            }
            SilentState.calibrating -> {
                color = Color.parseColor("#2ED573")
                icon = R.drawable.ic_play
                text = "Imparo il volume del tablet..."
            }
            SilentState.sound -> {
                color = Color.parseColor("#FF9F43")
                icon = R.drawable.ic_pause
                val left = SilentState.restartInMs
                text = if (left > 0) {
                    "Audio finito: riparto tra ${(left / 1000) + 1} s"
                } else {
                    "Audio rilevato: video in pausa"
                }
            }
            else -> {
                color = Color.parseColor("#2ED573")
                icon = R.drawable.ic_play
                text = "Silenzio: video attivo"
            }
        }
        circle.backgroundTintList = ColorStateList.valueOf(color)
        statusIcon.setImageResource(icon)
        val action = SilentState.lastAction
        statusText.text = if (running && action.isNotEmpty()) "$text\n($action)" else text
        updateWorkCard(running)
    }

    override fun onResume() {
        super.onResume()
        applySourceUi()
        updateBatteryButton()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
