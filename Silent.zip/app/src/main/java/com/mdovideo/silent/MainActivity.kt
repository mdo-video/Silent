package com.mdovideo.silent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var circle: FrameLayout
    private lateinit var statusIcon: ImageView
    private lateinit var statusText: TextView
    private lateinit var inputText: TextView
    private lateinit var levelView: LevelView
    private lateinit var levelText: TextView
    private lateinit var thresholdLabel: TextView
    private lateinit var delayLabel: TextView
    private lateinit var startButton: Button
    private lateinit var sourceGroup: RadioGroup
    private lateinit var radioTablet: RadioButton
    private lateinit var radioPc: RadioButton
    private lateinit var pcInfo: TextView
    private lateinit var micOptions: View
    private lateinit var workState: TextView
    private lateinit var workToday: TextView
    private lateinit var playToday: TextView
    private lateinit var weekText: TextView
    private lateinit var reportHourLabel: TextView
    private var lastWorkUi = 0L

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 80)
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (prefs.source == "pc" || hasMic()) {
                startListening()
            } else {
                Toast.makeText(this, "Serve il permesso del microfono", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        val root = findViewById<View>(R.id.root)
        val density = resources.displayMetrics.density
        val widthDp = resources.displayMetrics.widthPixels / density
        if (widthDp > 700f) {
            val pad = ((widthDp - 600f) / 2f * density).toInt()
            root.setPadding(pad, root.paddingTop, pad, root.paddingBottom)
        }

        circle = findViewById(R.id.circle)
        statusIcon = findViewById(R.id.statusIcon)
        statusText = findViewById(R.id.statusText)
        inputText = findViewById(R.id.inputText)
        levelView = findViewById(R.id.levelView)
        levelText = findViewById(R.id.levelText)
        thresholdLabel = findViewById(R.id.thresholdLabel)
        delayLabel = findViewById(R.id.delayLabel)
        startButton = findViewById(R.id.startButton)
        sourceGroup = findViewById(R.id.sourceGroup)
        radioTablet = findViewById(R.id.radioTablet)
        radioPc = findViewById(R.id.radioPc)
        pcInfo = findViewById(R.id.pcInfo)
        micOptions = findViewById(R.id.micOptions)
        workState = findViewById(R.id.workState)
        workToday = findViewById(R.id.workToday)
        playToday = findViewById(R.id.playToday)
        weekText = findViewById(R.id.weekText)
        reportHourLabel = findViewById(R.id.reportHourLabel)

        WorkLog.init(this)
        ReportScheduler.schedule(this)

        val switchReport = findViewById<SwitchCompat>(R.id.switchReport)
        val reportHourSeek = findViewById<SeekBar>(R.id.reportHourSeek)
        switchReport.isChecked = prefs.reportEnabled
        reportHourSeek.progress = prefs.reportHour
        reportHourSeek.isEnabled = prefs.reportEnabled
        updateReportLabel()
        switchReport.setOnCheckedChangeListener { _, checked ->
            prefs.reportEnabled = checked
            reportHourSeek.isEnabled = checked
            ReportScheduler.schedule(this)
        }
        reportHourSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.reportHour = p
                updateReportLabel()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                ReportScheduler.schedule(this@MainActivity)
            }
        })
        findViewById<Button>(R.id.shareReport).setOnClickListener {
            WorkLog.flush()
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "Silent - report di oggi")
                .putExtra(Intent.EXTRA_TEXT, WorkLog.reportText())
            startActivity(Intent.createChooser(send, "Condividi report"))
        }

        val thresholdSeek = findViewById<SeekBar>(R.id.thresholdSeek)
        val delaySeek = findViewById<SeekBar>(R.id.delaySeek)
        val switchExternal = findViewById<SwitchCompat>(R.id.switchExternal)
        val switchAntiEcho = findViewById<SwitchCompat>(R.id.switchAntiEcho)
        val switchSystemEcho = findViewById<SwitchCompat>(R.id.switchSystemEcho)
        val switchOnly = findViewById<SwitchCompat>(R.id.switchOnlyPlaying)
        val switchToggle = findViewById<SwitchCompat>(R.id.switchToggle)

        thresholdSeek.progress = prefs.threshold
        delaySeek.progress = prefs.delaySec - 1
        switchExternal.isChecked = prefs.externalOnly
        switchAntiEcho.isChecked = prefs.antiEcho
        switchSystemEcho.isChecked = prefs.systemEcho
        switchOnly.isChecked = prefs.onlyIfPlaying
        switchToggle.isChecked = prefs.useToggle
        updateLabels()

        thresholdSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.threshold = p
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.delaySec = p + 1
                updateLabels()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        switchExternal.setOnCheckedChangeListener { _, checked -> prefs.externalOnly = checked }
        switchAntiEcho.setOnCheckedChangeListener { _, checked -> prefs.antiEcho = checked }
        switchSystemEcho.setOnCheckedChangeListener { _, checked ->
            prefs.systemEcho = checked
            if (SilentState.running) {
                Toast.makeText(this, "Ferma e riavvia l'ascolto per applicarlo", Toast.LENGTH_SHORT).show()
            }
        }
        switchOnly.setOnCheckedChangeListener { _, checked -> prefs.onlyIfPlaying = checked }
        switchToggle.setOnCheckedChangeListener { _, checked -> prefs.useToggle = checked }

        sourceGroup.check(if (prefs.source == "pc") R.id.radioPc else R.id.radioTablet)
        applySourceUi()
        sourceGroup.setOnCheckedChangeListener { _, id ->
            prefs.source = if (id == R.id.radioPc) "pc" else "tablet"
            applySourceUi()
        }

        startButton.setOnClickListener {
            if (SilentState.running) {
                startService(
                    Intent(this, ListenService::class.java).setAction(ListenService.ACTION_STOP)
                )
            } else {
                requestAndStart()
            }
        }
        findViewById<Button>(R.id.testPause).setOnClickListener {
            MediaKeys.pause(this, prefs.useToggle)
        }
        findViewById<Button>(R.id.testPlay).setOnClickListener {
            MediaKeys.play(this, prefs.useToggle)
        }
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestAndStart() {
        val pc = prefs.source == "pc"
        val perms = mutableListOf<String>()
        if (!pc && !hasMic()) perms.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isEmpty()) {
            startListening()
        } else {
            permLauncher.launch(perms.toTypedArray())
        }
    }

    private fun startListening() {
        ContextCompat.startForegroundService(
            this, Intent(this, ListenService::class.java).setAction(ListenService.ACTION_START)
        )
    }

    private fun applySourceUi() {
        val pc = prefs.source == "pc"
        micOptions.visibility = if (pc) View.GONE else View.VISIBLE
        pcInfo.visibility = if (pc) View.VISIBLE else View.GONE
        if (pc) {
            pcInfo.text = "Nell'app Windows inserisci:\n${localIp()}  (porta ${ListenService.PC_PORT})"
        }
    }

    private fun localIp(): String {
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return "non connesso al Wi-Fi"
            for (ni in all) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: "-"
                }
            }
        } catch (e: Exception) {
        }
        return "non connesso al Wi-Fi"
    }

    private fun updateReportLabel() {
        reportHourLabel.text = "Orario report: %02d:00".format(prefs.reportHour)
    }

    private fun updateWorkCard(running: Boolean) {
        val sec = System.currentTimeMillis() / 1000L
        if (sec == lastWorkUi) return
        lastWorkUi = sec
        val day = WorkLog.today()
        val w = WorkLog.workMs(day)
        val p = WorkLog.playMs(day)
        workState.text = when {
            !running -> "Ascolto fermo: il tempo non viene registrato"
            SilentState.playingNow -> "In riproduzione: non stai lavorando"
            else -> "In pausa: stai lavorando"
        }
        workToday.text = "Lavoro oggi: ${WorkLog.fmt(w)}"
        playToday.text = "Riproduzione oggi: ${WorkLog.fmt(p)} · ${WorkLog.pct(w, p)}% lavoro"
        weekText.text = WorkLog.weekText()
    }

    private fun updateLabels() {
        thresholdLabel.text = "Soglia audio: ${prefs.threshold}"
        delayLabel.text = "Ritardo ripartenza: ${prefs.delaySec} s"
    }

    private fun refresh() {
        val running = SilentState.running
        radioTablet.isEnabled = !running
        radioPc.isEnabled = !running
        val threshold = if (running) SilentState.effectiveThreshold else prefs.threshold
        levelView.threshold = threshold
        levelView.level = if (running) SilentState.level else 0
        val tabletInfo = if (running && !SilentState.external && SilentState.ownLevel > 0 && prefs.antiEcho) {
            " · tablet ${SilentState.ownLevel}"
        } else {
            ""
        }
        levelText.text = "Livello ${if (running) SilentState.level else 0} · soglia $threshold$tabletInfo"
        inputText.text = if (running) "Ingresso: ${SilentState.inputLabel}" else "Ingresso: -"
        startButton.text = if (running) "Ferma ascolto" else "Avvia ascolto"

        val color: Int
        val icon: Int
        val text: String
        when {
            !running -> {
                color = Color.parseColor("#6B7690")
                icon = R.drawable.ic_play
                text = "Fermo"
            }
            SilentState.waiting -> {
                color = Color.parseColor("#6B7690")
                icon = R.drawable.ic_play
                text = if (prefs.source == "pc") "In attesa del flusso dal PC" else "Collega il microfono esterno"
            }
            SilentState.calibrating -> {
                color = Color.parseColor("#2ED573")
                icon = R.drawable.ic_play
                text = "Imparo il volume del tablet..."
            }
            SilentState.sound -> {
                color = Color.parseColor("#FF9F43")
                icon = R.drawable.ic_pause
                val left = SilentState.restartInMs
                text = if (left > 0) {
                    "Audio finito: riparto tra ${(left / 1000) + 1} s"
                } else {
                    "Audio rilevato: video in pausa"
                }
            }
            else -> {
                color = Color.parseColor("#2ED573")
                icon = R.drawable.ic_play
                text = "Silenzio: video attivo"
            }
        }
        circle.backgroundTintList = ColorStateList.valueOf(color)
        statusIcon.setImageResource(icon)
        val action = SilentState.lastAction
        statusText.text = if (running && action.isNotEmpty()) "$text\n($action)" else text
        updateWorkCard(running)
    }

    override fun onResume() {
        super.onResume()
        applySourceUi()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
