package com.mdovideo.silent

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent

/** Simula i tasti media, come fanno le cuffie Bluetooth. */
object MediaKeys {
    private fun send(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun pause(ctx: Context, toggle: Boolean) {
        send(ctx, if (toggle) KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE else KeyEvent.KEYCODE_MEDIA_PAUSE)
    }

    fun play(ctx: Context, toggle: Boolean) {
        send(ctx, if (toggle) KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE else KeyEvent.KEYCODE_MEDIA_PLAY)
    }
}
