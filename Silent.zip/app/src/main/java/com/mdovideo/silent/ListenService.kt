package com.mdovideo.silent

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat

class ListenService : Service() {

    companion object {
        private const val CHANNEL = "silent_listen"
        private const val NOTIF_ID = 1
        private const val SAMPLE_RATE = 16000
    }

    @Volatile private var running = false
    @Volatile private var restartInput = false
    private var worker: Thread? = null
    private var lastLoud = 0L
    private lateinit var audioManager: AudioManager
    private lateinit var prefs: Prefs

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        if (!running) {
            running = true
            SilentState.reset()
            SilentState.running = true
            audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
            worker = Thread { loop() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ascolto Silent", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Silent in ascolto")
            .setContentText("Il video va in pausa quando c'è audio")
            .setSmallIcon(R.drawable.ic_pause)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun createRecord(): AudioRecord? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return null
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4096) * 2
            )
        } catch (e: Exception) {
            return null
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return null
        }
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val usb = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        }
        val chosen = usb ?: wired
        if (chosen != null) {
            rec.setPreferredDevice(chosen)
            SilentState.inputLabel = if (usb != null) "Microfono USB" else "Ingresso a cavo"
        } else {
            SilentState.inputLabel = "Microfono interno"
        }
        return rec
    }

    private fun loop() {
        val buf = ShortArray(1024)
        while (running) {
            restartInput = false
            val rec = createRecord()
            if (rec == null) {
                SilentState.inputLabel = "Microfono non disponibile"
                pause(800)
                continue
            }
            try {
                rec.startRecording()
                while (running && !restartInput) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) break
                    handle(buf, n)
                }
            } catch (e: Exception) {
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
            }
            if (running) pause(200)
        }
    }

    private fun handle(buf: ShortArray, n: Int) {
        var sum = 0.0
        for (i in 0 until n) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        val rms = Math.sqrt(sum / n)
        val db = if (rms < 1.0) -100.0 else 20.0 * Math.log10(rms / 32768.0)
        val level = (((db + 70.0) / 70.0) * 100.0).toInt().coerceIn(0, 100)
        SilentState.level = level

        val now = SystemClock.elapsedRealtime()
        val delayMs = prefs.delaySec * 1000L
        if (level >= prefs.threshold) {
            lastLoud = now
            SilentState.restartInMs = -1L
            if (!SilentState.sound) {
                SilentState.sound = true
                onSoundStart()
            }
        } else if (SilentState.sound) {
            val remaining = delayMs - (now - lastLoud)
            if (remaining <= 0) {
                SilentState.sound = false
                SilentState.restartInMs = -1L
                onSilence()
            } else {
                SilentState.restartInMs = remaining
            }
        }
    }

    private fun onSoundStart() {
        if (!prefs.onlyIfPlaying || audioManager.isMusicActive) {
            MediaKeys.pause(this, prefs.useToggle)
            SilentState.pausedByMe = true
            SilentState.lastAction = "Pausa inviata"
        } else {
            SilentState.lastAction = "Niente in riproduzione: nessun comando"
        }
    }

    private fun onSilence() {
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
            SilentState.pausedByMe = false
            SilentState.lastAction = "Play inviato"
        }
    }

    override fun onDestroy() {
        running = false
        try {
            audioManager.unregisterAudioDeviceCallback(deviceCallback)
        } catch (e: Exception) {
        }
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
        }
        SilentState.running = false
        SilentState.reset()
        super.onDestroy()
    }
}
