package com.mdovideo.silent

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

class ListenService : Service() {

    companion object {
        private const val CHANNEL = "silent_listen"
        private const val NOTIF_ID = 1
        private const val SAMPLE_RATE = 16000
        private const val ECHO_MARGIN = 12
        const val PC_PORT = 5005
        const val ACTION_START = "com.mdovideo.silent.START"
        const val ACTION_STOP = "com.mdovideo.silent.STOP"
        const val ACTION_QUIT = "com.mdovideo.silent.QUIT"
    }

    @Volatile private var running = false
    @Volatile private var restartInput = false
    private var worker: Thread? = null
    private var lastLoud = 0L
    private var firstRecord = true
    private var foregroundSource: String? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var echoCanceler: AcousticEchoCanceler? = null

    // Registro del tempo di lavoro: ogni secondo guarda se c'è una riproduzione in corso
    private val tickHandler = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private var lastFlush = 0L
    private val workTick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.elapsedRealtime()
            val delta = (now - lastTick).coerceIn(0L, 3000L)
            lastTick = now
            val playing = audioManager.isMusicActive
            SilentState.playingNow = playing
            WorkLog.add(playing, delta)
            if (now - lastFlush >= 10_000L) {
                WorkLog.flush()
                lastFlush = now
            }
            tickHandler.postDelayed(this, 1000L)
        }
    }
    private lateinit var audioManager: AudioManager
    private lateinit var prefs: Prefs

    // Taratura del volume del tablet (anti-ritorno)
    private var calibGuardEnd = 0L
    private var calibEnd = 0L
    private var chunkStart = 0L
    private var chunkSum = 0
    private var chunkCount = 0
    private val chunks = ArrayList<Int>()

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                updateNotification()
            }
            ACTION_QUIT -> {
                stopListening()
                stopSelf()
            }
            else -> {
                ensureForeground()
                startListening()
                updateNotification()
            }
        }
        return START_NOT_STICKY
    }

    private fun startListening() {
        if (running) return
        running = true
        firstRecord = true
        SilentState.reset()
        SilentState.running = true
        audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
        if (prefs.source == "pc") acquireWifiLock()
        worker = Thread { loop() }.also { it.start() }
        WorkLog.init(this)
        lastTick = SystemClock.elapsedRealtime()
        lastFlush = lastTick
        tickHandler.postDelayed(workTick, 1000L)
    }

    private fun stopListening() {
        if (!running) return
        running = false
        tickHandler.removeCallbacks(workTick)
        WorkLog.add(
            audioManager.isMusicActive,
            (SystemClock.elapsedRealtime() - lastTick).coerceIn(0L, 3000L)
        )
        WorkLog.flush()
        try {
            audioManager.unregisterAudioDeviceCallback(deviceCallback)
        } catch (e: Exception) {
        }
        try {
            worker?.join(700)
        } catch (e: InterruptedException) {
        }
        worker = null
        releaseWifiLock()
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
        }
        SilentState.running = false
        SilentState.reset()
    }

    private fun buildNotification(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ascolto Silent", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val listening = running
        val toggle = PendingIntent.getService(
            this, 1,
            Intent(this, ListenService::class.java).setAction(if (listening) ACTION_STOP else ACTION_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quit = PendingIntent.getService(
            this, 2,
            Intent(this, ListenService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val title = if (listening) "Silent in ascolto" else "Silent fermo"
        val text = if (listening) "Il video va in pausa quando c'è audio"
        else "Tocca Avvia ascolto per riprendere"

        // Vista compatta con i pulsanti sempre visibili, anche a notifica chiusa
        val view = RemoteViews(packageName, R.layout.notif_collapsed)
        view.setTextViewText(R.id.nTitle, title)
        view.setTextViewText(R.id.nText, text)
        view.setTextViewText(R.id.nToggle, if (listening) "Ferma" else "Avvia")
        view.setOnClickPendingIntent(R.id.nToggle, toggle)
        view.setOnClickPendingIntent(R.id.nQuit, quit)

        return Notification.Builder(this, CHANNEL)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_pause)
            .setContentIntent(open)
            .setOngoing(true)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(view)
            .setCustomBigContentView(view)
            .build()
    }

    private fun ensureForeground() {
        val src = prefs.source
        if (foregroundSource == src) return
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            // In modalità PC non serve il microfono: basta il tipo "dispositivo connesso"
            val type = if (src == "pc") ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(NOTIF_ID, n, type)
        } else {
            startForeground(NOTIF_ID, n)
        }
        foregroundSource = src
    }

    private fun acquireWifiLock() {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wm.createWifiLock(mode, "silent:pc").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } catch (e: Exception) {
        }
    }

    private fun releaseWifiLock() {
        try {
            wifiLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        wifiLock = null
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun createRecord(): AudioRecord? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val usb = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        }
        val chosen = usb ?: wired

        // Modalità "solo esterno": il microfono del tablet non viene mai usato
        if (chosen == null && prefs.externalOnly) {
            SilentState.external = false
            SilentState.waiting = true
            SilentState.inputLabel = "In attesa del microfono esterno"
            return null
        }

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        val useEcho = prefs.systemEcho && chosen == null
        val source = if (useEcho) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
        val rec = try {
            AudioRecord(
                source, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4096) * 2
            )
        } catch (e: Exception) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        SilentState.waiting = false
        if (chosen != null) {
            rec.setPreferredDevice(chosen)
            SilentState.external = true
            SilentState.calibrating = false
            SilentState.ownLevel = 0
            SilentState.inputLabel = if (usb != null) "Microfono USB" else "Ingresso a cavo"
        } else {
            SilentState.external = false
            var note = ""
            if (useEcho) {
                note = if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
                        if (echoCanceler != null) " · eco di sistema attivo" else " · eco di sistema non disponibile"
                    } catch (e: Exception) {
                        " · eco di sistema non disponibile"
                    }
                } else {
                    " · eco di sistema non disponibile"
                }
            }
            SilentState.inputLabel = "Microfono interno$note"
        }
        return rec
    }

    private fun loop() {
        if (prefs.source == "pc") {
            pcLoop()
            return
        }
        val buf = ShortArray(1024)
        while (running) {
            restartInput = false
            val rec = createRecord()
            if (rec == null) {
                process(0)
                pause(800)
                continue
            }
            if (firstRecord) {
                firstRecord = false
                if (audioManager.isMusicActive) startCalibration(0L, 3000L)
            }
            try {
                rec.startRecording()
                while (running && !restartInput) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) break
                    handle(buf, n)
                }
            } catch (e: Exception) {
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
                try {
                    echoCanceler?.release()
                } catch (e: Exception) {
                }
                echoCanceler = null
            }
            if (running) pause(200)
        }
    }

    /** Modalità PC: riceve via UDP l'audio PCM 16 bit mono 16 kHz inviato dall'app Windows. */
    private fun pcLoop() {
        val bytes = ByteArray(8192)
        val samples = ShortArray(4096)
        val packet = DatagramPacket(bytes, bytes.size)
        while (running) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(PC_PORT))
                    soTimeout = 300
                }
                // Nessuna taratura del tablet: l'audio arriva dalla rete, non dal microfono
                SilentState.external = true
                SilentState.calibrating = false
                SilentState.ownLevel = 0
                SilentState.waiting = true
                SilentState.inputLabel = "In attesa del PC"
                var lastPacket = 0L
                while (running) {
                    try {
                        packet.length = bytes.size
                        socket.receive(packet)
                        lastPacket = SystemClock.elapsedRealtime()
                        val n = packet.length / 2
                        for (i in 0 until n) {
                            samples[i] = ((bytes[2 * i + 1].toInt() shl 8) or (bytes[2 * i].toInt() and 0xFF)).toShort()
                        }
                        SilentState.pcConnected = true
                        SilentState.waiting = false
                        SilentState.inputLabel = "Flusso dal PC"
                        handle(samples, n)
                    } catch (e: SocketTimeoutException) {
                        if (SystemClock.elapsedRealtime() - lastPacket > 2000L) {
                            SilentState.pcConnected = false
                            SilentState.waiting = true
                            SilentState.inputLabel = "In attesa del PC"
                        }
                        process(0)
                    }
                }
            } catch (e: Exception) {
                SilentState.pcConnected = false
                SilentState.waiting = true
                SilentState.inputLabel = "Rete non disponibile"
                process(0)
                pause(800)
            } finally {
                try {
                    socket?.close()
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun handle(buf: ShortArray, n: Int) {
        var sum = 0.0
        for (i in 0 until n) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        val rms = Math.sqrt(sum / n)
        val db = if (rms < 1.0) -100.0 else 20.0 * Math.log10(rms / 32768.0)
        val level = (((db + 70.0) / 70.0) * 100.0).toInt().coerceIn(0, 100)
        process(level)
    }

    private fun updateEffectiveThreshold() {
        val base = prefs.threshold
        SilentState.effectiveThreshold =
            if (!SilentState.external && prefs.antiEcho && SilentState.ownLevel > 0) {
                minOf(95, maxOf(base, SilentState.ownLevel + ECHO_MARGIN))
            } else {
                base
            }
    }

    private fun startCalibration(guardMs: Long, calibMs: Long) {
        if (SilentState.external || !prefs.antiEcho) return
        val now = SystemClock.elapsedRealtime()
        calibGuardEnd = now + guardMs
        calibEnd = calibGuardEnd + calibMs
        chunkStart = calibGuardEnd
        chunkSum = 0
        chunkCount = 0
        chunks.clear()
        SilentState.calibrating = true
    }

    private fun finishCalibration() {
        if (chunkCount > 0) chunks.add(chunkSum / chunkCount)
        if (chunks.isNotEmpty()) {
            val sorted = chunks.sorted()
            SilentState.ownLevel = sorted[sorted.size / 2]
        }
        SilentState.calibrating = false
    }

    private fun process(level: Int) {
        SilentState.level = level
        val now = SystemClock.elapsedRealtime()

        if (SilentState.calibrating) {
            if (now < calibEnd) {
                if (now >= calibGuardEnd) {
                    chunkSum += level
                    chunkCount++
                    if (now - chunkStart >= 500L) {
                        if (chunkCount > 0) chunks.add(chunkSum / chunkCount)
                        chunkSum = 0
                        chunkCount = 0
                        chunkStart = now
                    }
                }
                updateEffectiveThreshold()
                return
            }
            finishCalibration()
        }

        updateEffectiveThreshold()
        val threshold = SilentState.effectiveThreshold
        val delayMs = prefs.delaySec * 1000L
        if (level >= threshold) {
            lastLoud = now
            SilentState.restartInMs = -1L
            if (!SilentState.sound) {
                SilentState.sound = true
                onSoundStart()
            }
        } else if (SilentState.sound) {
            val remaining = delayMs - (now - lastLoud)
            if (remaining <= 0) {
                SilentState.sound = false
                SilentState.restartInMs = -1L
                onSilence()
            } else {
                SilentState.restartInMs = remaining
            }
        }
    }

    private fun onSoundStart() {
        if (!prefs.onlyIfPlaying || audioManager.isMusicActive) {
            MediaKeys.pause(this, prefs.useToggle)
            SilentState.pausedByMe = true
            SilentState.lastAction = "Pausa inviata"
        } else {
            SilentState.lastAction = "Niente in riproduzione: nessun comando"
        }
    }

    private fun onSilence() {
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
            SilentState.pausedByMe = false
            SilentState.lastAction = "Play inviato"
            // Il video riparte: impara quanto suona il tablet per ignorarlo
            startCalibration(1500L, 2500L)
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}
