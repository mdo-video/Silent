package com.mdovideo.silent

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat

class ListenService : Service() {

    companion object {
        private const val CHANNEL = "silent_listen"
        private const val NOTIF_ID = 1
        private const val SAMPLE_RATE = 16000
        private const val ECHO_MARGIN = 12
        const val ACTION_START = "com.mdovideo.silent.START"
        const val ACTION_STOP = "com.mdovideo.silent.STOP"
        const val ACTION_QUIT = "com.mdovideo.silent.QUIT"
    }

    @Volatile private var running = false
    @Volatile private var restartInput = false
    private var worker: Thread? = null
    private var lastLoud = 0L
    private var firstRecord = true
    private var foregroundStarted = false
    private var echoCanceler: AcousticEchoCanceler? = null
    private lateinit var audioManager: AudioManager
    private lateinit var prefs: Prefs

    // Taratura del volume del tablet (anti-ritorno)
    private var calibGuardEnd = 0L
    private var calibEnd = 0L
    private var chunkStart = 0L
    private var chunkSum = 0
    private var chunkCount = 0
    private val chunks = ArrayList<Int>()

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            restartInput = true
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                updateNotification()
            }
            ACTION_QUIT -> {
                stopListening()
                stopSelf()
            }
            else -> {
                ensureForeground()
                startListening()
                updateNotification()
            }
        }
        return START_NOT_STICKY
    }

    private fun startListening() {
        if (running) return
        running = true
        firstRecord = true
        SilentState.reset()
        SilentState.running = true
        audioManager.registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
        worker = Thread { loop() }.also { it.start() }
    }

    private fun stopListening() {
        if (!running) return
        running = false
        try {
            audioManager.unregisterAudioDeviceCallback(deviceCallback)
        } catch (e: Exception) {
        }
        try {
            worker?.join(700)
        } catch (e: InterruptedException) {
        }
        worker = null
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
        }
        SilentState.running = false
        SilentState.reset()
    }

    private fun buildNotification(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ascolto Silent", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val listening = running
        val toggle = PendingIntent.getService(
            this, 1,
            Intent(this, ListenService::class.java).setAction(if (listening) ACTION_STOP else ACTION_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quit = PendingIntent.getService(
            this, 2,
            Intent(this, ListenService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIcon = Icon.createWithResource(
            this, if (listening) R.drawable.ic_pause else R.drawable.ic_play
        )
        val quitIcon = Icon.createWithResource(this, R.drawable.ic_close)
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(if (listening) "Silent in ascolto" else "Silent fermo")
            .setContentText(
                if (listening) "Il video va in pausa quando c'è audio"
                else "Tocca Avvia ascolto per riprendere"
            )
            .setSmallIcon(R.drawable.ic_pause)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    toggleIcon, if (listening) "Ferma ascolto" else "Avvia ascolto", toggle
                ).build()
            )
            .addAction(Notification.Action.Builder(quitIcon, "Chiudi", quit).build())
            .build()
    }

    private fun ensureForeground() {
        if (foregroundStarted) return
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        foregroundStarted = true
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
        }
    }

    private fun createRecord(): AudioRecord? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val usb = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        }
        val chosen = usb ?: wired

        // Modalità "solo esterno": il microfono del tablet non viene mai usato
        if (chosen == null && prefs.externalOnly) {
            SilentState.external = false
            SilentState.waiting = true
            SilentState.inputLabel = "In attesa del microfono esterno"
            return null
        }

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        val useEcho = prefs.systemEcho && chosen == null
        val source = if (useEcho) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC
        val rec = try {
            AudioRecord(
                source, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4096) * 2
            )
        } catch (e: Exception) {
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            SilentState.waiting = false
            SilentState.inputLabel = "Microfono non disponibile"
            return null
        }
        SilentState.waiting = false
        if (chosen != null) {
            rec.setPreferredDevice(chosen)
            SilentState.external = true
            SilentState.calibrating = false
            SilentState.ownLevel = 0
            SilentState.inputLabel = if (usb != null) "Microfono USB" else "Ingresso a cavo"
        } else {
            SilentState.external = false
            var note = ""
            if (useEcho) {
                note = if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(rec.audioSessionId)?.also { it.enabled = true }
                        if (echoCanceler != null) " · eco di sistema attivo" else " · eco di sistema non disponibile"
                    } catch (e: Exception) {
                        " · eco di sistema non disponibile"
                    }
                } else {
                    " · eco di sistema non disponibile"
                }
            }
            SilentState.inputLabel = "Microfono interno$note"
        }
        return rec
    }

    private fun loop() {
        val buf = ShortArray(1024)
        while (running) {
            restartInput = false
            val rec = createRecord()
            if (rec == null) {
                process(0)
                pause(800)
                continue
            }
            if (firstRecord) {
                firstRecord = false
                if (audioManager.isMusicActive) startCalibration(0L, 3000L)
            }
            try {
                rec.startRecording()
                while (running && !restartInput) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n <= 0) break
                    handle(buf, n)
                }
            } catch (e: Exception) {
            } finally {
                try {
                    rec.stop()
                } catch (e: Exception) {
                }
                rec.release()
                try {
                    echoCanceler?.release()
                } catch (e: Exception) {
                }
                echoCanceler = null
            }
            if (running) pause(200)
        }
    }

    private fun handle(buf: ShortArray, n: Int) {
        var sum = 0.0
        for (i in 0 until n) {
            val s = buf[i].toDouble()
            sum += s * s
        }
        val rms = Math.sqrt(sum / n)
        val db = if (rms < 1.0) -100.0 else 20.0 * Math.log10(rms / 32768.0)
        val level = (((db + 70.0) / 70.0) * 100.0).toInt().coerceIn(0, 100)
        process(level)
    }

    private fun updateEffectiveThreshold() {
        val base = prefs.threshold
        SilentState.effectiveThreshold =
            if (!SilentState.external && prefs.antiEcho && SilentState.ownLevel > 0) {
                minOf(95, maxOf(base, SilentState.ownLevel + ECHO_MARGIN))
            } else {
                base
            }
    }

    private fun startCalibration(guardMs: Long, calibMs: Long) {
        if (SilentState.external || !prefs.antiEcho) return
        val now = SystemClock.elapsedRealtime()
        calibGuardEnd = now + guardMs
        calibEnd = calibGuardEnd + calibMs
        chunkStart = calibGuardEnd
        chunkSum = 0
        chunkCount = 0
        chunks.clear()
        SilentState.calibrating = true
    }

    private fun finishCalibration() {
        if (chunkCount > 0) chunks.add(chunkSum / chunkCount)
        if (chunks.isNotEmpty()) {
            val sorted = chunks.sorted()
            SilentState.ownLevel = sorted[sorted.size / 2]
        }
        SilentState.calibrating = false
    }

    private fun process(level: Int) {
        SilentState.level = level
        val now = SystemClock.elapsedRealtime()

        if (SilentState.calibrating) {
            if (now < calibEnd) {
                if (now >= calibGuardEnd) {
                    chunkSum += level
                    chunkCount++
                    if (now - chunkStart >= 500L) {
                        if (chunkCount > 0) chunks.add(chunkSum / chunkCount)
                        chunkSum = 0
                        chunkCount = 0
                        chunkStart = now
                    }
                }
                updateEffectiveThreshold()
                return
            }
            finishCalibration()
        }

        updateEffectiveThreshold()
        val threshold = SilentState.effectiveThreshold
        val delayMs = prefs.delaySec * 1000L
        if (level >= threshold) {
            lastLoud = now
            SilentState.restartInMs = -1L
            if (!SilentState.sound) {
                SilentState.sound = true
                onSoundStart()
            }
        } else if (SilentState.sound) {
            val remaining = delayMs - (now - lastLoud)
            if (remaining <= 0) {
                SilentState.sound = false
                SilentState.restartInMs = -1L
                onSilence()
            } else {
                SilentState.restartInMs = remaining
            }
        }
    }

    private fun onSoundStart() {
        if (!prefs.onlyIfPlaying || audioManager.isMusicActive) {
            MediaKeys.pause(this, prefs.useToggle)
            SilentState.pausedByMe = true
            SilentState.lastAction = "Pausa inviata"
        } else {
            SilentState.lastAction = "Niente in riproduzione: nessun comando"
        }
    }

    private fun onSilence() {
        if (SilentState.pausedByMe) {
            MediaKeys.play(this, prefs.useToggle)
            SilentState.pausedByMe = false
            SilentState.lastAction = "Play inviato"
            // Il video riparte: impara quanto suona il tablet per ignorarlo
            startCalibration(1500L, 2500L)
        }
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}
