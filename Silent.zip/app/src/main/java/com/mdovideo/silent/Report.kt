package com.mdovideo.silent

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Pianifica e mostra la notifica con il report giornaliero. */
object ReportScheduler {
    private const val CHANNEL = "silent_report"
    private const val NOTIF_ID = 2

    private fun alarmIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 10, Intent(ctx, ReportReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Programma (o annulla) il prossimo report all'ora scelta. */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmIntent(ctx)
        val prefs = Prefs(ctx)
        if (!prefs.reportEnabled) {
            am.cancel(pi)
            return
        }
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, prefs.reportHour)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 60_000L) {
            c.add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }

    fun notifyReport(ctx: Context) {
        WorkLog.init(ctx)
        WorkLog.flush()
        val mgr = ctx.getSystemService(NotificationManager::class.java)
        mgr.createNotificationChannel(
            NotificationChannel(CHANNEL, "Report giornaliero", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            ctx, 3, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val text = WorkLog.summary(WorkLog.today())
        val n = Notification.Builder(ctx, CHANNEL)
            .setContentTitle("Report di oggi")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text + "\n\n" + WorkLog.weekText()))
            .setSmallIcon(R.drawable.ic_pause)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        mgr.notify(NOTIF_ID, n)
    }
}

class ReportReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Prefs(ctx).reportEnabled) ReportScheduler.notifyReport(ctx)
        ReportScheduler.schedule(ctx)
    }
}

/** Dopo un riavvio del telefono riprogramma il report. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        ReportScheduler.schedule(ctx)
    }
}
