"""
Silent PC - invia l'audio del PC al tablet e comanda l'app Silent da qui.

Cosa fa:
- Trova da solo il tablet sulla rete (nessun IP da scrivere). Se vuoi, l'IP si puo' ancora inserire a mano.
- Invia l'audio (UDP, PCM 16 bit mono 16 kHz, porta 5005). Se il PC e' muto manda silenzio,
  cosi' il tablet sa che sei collegato.
- Canale di controllo (UDP, porta 5006): soglia, ritardo di ripartenza, "pausa solo se sta
  suonando qualcosa", "tasto unico play/pausa", Prova pausa / Prova play, avvia / ferma.
  Quello che cambi sul PC si vede sul tablet e viceversa.
- Aggiornamento automatico (OTA) dell'exe dalle release GitHub.

Per usarlo come script:  pip install pyaudiowpatch numpy   poi   python Silent.py
"""
import base64
import ctypes
import ctypes.wintypes
import hashlib
import json
import os
import queue
import re
import socket
import datetime
import struct
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
import zlib
from tkinter import ttk

import numpy as np

try:
    import pyaudiowpatch as pyaudio
except ImportError:  # messaggio chiaro invece di un errore criptico
    pyaudio = None

try:
    from build_info import BUILD
except Exception:
    BUILD = 0

PORT = 5005          # audio verso il tablet
CTRL_PORT = 5006     # controllo e scoperta del tablet
OUT_RATE = 16000
PACKET_SAMPLES = 512
CONFIG = os.path.join(os.path.expanduser("~"), ".silent_pc_sender.json")
REPO = "mdo-video/Silent"
API_LATEST = "https://api.github.com/repos/%s/releases/latest" % REPO
EXE_ASSET = "Silent-PC.exe"

DEFAULT_LABEL = "Audio del PC - uscita predefinita (consigliato)"

BG = "#0F1420"
CARD = "#1A2132"
TRACK = "#232C42"
TRACK2 = "#2D3858"
BTN2 = "#34457A"       # tasti secondari attivi
DIS_FILL = "#141A2A"   # tasti disattivati: sfondo scuro
DIS_FG = "#4A5470"     # tasti disattivati: testo spento
WHITE = "#FFFFFF"
GREY = "#6B7690"
LIGHT = "#A7B1C9"
ORANGE = "#FF9F43"
GREEN = "#2ED573"
COLORS = {"grey": GREY, "green": GREEN, "orange": ORANGE}


# ------------------------------------------------------------------ icona

def make_icon_png(size):
    """Logo di Silent (pausa arancione su fondo scuro) come PNG RGBA, senza librerie esterne."""
    ss = 4
    n = size * ss
    yy, xx = np.mgrid[0:n, 0:n]
    u = (xx + 0.5) / n * 108.0
    v = (yy + 0.5) / n * 108.0

    def rr(x1, y1, x2, y2, r):
        qx = np.abs(u - (x1 + x2) / 2) - ((x2 - x1) / 2 - r)
        qy = np.abs(v - (y1 + y2) / 2) - ((y2 - y1) / 2 - r)
        d = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
        return (d <= 0).astype(np.float32)

    tile = rr(2, 2, 106, 106, 24)
    bars = np.maximum(rr(33, 27, 51, 81, 4), rr(57, 27, 75, 81, 4)) * tile
    bg = np.array([0x0F, 0x14, 0x20], dtype=np.float32)
    fg = np.array([0xFF, 0x9F, 0x43], dtype=np.float32)
    rgb = bg[None, None, :] * (tile - bars)[:, :, None] + fg[None, None, :] * bars[:, :, None]
    pre = np.concatenate((rgb, (tile * 255.0)[:, :, None]), axis=2)
    pre = pre.reshape(size, ss, size, ss, 4).mean(axis=(1, 3))
    a = pre[:, :, 3]
    out = np.zeros((size, size, 4), dtype=np.uint8)
    nz = a > 0
    for c in range(3):
        ch = np.zeros_like(a)
        ch[nz] = pre[:, :, c][nz] / (a[nz] / 255.0)
        out[:, :, c] = np.clip(ch, 0, 255).astype(np.uint8)
    out[:, :, 3] = np.clip(a, 0, 255).astype(np.uint8)
    return out


def png_bytes(rgba):
    size = rgba.shape[0]
    raw = b"".join(b"\x00" + rgba[y].tobytes() for y in range(size))

    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9))
            + chunk(b"IEND", b""))


def dib_bytes(rgba):
    """Immagine BMP (DIB 32 bit con maschera) per le icone .ico piccole."""
    size = rgba.shape[0]
    bgra = rgba[:, :, [2, 1, 0, 3]][::-1]
    header = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0, 0, 0, 0, 0, 0)
    row = ((size + 31) // 32) * 4
    return header + bgra.tobytes() + bytes(row * size)


def write_ico(path):
    entries = []
    for s in (16, 24, 32, 48, 64, 128, 256):
        rgba = make_icon_png(s)
        entries.append((s, png_bytes(rgba) if s >= 128 else dib_bytes(rgba)))
    head = struct.pack("<HHH", 0, 1, len(entries))
    offset = 6 + 16 * len(entries)
    dirs, blobs = b"", b""
    for s, data in entries:
        dirs += struct.pack("<BBBBHHII", 0 if s >= 256 else s, 0 if s >= 256 else s, 0, 0, 1, 32, len(data), offset)
        blobs += data
        offset += len(data)
    with open(path, "wb") as f:
        f.write(head + dirs + blobs)


def resource_path(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


# ------------------------------------------------------------------ configurazione

def load_config():
    try:
        with open(CONFIG, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    try:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
    except Exception:
        pass


# ------------------------------------------------------------------ rete

IPV4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def resolve_host(text):
    """Accetta un IP o un nome di rete e restituisce l'IP, oppure None."""
    try:
        return socket.gethostbyname(text)
    except Exception:
        return None


def local_ips():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    return [i for i in ips if not i.startswith("127.") and not i.startswith("169.254.")]


def broadcast_targets():
    out = ["255.255.255.255"]
    for ip in local_ips():
        p = ip.split(".")
        if len(p) == 4:
            out.append(".".join(p[:3] + ["255"]))
    return list(dict.fromkeys(out))


class Control:
    """Canale di controllo col tablet: scoperta automatica, stato in tempo reale, comandi."""

    def __init__(self):
        self.sock = None
        self.running = False
        self.lock = threading.Lock()
        self.seen = {}       # ip -> {name, build, t}
        self.statuses = {}   # ip -> (dict, t)
        self.reports = {}    # ip -> (dict, t)
        self.manual = None   # IP scelto a mano; None = automatico
        self.pin = ""        # PIN di abbinamento col tablet (vuoto = nessuno)
        self.last_ip = None
        self.hostname = socket.gethostname()

    def start(self):
        if self.running:
            return
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        for opt in (socket.SO_REUSEADDR, socket.SO_BROADCAST):
            try:
                s.setsockopt(socket.SOL_SOCKET, opt, 1)
            except Exception:
                pass
        try:  # Windows: non dare errore quando un pacchetto UDP trova la porta chiusa
            s.ioctl(socket.SIO_UDP_CONNRESET, False)
        except Exception:
            pass
        s.settimeout(0.3)
        try:
            s.bind(("", CTRL_PORT))
        except OSError:
            s.bind(("", 0))
        self.sock = s
        self.running = True
        threading.Thread(target=self._recv, daemon=True).start()
        threading.Thread(target=self._hello, daemon=True).start()

    def close(self):
        if not self.running:
            return
        self.send({"cmd": "bye"})
        self.running = False
        try:
            self.sock.close()
        except Exception:
            pass

    def _send_raw(self, data, ip):
        try:
            self.sock.sendto(data, (ip, CTRL_PORT))
        except Exception:
            pass

    def send(self, cmd):
        ip = self.target_ip()
        if ip and self.sock is not None:
            if self.pin:
                cmd = dict(cmd, pin=self.pin)
            self._send_raw(json.dumps(cmd).encode("utf-8"), ip)

    def _recv(self):
        while self.running:
            try:
                data, addr = self.sock.recvfrom(4096)
            except socket.timeout:
                continue
            except ConnectionResetError:
                continue
            except OSError:
                if not self.running:
                    break
                time.sleep(0.2)
                continue
            try:
                j = json.loads(data.decode("utf-8", "ignore"))
            except Exception:
                continue
            if not isinstance(j, dict) or j.get("type") not in ("beacon", "status", "report"):
                continue
            ip, now = addr[0], time.monotonic()
            if j.get("type") == "report":
                with self.lock:
                    self.reports[ip] = (j, now)
                continue
            try:
                build = int(j.get("build", 0) or 0)
            except Exception:
                build = 0
            with self.lock:
                self.seen[ip] = {"name": str(j.get("name", "Tablet")), "build": build, "t": now,
                                 "lock": bool(j.get("lock"))}
                if j.get("type") == "status":
                    self.statuses[ip] = (j, now)

    def _hello(self):
        while self.running:
            hello = {"cmd": "hello", "name": self.hostname, "build": BUILD}
            if self.pin:
                hello["pin"] = self.pin
            msg = json.dumps(hello).encode("utf-8")
            ip = self.target_ip()
            targets = [ip] if ip else []
            if self.status() is None and not self.manual:
                targets += broadcast_targets()  # ricerca: chiamo tutta la rete
            for t in targets:
                self._send_raw(msg, t)
            time.sleep(1.0)

    def target_ip(self):
        if self.manual:
            return self.manual
        now = time.monotonic()
        with self.lock:
            fresh = [(v["t"], ip) for ip, v in self.seen.items() if now - v["t"] < 8.0]
        if fresh:
            if self.last_ip in [ip for _, ip in fresh]:
                return self.last_ip
            self.last_ip = max(fresh)[1]
        return self.last_ip

    def status(self, max_age=2.5):
        ip = self.target_ip()
        if not ip:
            return None
        with self.lock:
            item = self.statuses.get(ip)
        if item and time.monotonic() - item[1] <= max_age:
            return item[0]
        return None

    def report(self):
        """Ultimo registro del lavoro ricevuto dal tablet: (dict, istante) oppure None."""
        ip = self.target_ip()
        with self.lock:
            return self.reports.get(ip) if ip else None

    def is_locked(self):
        """True se il tablet e' protetto da PIN e non ci risponde (PIN mancante o sbagliato)."""
        ip = self.target_ip()
        if not ip or self.status() is not None:
            return False
        with self.lock:
            v = self.seen.get(ip)
        return bool(v and v.get("lock") and time.monotonic() - v["t"] < 8.0)

    def tablet_name(self):
        ip = self.target_ip()
        with self.lock:
            v = self.seen.get(ip)
        return v["name"] if v else "Tablet"


# ------------------------------------------------------------------ audio

def list_devices(p):
    """Ritorna ([(etichetta, info_dispositivo)], indice_predefinito).

    Il primo elemento ha info None: significa "segui l'uscita predefinita di Windows".
    """
    devices = []
    try:
        wasapi = p.get_host_api_info_by_type(pyaudio.paWASAPI)
    except Exception:
        return devices, 0
    devices.append((DEFAULT_LABEL, None))
    for lb in p.get_loopback_device_info_generator():
        devices.append(("Audio del PC - " + lb["name"].replace(" [Loopback]", ""), lb))
    for i in range(p.get_device_count()):
        d = p.get_device_info_by_index(i)
        if (d["hostApi"] == wasapi["index"] and d["maxInputChannels"] > 0
                and not d.get("isLoopbackDevice", False)):
            devices.append(("Microfono - " + d["name"], d))
    return devices, 0


class StreamResampler:
    """Ricampionamento in streaming (media su finestre frazionarie), senza salti tra i blocchi."""

    def __init__(self, in_rate, out_rate):
        self.ratio = in_rate / float(out_rate)
        self.buf = np.zeros(0, dtype=np.float64)
        self.pos = 0.0

    def process(self, x):
        self.buf = np.concatenate((self.buf, x.astype(np.float64)))
        n_out = int((len(self.buf) - self.pos) // self.ratio)
        if n_out <= 0:
            return np.zeros(0, dtype=np.float32)
        edges = self.pos + np.arange(n_out + 1) * self.ratio
        csum = np.concatenate(([0.0], np.cumsum(self.buf)))
        ci = np.interp(edges, np.arange(len(csum)), csum)
        out = np.diff(ci) / self.ratio
        end = edges[-1]
        drop = int(end)
        self.buf = self.buf[drop:]
        self.pos = end - drop
        return out.astype(np.float32)


class Sender:
    """Cattura l'audio e lo spedisce in UDP al tablet."""

    def __init__(self):
        self.p = None
        self.stream = None
        self.sock = None
        self.q = queue.Queue(maxsize=256)
        self.thread = None
        self.running = False
        self.level = 0
        self.error = ""
        self.audio_msg = ""
        self.device = None
        self.follow_default = False
        self.current_index = None
        self.channels = 2
        self.rate = 48000
        self.resampler = None
        self.target = None

    def start(self, device, ip):
        self.error = ""
        self.audio_msg = ""
        self.device = device
        self.follow_default = device is None
        self.target = (ip, PORT)
        self.q = queue.Queue(maxsize=256)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            self.sock.ioctl(socket.SIO_UDP_CONNRESET, False)
        except Exception:
            pass
        self._open_stream()  # se fallisce, l'eccezione arriva alla finestra
        self.running = True
        self.thread = threading.Thread(target=self._send_loop, daemon=True)
        self.thread.start()

    def set_target(self, ip):
        if self.running and ip and (not self.target or self.target[0] != ip):
            self.target = (ip, PORT)

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=1.5)
        self._close_stream()
        try:
            if self.sock is not None:
                self.sock.close()
        except Exception:
            pass
        self.sock = self.thread = None
        self.level = 0
        self.audio_msg = ""

    def _callback(self, in_data, frame_count, time_info, status):
        try:
            self.q.put_nowait(in_data)
        except queue.Full:
            pass  # meglio perdere un blocco che accumulare ritardo
        return (None, pyaudio.paContinue)

    def _open_stream(self):
        self._close_stream()
        p = pyaudio.PyAudio()
        try:
            dev = self.device if self.device is not None else p.get_default_wasapi_loopback()
            channels = max(1, int(dev["maxInputChannels"]))
            rate = int(dev["defaultSampleRate"])
            stream = p.open(format=pyaudio.paInt16, channels=channels, rate=rate,
                            frames_per_buffer=1024, input=True,
                            input_device_index=int(dev["index"]),
                            stream_callback=self._callback)
        except Exception:
            p.terminate()
            raise
        self.p = p
        self.stream = stream
        self.channels = channels
        self.rate = rate
        self.current_index = int(dev["index"])
        self.resampler = StreamResampler(rate, OUT_RATE)

    def _close_stream(self):
        try:
            if self.stream is not None:
                self.stream.stop_stream()
                self.stream.close()
        except Exception:
            pass
        try:
            if self.p is not None:
                self.p.terminate()
        except Exception:
            pass
        self.stream = None
        self.p = None

    def _default_index(self):
        p = pyaudio.PyAudio()
        try:
            return int(p.get_default_wasapi_loopback()["index"])
        except Exception:
            return None
        finally:
            p.terminate()

    def _health_check(self):
        """Riapre lo stream se si e' fermato o se l'uscita predefinita di Windows e' cambiata."""
        try:
            reopen = False
            if self.stream is None or not self.stream.is_active():
                reopen = True
            elif self.follow_default:
                idx = self._default_index()
                if idx is not None and idx != self.current_index:
                    reopen = True
            if reopen:
                self.audio_msg = "Riconnessione audio..."
                self._open_stream()
                self.audio_msg = ""
        except Exception as e:
            self.audio_msg = "Audio non disponibile, riprovo (%s)" % e

    def _to_mono(self, data):
        a = np.frombuffer(data, dtype=np.int16)
        if self.channels > 1:
            a = a[: len(a) - len(a) % self.channels].reshape(-1, self.channels)
            return a.astype(np.float32).mean(axis=1)
        return a.astype(np.float32)

    def _send_loop(self):
        buf = np.zeros(0, dtype=np.int16)
        silence = bytes(PACKET_SAMPLES * 2)
        last_check = time.monotonic()
        while self.running:
            now = time.monotonic()
            if now - last_check >= 2.0:
                last_check = now
                self._health_check()
            try:
                data = self.q.get(timeout=0.1)
            except queue.Empty:
                # Il loopback di Windows non produce dati quando non c'e' audio:
                # mando silenzio per far sapere a Silent che sono collegato.
                self.level = 0
                self._send(silence)
                continue
            mono = self._to_mono(data)
            if len(mono) == 0 or self.resampler is None:
                continue
            out = np.clip(self.resampler.process(mono), -32768, 32767).astype(np.int16)
            buf = np.concatenate((buf, out))
            while len(buf) >= PACKET_SAMPLES:
                chunk, buf = buf[:PACKET_SAMPLES], buf[PACKET_SAMPLES:]
                rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))
                db = -100.0 if rms < 1.0 else 20.0 * np.log10(rms / 32768.0)
                self.level = int(min(100, max(0, (db + 70.0) / 70.0 * 100.0)))
                self._send(chunk.astype("<i2").tobytes())

    def _send(self, payload):
        try:
            self.sock.sendto(payload, self.target)
            self.error = ""
        except Exception as e:  # rete assente o IP errato
            self.error = str(e)


# ------------------------------------------------------------------ aggiornamenti (OTA)

def is_frozen():
    return bool(getattr(sys, "frozen", False))


def check_update():
    """Ritorna (build_online, url_exe_o_None, sha256_o_None). Solleva eccezione se la rete non risponde."""
    req = urllib.request.Request(API_LATEST, headers={
        "User-Agent": "Silent-PC", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        j = json.loads(r.read().decode("utf-8"))
    digits = "".join(c for c in str(j.get("tag_name", "")) if c.isdigit())
    build = int(digits) if digits else 0
    url = None
    sha = None
    for a in j.get("assets", []):
        if a.get("name") == EXE_ASSET:
            url = a.get("browser_download_url")
            # GitHub pubblica l'hash dell'asset nel campo "digest" (es. "sha256:abc...")
            d = str(a.get("digest") or "").lower()
            if d.startswith("sha256:") and len(d) == 71:
                sha = d[7:]
    return build, url, sha


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(65536)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def download_file(url, dest, progress):
    req = urllib.request.Request(url, headers={"User-Agent": "Silent-PC"})
    with urllib.request.urlopen(req, timeout=30) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length", "0") or 0)
        got = 0
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b)
            got += len(b)
            if total:
                progress(int(got * 100 / total))


def apply_update(new_path):
    """Sostituisce l'exe in uso con quello scaricato e lo riavvia (tramite un .bat)."""
    exe = sys.executable
    bat = os.path.join(os.path.dirname(new_path), "silent_update.bat")
    script = (
        "@echo off\r\n"
        "set PYINSTALLER_RESET_ENVIRONMENT=1\r\n"
        "set n=0\r\n"
        ":wait\r\n"
        "ping 127.0.0.1 -n 2 >nul\r\n"
        "move /y \"%s\" \"%s\" >nul 2>&1\r\n"
        "if not errorlevel 1 goto done\r\n"
        "set /a n+=1\r\n"
        "if %%n%% lss 40 goto wait\r\n"
        "goto end\r\n"
        ":done\r\n"
        "start \"\" \"%s\"\r\n"
        ":end\r\n"
        "del \"%%~f0\"\r\n"
    ) % (new_path, exe, exe)
    with open(bat, "w", encoding="mbcs", errors="replace") as f:
        f.write(script)
    env = dict(os.environ)
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    env.pop("_MEIPASS2", None)
    subprocess.Popen(["cmd", "/c", bat], env=env, close_fds=True,
                     creationflags=0x00000008 | 0x08000000)  # DETACHED_PROCESS | CREATE_NO_WINDOW


# ------------------------------------------------------------------ tray e avvio con Windows

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "SilentPC"


def startup_command():
    """Comando da lanciare all'accesso a Windows (parte direttamente nella tray)."""
    if is_frozen():
        return '"%s" --tray' % sys.executable
    py = sys.executable
    pyw = os.path.join(os.path.dirname(py), "pythonw.exe")
    if os.path.exists(pyw):
        py = pyw
    return '"%s" "%s" --tray' % (py, os.path.abspath(__file__))


def startup_enabled():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, RUN_NAME)
        return True
    except Exception:
        return False


def set_startup(on):
    """Attiva/disattiva l'avvio con Windows. Ritorna True se riuscito."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, RUN_NAME, 0, winreg.REG_SZ, startup_command())
            else:
                try:
                    winreg.DeleteValue(k, RUN_NAME)
                except FileNotFoundError:
                    pass
        return True
    except Exception:
        return False


class TrayIcon:
    """Icona nell'area di notifica di Windows, solo con ctypes (nessuna dipendenza in piu').

    Gira in un thread suo, con una finestra nascosta che riceve i clic. Non tocca mai Tk:
    manda gli eventi ("show", "toggle", "quit") a on_event, che li mette in coda.
    """
    WM_TRAY = 0x0400 + 20
    WM_STOP = 0x0400 + 21

    def __init__(self, tip, ico_path, on_event, toggle_label):
        self.tip, self.ico_path = tip, ico_path
        self.on_event, self.toggle_label = on_event, toggle_label
        self.hwnd = None
        self.ok = False
        self.ready = threading.Event()
        self.user32 = None
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()
        self.ready.wait(3.0)
        return self.ok

    def stop(self):
        try:
            if self.ok and self.hwnd:
                self.user32.PostMessageW(self.hwnd, self.WM_STOP, 0, 0)
                self.thread.join(1.0)
        except Exception:
            pass

    def _run(self):
        try:
            self._loop()
        except Exception:
            self.ok = False
        finally:
            self.ready.set()

    def _loop(self):
        from ctypes import wintypes as wt
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.user32 = user32
        LRESULT = ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)

        class WNDCLASSW(ctypes.Structure):
            _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", wt.HINSTANCE), ("hIcon", wt.HICON),
                        ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                        ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]

        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_ = [("cbSize", wt.DWORD), ("hWnd", wt.HWND), ("uID", wt.UINT), ("uFlags", wt.UINT),
                        ("uCallbackMessage", wt.UINT), ("hIcon", wt.HICON), ("szTip", wt.WCHAR * 128),
                        ("dwState", wt.DWORD), ("dwStateMask", wt.DWORD), ("szInfo", wt.WCHAR * 256),
                        ("uVersion", wt.UINT), ("szInfoTitle", wt.WCHAR * 64), ("dwInfoFlags", wt.DWORD),
                        ("guidItem", ctypes.c_byte * 16), ("hBalloonIcon", wt.HICON)]

        class MSG(ctypes.Structure):
            _fields_ = [("hwnd", wt.HWND), ("message", wt.UINT), ("wParam", wt.WPARAM),
                        ("lParam", wt.LPARAM), ("time", wt.DWORD), ("pt", wt.POINT)]

        user32.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
        user32.DefWindowProcW.restype = LRESULT
        user32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
        user32.RegisterClassW.restype = wt.ATOM
        user32.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int,
                                           ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.HWND, wt.HMENU,
                                           wt.HINSTANCE, wt.LPVOID]
        user32.CreateWindowExW.restype = wt.HWND
        user32.GetMessageW.argtypes = [ctypes.POINTER(MSG), wt.HWND, wt.UINT, wt.UINT]
        user32.GetMessageW.restype = wt.BOOL
        user32.TranslateMessage.argtypes = [ctypes.POINTER(MSG)]
        user32.DispatchMessageW.argtypes = [ctypes.POINTER(MSG)]
        user32.DispatchMessageW.restype = LRESULT
        user32.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
        user32.PostQuitMessage.argtypes = [ctypes.c_int]
        user32.DestroyWindow.argtypes = [wt.HWND]
        user32.RegisterWindowMessageW.argtypes = [wt.LPCWSTR]
        user32.RegisterWindowMessageW.restype = wt.UINT
        user32.LoadImageW.argtypes = [wt.HINSTANCE, wt.LPCWSTR, wt.UINT, ctypes.c_int, ctypes.c_int, wt.UINT]
        user32.LoadImageW.restype = wt.HANDLE
        user32.LoadIconW.argtypes = [wt.HINSTANCE, ctypes.c_void_p]
        user32.LoadIconW.restype = wt.HICON
        user32.GetSystemMetrics.argtypes = [ctypes.c_int]
        user32.CreatePopupMenu.restype = wt.HMENU
        user32.AppendMenuW.argtypes = [wt.HMENU, wt.UINT, ctypes.c_size_t, wt.LPCWSTR]
        user32.TrackPopupMenu.argtypes = [wt.HMENU, wt.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                          wt.HWND, ctypes.c_void_p]
        user32.DestroyMenu.argtypes = [wt.HMENU]
        user32.GetCursorPos.argtypes = [ctypes.POINTER(wt.POINT)]
        user32.SetForegroundWindow.argtypes = [wt.HWND]
        shell32.Shell_NotifyIconW.argtypes = [wt.DWORD, ctypes.POINTER(NOTIFYICONDATAW)]
        shell32.Shell_NotifyIconW.restype = wt.BOOL
        kernel32.GetModuleHandleW.argtypes = [wt.LPCWSTR]
        kernel32.GetModuleHandleW.restype = wt.HINSTANCE

        hicon = None
        try:
            size = user32.GetSystemMetrics(49)  # SM_CXSMICON
            if os.path.exists(self.ico_path):
                hicon = user32.LoadImageW(None, self.ico_path, 1, size, size, 0x10)  # IMAGE_ICON, LR_LOADFROMFILE
        except Exception:
            hicon = None
        if not hicon:
            hicon = user32.LoadIconW(None, 32512)  # icona di sistema

        nid = NOTIFYICONDATAW()
        taskbar_created = user32.RegisterWindowMessageW("TaskbarCreated")

        def add_icon():
            nid.cbSize = ctypes.sizeof(nid)
            nid.hWnd = self.hwnd
            nid.uID = 1
            nid.uFlags = 0x1 | 0x2 | 0x4  # NIF_MESSAGE | NIF_ICON | NIF_TIP
            nid.uCallbackMessage = self.WM_TRAY
            nid.hIcon = hicon
            nid.szTip = self.tip
            shell32.Shell_NotifyIconW(0, ctypes.byref(nid))  # NIM_ADD

        def show_menu(hwnd):
            menu = user32.CreatePopupMenu()
            user32.AppendMenuW(menu, 0, 1, "Apri Silent")
            user32.AppendMenuW(menu, 0, 2, self.toggle_label())
            user32.AppendMenuW(menu, 0x800, 0, None)  # MF_SEPARATOR
            user32.AppendMenuW(menu, 0, 3, "Esci")
            pt = wt.POINT()
            user32.GetCursorPos(ctypes.byref(pt))
            user32.SetForegroundWindow(hwnd)
            cmd = user32.TrackPopupMenu(menu, 0x0100 | 0x0002, pt.x, pt.y, 0, hwnd, None)  # RETURNCMD | RIGHTBUTTON
            user32.PostMessageW(hwnd, 0, 0, 0)
            user32.DestroyMenu(menu)
            if cmd == 1:
                self.on_event("show")
            elif cmd == 2:
                self.on_event("toggle")
            elif cmd == 3:
                self.on_event("quit")

        def wndproc(hwnd, msg, wparam, lparam):
            try:
                if msg == self.WM_TRAY:
                    ev = lparam & 0xFFFF
                    if ev in (0x0202, 0x0203):      # clic o doppio clic sinistro
                        self.on_event("show")
                    elif ev == 0x0205:              # rilascio del tasto destro
                        show_menu(hwnd)
                    return 0
                if msg == taskbar_created:          # Esplora risorse e' ripartito: rimetto l'icona
                    add_icon()
                    return 0
                if msg == self.WM_STOP:
                    shell32.Shell_NotifyIconW(2, ctypes.byref(nid))  # NIM_DELETE
                    user32.DestroyWindow(hwnd)
                    return 0
                if msg == 0x0002:                   # WM_DESTROY
                    user32.PostQuitMessage(0)
                    return 0
            except Exception:
                pass
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

        self._wndproc = WNDPROC(wndproc)  # tengo il riferimento: se Python lo scarta, Windows crolla
        hinst = kernel32.GetModuleHandleW(None)
        wc = WNDCLASSW()
        wc.lpfnWndProc = self._wndproc
        wc.hInstance = hinst
        wc.lpszClassName = "SilentPCTrayWindow"
        if not user32.RegisterClassW(ctypes.byref(wc)):
            return
        self.hwnd = user32.CreateWindowExW(0, "SilentPCTrayWindow", "Silent", 0, 0, 0, 0, 0,
                                           None, None, hinst, None)
        if not self.hwnd:
            return
        add_icon()
        self.ok = True
        self.ready.set()
        msg = MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        self.ok = False


# ------------------------------------------------------------------ grafica

def rrect(c, x1, y1, x2, y2, r, **kw):
    """Rettangolo con angoli arrotondati su un Canvas."""
    r = max(0, min(r, (x2 - x1) / 2.0, (y2 - y1) / 2.0))
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
           x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


class Card(tk.Canvas):
    """Contenitore con sfondo arrotondato (come le card dell'app Android). Usa .inner per i widget."""

    def __init__(self, parent, bg, fill, radius, pad):
        super().__init__(parent, bg=bg, highlightthickness=0, bd=0, height=10)
        self.fill, self.radius, self.pad = fill, radius, pad
        self.inner = tk.Frame(self, bg=fill)
        self.win = self.create_window(pad, pad, window=self.inner, anchor="nw")
        self.bind("<Configure>", self._on_canvas)
        self.inner.bind("<Configure>", self._on_inner)

    def sync_height(self):
        h = self.inner.winfo_reqheight() + 2 * self.pad
        if int(self.cget("height")) != h:
            self.config(height=h)

    def _on_inner(self, event):
        self.sync_height()

    def _on_canvas(self, event):
        self.delete("bg")
        rrect(self, 0, 0, event.width, event.height, self.radius, fill=self.fill, outline="", tags="bg")
        self.tag_lower("bg")
        self.itemconfig(self.win, width=max(1, event.width - 2 * self.pad))


class RoundButton(tk.Canvas):
    """Pulsante arrotondato."""

    def __init__(self, parent, text, command, fill, fg, bg, height, font, width=None):
        kw = {"width": width} if width else {}
        super().__init__(parent, height=height, bg=bg, highlightthickness=0, bd=0,
                         cursor="hand2", **kw)
        self.text, self.command, self.fill, self.fg, self.font = text, command, fill, fg, font
        self.enabled = True
        self.bind("<Configure>", lambda e: self.redraw())
        self.bind("<Button-1>", self._click)

    def redraw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        rrect(self, 0, 0, w, h, h / 2.0, fill=self.fill if self.enabled else DIS_FILL, outline="")
        self.create_text(w / 2.0, h / 2.0, text=self.text,
                         fill=self.fg if self.enabled else DIS_FG, font=self.font)

    def configure_button(self, text=None, fill=None, fg=None):
        changed = False
        for attr, val in (("text", text), ("fill", fill), ("fg", fg)):
            if val is not None and getattr(self, attr) != val:
                setattr(self, attr, val)
                changed = True
        if changed:
            self.redraw()

    def set_enabled(self, enabled):
        if self.enabled != enabled:
            self.enabled = enabled
            self.config(cursor="hand2" if enabled else "arrow")
            self.redraw()

    def _click(self, event):
        if self.enabled and self.command:
            self.command()


class LevelBar(tk.Canvas):
    """Barra del livello audio arrotondata con la linea della soglia (come nell'app)."""

    def __init__(self, parent, bg, height):
        super().__init__(parent, height=height, bg=bg, highlightthickness=0, bd=0)
        self.level = 0
        self.threshold = 40
        self.bind("<Configure>", lambda e: self.draw())

    def set_state(self, level, threshold):
        if level != self.level or threshold != self.threshold:
            self.level, self.threshold = level, threshold
            self.draw()

    def draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        rrect(self, 0, 0, w, h, h / 2.0, fill=TRACK, outline="")
        if self.level > 0:
            fw = max(w * self.level / 100.0, h)
            color = ORANGE if self.level >= self.threshold else GREEN
            rrect(self, 0, 0, fw, h, h / 2.0, fill=color, outline="")
        x = w * self.threshold / 100.0
        self.create_rectangle(x - 1.5, 0, x + 1.5, h, fill=WHITE, outline="")


class StatusCircle(tk.Canvas):
    """Cerchio di stato con icona play / pausa, come nell'app Android."""

    def __init__(self, parent, bg, size):
        super().__init__(parent, width=size, height=size, bg=bg, highlightthickness=0, bd=0)
        self.size = size
        self.state = None

    def set(self, color, icon):
        if self.state == (color, icon):
            return
        self.state = (color, icon)
        self.delete("all")
        s = self.size
        self.create_oval(2, 2, s - 2, s - 2, fill=color, outline="")
        k = s * 0.49 / 24.0
        off = (s - 24 * k) / 2.0

        def p(x, y):
            return (off + x * k, off + y * k)

        if icon == "play":
            self.create_polygon(*p(8, 5), *p(8, 19), *p(19, 12), fill=WHITE, outline="")
        elif icon == "pause":
            self.create_rectangle(*p(6, 5), *p(10, 19), fill=WHITE, outline="")
            self.create_rectangle(*p(14, 5), *p(18, 19), fill=WHITE, outline="")
        else:
            self.create_text(s / 2.0, s / 2.0, text="!", fill=WHITE,
                             font=("Segoe UI", max(12, int(s * 0.16)), "bold"))


class Slider(tk.Canvas):
    """Cursore arrotondato (soglia e ritardo)."""

    def __init__(self, parent, bg, color, lo, hi, value, height, on_change=None, on_release=None):
        super().__init__(parent, height=height, bg=bg, highlightthickness=0, bd=0, cursor="hand2")
        self.color, self.lo, self.hi, self.value = color, lo, hi, value
        self.on_change, self.on_release = on_change, on_release
        self.dragging = False
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Button-1>", self._press)
        self.bind("<B1-Motion>", self._drag)
        self.bind("<ButtonRelease-1>", self._release)

    def draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w <= 2:
            return
        r = h / 2.0
        th = max(4.0, h * 0.28)
        cy = h / 2.0
        x0, x1 = r, w - r
        frac = (self.value - self.lo) / float(self.hi - self.lo)
        xv = x0 + (x1 - x0) * frac
        rrect(self, x0 - r * 0.5, cy - th / 2, x1 + r * 0.5, cy + th / 2, th / 2, fill=TRACK2, outline="")
        if xv > x0:
            rrect(self, x0 - r * 0.5, cy - th / 2, xv, cy + th / 2, th / 2, fill=self.color, outline="")
        self.create_oval(xv - r * 0.78, cy - r * 0.78, xv + r * 0.78, cy + r * 0.78,
                         fill=self.color, outline="")

    def set(self, value):
        value = max(self.lo, min(self.hi, int(value)))
        if not self.dragging and value != self.value:
            self.value = value
            self.draw()

    def _from_x(self, x):
        w, h = self.winfo_width(), self.winfo_height()
        r = h / 2.0
        frac = (x - r) / max(1.0, (w - 2 * r))
        frac = max(0.0, min(1.0, frac))
        return int(round(self.lo + frac * (self.hi - self.lo)))

    def _apply(self, x):
        v = self._from_x(x)
        if v != self.value:
            self.value = v
            self.draw()
            if self.on_change:
                self.on_change(v)

    def _press(self, e):
        self.dragging = True
        self._apply(e.x)

    def _drag(self, e):
        self._apply(e.x)

    def _release(self, e):
        self.dragging = False
        if self.on_release:
            self.on_release(self.value)


class Toggle(tk.Canvas):
    """Interruttore arrotondato."""

    def __init__(self, parent, bg, on, command, width, height):
        super().__init__(parent, width=width, height=height, bg=bg, highlightthickness=0, bd=0,
                         cursor="hand2")
        self.on, self.command = bool(on), command
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Button-1>", lambda e: self.flip())

    def draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w <= 2:
            return
        rrect(self, 0, 0, w, h, h / 2.0, fill=ORANGE if self.on else TRACK2, outline="")
        m = h * 0.14
        d = h - 2 * m
        x = w - m - d if self.on else m
        self.create_oval(x, m, x + d, m + d, fill=WHITE if self.on else LIGHT, outline="")

    def set(self, on):
        if bool(on) != self.on:
            self.on = bool(on)
            self.draw()

    def flip(self):
        self.on = not self.on
        self.draw()
        if self.command:
            self.command(self.on)


def fmt_dur(sec):
    sec = int(sec)
    total_min = sec // 60
    h, m = total_min // 60, total_min % 60
    if h > 0:
        return "%dh %dm" % (h, m)
    if total_min > 0:
        return "%dm" % m
    return "%ds" % sec


def pct_work(w, p):
    tot = w + p
    return 0 if tot <= 0 else int(w * 100 / tot)


DAYS_IT = ["Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"]


def day_label(iso, i):
    if i == 0:
        return "Oggi"
    try:
        d = datetime.date.fromisoformat(iso)
        return "%s %02d/%02d" % (DAYS_IT[d.weekday()], d.day, d.month)
    except Exception:
        return iso


def report_text(days):
    """Stesso testo del report dell'app Android."""
    if not days:
        return "Nessun dato"
    w, p = days[0][1], days[0][2]
    lines = ["Silent - report di oggi",
             "Lavoro: %s" % fmt_dur(w),
             "Riproduzione (non lavoro): %s" % fmt_dur(p),
             "Quota di lavoro: %d%%" % pct_work(w, p), "", "Ultimi 7 giorni:"]
    for i, (iso, dw, dp) in enumerate(days[:7]):
        label = day_label(iso, i)
        if dw + dp == 0:
            lines.append("%s: nessun dato" % label)
        else:
            lines.append("%s: lavoro %s · play %s (%d%%)" % (label, fmt_dur(dw), fmt_dur(dp), pct_work(dw, dp)))
    return "\n".join(lines)


def enable_dpi_awareness():
    """Testo nitido sugli schermi con scala diversa da 100%."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    try:  # la barra delle applicazioni mostra il logo di Silent invece di quello di Python
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("mdovideo.silent.pcsender")
    except Exception:
        pass


def dark_title_bar(root):
    """Barra del titolo scura (Windows 10 recente / 11); se non supportata non fa nulla."""
    try:
        root.update()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        for attr, val in ((20, 1), (19, 1)):
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(ctypes.c_int(val)), ctypes.sizeof(ctypes.c_int))
        color = ctypes.c_int(0x20140F)  # #0F1420 in formato BGR
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color), ctypes.sizeof(color))
    except Exception:
        pass


class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.sender = Sender()
        self.ctrl = Control()
        self.notice = None            # (testo, colore) quando l'invio e' fermo
        self.compact = False
        self.cards = []
        self.devices = []
        self.local_ts = 0.0           # ultima modifica fatta dal PC a soglia/ritardo/interruttori
        self.push_job = None
        self.offline_edit = False
        self.autostart_since = None
        self.tray = None
        self.tray_events = queue.Queue()
        self.quitting = False
        self.tray_var = tk.BooleanVar(value=bool(self.cfg.get("toTray", True)))
        self.upd = {"state": "idle", "build": 0, "url": None, "sha": None, "pct": 0, "msg": ""}
        self.upd_checked = False
        self.ip_entry = None
        self.auto_toggle = None
        self.test_pause = None
        self.test_play = None
        self.settings_win = None
        self.report_win = None
        self.report_drawn = None
        self.report_req = 0.0
        self.report_days = []
        self.start_time = time.monotonic()
        self.sc = max(1.0, root.winfo_fpixels("1i") / 96.0)
        S = self.S
        root.title("Silent PC")
        root.configure(bg=BG)
        root.resizable(False, False)
        self.setup_icons()

        style = ttk.Style()
        style.theme_use("clam")
        root.option_add("*TCombobox*Listbox.background", TRACK)
        root.option_add("*TCombobox*Listbox.foreground", WHITE)
        root.option_add("*TCombobox*Listbox.selectBackground", ORANGE)
        root.option_add("*TCombobox*Listbox.selectForeground", BG)
        root.option_add("*TCombobox*Listbox.font", ("Segoe UI", 10))
        style.configure("Silent.TCombobox", fieldbackground=TRACK, background=TRACK,
                        foreground=WHITE, arrowcolor=WHITE, bordercolor=TRACK,
                        lightcolor=TRACK, darkcolor=TRACK, selectbackground=TRACK,
                        selectforeground=WHITE, padding=S(6))
        style.map("Silent.TCombobox",
                  fieldbackground=[("readonly", TRACK), ("disabled", CARD)],
                  foreground=[("readonly", WHITE), ("disabled", GREY)],
                  selectbackground=[("readonly", TRACK)],
                  selectforeground=[("readonly", WHITE)],
                  background=[("active", TRACK), ("readonly", TRACK)],
                  arrowcolor=[("disabled", GREY)])

        self.build_ui()

        if pyaudio is None:
            self.notice = ("Manca pyaudiowpatch: pip install pyaudiowpatch numpy", ORANGE)
            self.btn.set_enabled(False)
            self.refresh_btn.set_enabled(False)
        else:
            self.refresh_devices()

        root.protocol("WM_DELETE_WINDOW", self.close)
        dark_title_bar(root)
        self.fit()
        root.after(120, self.fit)
        root.after(500, self.fit)
        self.ctrl.start()
        self.start_tray()
        if "--tray" in sys.argv and self.tray is not None:
            root.after(300, root.withdraw)   # avviato con Windows: parte nascosto nella tray
        if self.autostart_var.get() and pyaudio is not None:
            self.autostart_since = time.monotonic()
        self.tick()

    def S(self, v):
        return int(round(v * self.sc))

    # ---- icone
    def setup_icons(self):
        root, S = self.root, self.S
        ico = resource_path("silent.ico")
        done = False
        if os.path.exists(ico):
            try:
                root.iconbitmap(default=ico)
                done = True
            except Exception:
                pass
        self.icons = []
        try:
            for s in (16, 32, 48, 64):
                self.icons.append(tk.PhotoImage(data=base64.b64encode(png_bytes(make_icon_png(s)))))
            if not done:
                root.iconphoto(True, *self.icons)
        except Exception:
            self.icons = []
        try:
            self.logo = tk.PhotoImage(data=base64.b64encode(png_bytes(make_icon_png(S(46)))))
        except Exception:
            self.logo = None

    # ---- costruzione della finestra
    def build_ui(self):
        S = self.S
        root = self.root
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True, padx=S(24), pady=S(16))
        outer.grid_columnconfigure(0, weight=1, uniform="col")
        outer.grid_columnconfigure(1, weight=1, uniform="col")
        left = tk.Frame(outer, bg=BG)
        right = tk.Frame(outer, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, S(12)))
        right.grid(row=0, column=1, sticky="nsew", padx=(S(12), 0))
        footer = tk.Frame(outer, bg=BG)
        footer.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(S(14), 0))

        # --- colonna sinistra: stato
        self.head = tk.Frame(left, bg=BG)
        self.head.pack()
        if self.logo is not None:
            tk.Label(self.head, image=self.logo, bg=BG).pack()
        tk.Label(self.head, text="Silent PC", bg=BG, fg=WHITE,
                 font=("Segoe UI", 22, "bold")).pack()
        tk.Label(self.head, text="Il video va solo quando c'è silenzio", bg=BG, fg=GREY,
                 font=("Segoe UI", 10)).pack()

        self.circle = StatusCircle(left, BG, S(120))
        self.circle.pack(pady=(S(14), S(8)))
        self.status = tk.Label(left, text="Fermo", bg=BG, fg=WHITE, height=2,
                               font=("Segoe UI", 13, "bold"), wraplength=S(380), justify="center")
        self.status.pack()
        self.input_lbl = tk.Label(left, text="Ingresso: -", bg=BG, fg=GREY, font=("Segoe UI", 9))
        self.input_lbl.pack(pady=(0, S(8)))
        self.bar = LevelBar(left, BG, S(26))
        self.bar.pack(fill="x")
        self.level_lbl = tk.Label(left, text="Livello 0 · soglia 40", bg=BG, fg=GREY,
                                  font=("Segoe UI", 9))
        self.level_lbl.pack(pady=(S(4), S(12)))

        self.btn = RoundButton(left, "Avvia invio", self.toggle, ORANGE, BG, BG, S(50),
                               ("Segoe UI", 13, "bold"))
        self.btn.pack(fill="x")
        self.listen_btn = RoundButton(left, "Avvia ascolto del tablet", self.toggle_listen, ORANGE, BG,
                                      BG, S(50), ("Segoe UI", 13, "bold"))
        self.listen_btn.pack(fill="x", pady=(S(10), 0))

        # --- colonna destra: card
        c1 = Card(right, BG, CARD, S(18), S(14))
        c1.pack(fill="x")
        self.cards.append(c1)
        c = c1.inner
        tk.Label(c, text="Tablet", bg=CARD, fg=WHITE, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.conn_lbl = tk.Label(c, text="Cerco il tablet sulla rete...", bg=CARD, fg=ORANGE,
                                 font=("Segoe UI", 10), wraplength=S(340), justify="left")
        self.conn_lbl.pack(anchor="w", pady=(S(2), S(10)))
        self.auto_var = tk.BooleanVar(value=bool(self.cfg.get("auto", True)))
        self.ip_var = tk.StringVar(value=self.cfg.get("ip", ""))
        self.pin_var = tk.StringVar(value=str(self.cfg.get("pin", "")))
        self.ctrl.pin = self.pin_var.get().strip()
        self.pin_var.trace_add("write", lambda *a: setattr(self.ctrl, "pin", self.pin_var.get().strip()))
        br = tk.Frame(c, bg=CARD)
        br.pack(fill="x")
        br.grid_columnconfigure(0, weight=1, uniform="t")
        br.grid_columnconfigure(1, weight=1, uniform="t")
        RoundButton(br, "Impostazioni", self.open_settings, BTN2, WHITE, CARD, S(32),
                    ("Segoe UI", 10)).grid(row=0, column=0, sticky="ew", padx=(0, S(5)))
        RoundButton(br, "Report", self.open_report, BTN2, WHITE, CARD, S(32),
                    ("Segoe UI", 10)).grid(row=0, column=1, sticky="ew", padx=(S(5), 0))

        c2 = Card(right, BG, CARD, S(18), S(14))
        c2.pack(fill="x", pady=(S(12), 0))
        self.cards.append(c2)
        c = c2.inner
        r = tk.Frame(c, bg=CARD)
        r.pack(fill="x")
        tk.Label(r, text="Audio da inviare", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 11, "bold")).pack(side="left")
        self.refresh_btn = RoundButton(r, "Aggiorna", self.refresh_devices, BTN2, WHITE, CARD,
                                       S(28), ("Segoe UI", 9), width=S(84))
        self.refresh_btn.pack(side="right")
        self.combo = ttk.Combobox(c, state="readonly", style="Silent.TCombobox", font=("Segoe UI", 10))
        self.combo.pack(fill="x", pady=(S(8), 0))

        c3 = Card(right, BG, CARD, S(18), S(14))
        c3.pack(fill="x", pady=(S(12), 0))
        self.cards.append(c3)
        c = c3.inner
        self.thr_lbl = tk.Label(c, text="Soglia audio: 40", bg=CARD, fg=WHITE, font=("Segoe UI", 10))
        self.thr_lbl.pack(anchor="w")
        self.thr = Slider(c, CARD, ORANGE, 0, 100, int(self.cfg.get("threshold", 40)), S(26),
                          on_change=self.on_slider, on_release=lambda v: self.push_settings())
        self.thr.pack(fill="x", pady=(S(2), S(8)))
        self.delay_lbl = tk.Label(c, text="Ritardo ripartenza: 5 s", bg=CARD, fg=WHITE,
                                  font=("Segoe UI", 10))
        self.delay_lbl.pack(anchor="w")
        self.delay = Slider(c, CARD, GREEN, 1, 60, int(self.cfg.get("delay", 5)), S(26),
                            on_change=self.on_slider, on_release=lambda v: self.push_settings())
        self.delay.pack(fill="x", pady=(S(2), S(8)))
        self.minms_lbl = tk.Label(c, text="Durata minima suono: 300 ms", bg=CARD, fg=WHITE,
                                  font=("Segoe UI", 10))
        self.minms_lbl.pack(anchor="w")
        self.minms = Slider(c, CARD, ORANGE, 0, 20, int(self.cfg.get("minMs", 300)) // 50, S(26),
                            on_change=self.on_slider, on_release=lambda v: self.push_settings())
        self.minms.pack(fill="x", pady=(S(2), S(8)))
        self.only_tg = self.toggle_row(c, "Pausa solo se sta suonando qualcosa",
                                       bool(self.cfg.get("onlyPlaying", True)), self.on_switch)
        self.single_tg = self.toggle_row(c, "Usa un unico tasto play/pausa",
                                         bool(self.cfg.get("toggle", False)), self.on_switch, pady=S(6))
        self.autostart_var = tk.BooleanVar(value=bool(self.cfg.get("autostart", False)))
        self.autostart_tg = self.toggle_row(c, "Avvia l'invio all'apertura",
                                            self.autostart_var.get(),
                                            lambda on: self.autostart_var.set(on), pady=S(6))
        self.update_labels()

        # --- piede: aggiornamenti
        fc = Card(footer, BG, CARD, S(16), S(10))
        fc.pack(fill="x")
        self.cards.append(fc)
        fr = tk.Frame(fc.inner, bg=CARD)
        fr.pack(fill="x")
        self.ver_lbl = tk.Label(fr, text="", bg=CARD, fg=LIGHT, font=("Segoe UI", 9), anchor="w")
        self.ver_lbl.pack(side="left")
        self.upd_btn = RoundButton(fr, "Controlla aggiornamenti", self.on_update_click, BTN2, WHITE,
                                   CARD, S(30), ("Segoe UI", 9, "bold"), width=S(190))
        self.upd_btn.pack(side="right")
        self.upd_lbl = tk.Label(fr, text="", bg=CARD, fg=GREY, font=("Segoe UI", 9))
        self.upd_lbl.pack(side="right", padx=(0, S(10)))

        self.apply_auto_ui()

    def toggle_row(self, parent, text, on, command, pady=0):
        S = self.S
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill="x", pady=(pady, 0))
        lbl = tk.Label(row, text=text, bg=CARD, fg=WHITE, font=("Segoe UI", 10), anchor="w")
        lbl.pack(side="left")
        tg = Toggle(row, CARD, on, command, S(42), S(22))
        tg.pack(side="right")
        lbl.bind("<Button-1>", lambda e: tg.flip())
        return tg

    def work_area(self):
        """Area dello schermo non coperta dalla barra delle applicazioni: (x, y, larghezza, altezza)."""
        try:
            r = ctypes.wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
            return r.left, r.top, r.right - r.left, r.bottom - r.top
        except Exception:
            return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight() - self.S(60)

    def fit(self):
        """Dimensiona la finestra sul contenuto e la tiene dentro lo schermo."""
        r = self.root
        for c in self.cards:
            c.sync_height()
        r.update_idletasks()
        x0, y0, aw, ah = self.work_area()
        avail = ah - self.S(40)
        if r.winfo_reqheight() > avail and not self.compact:
            self.compact = True  # schermo basso: nascondo logo e sottotitolo
            self.head.pack_forget()
            for c in self.cards:
                c.sync_height()
            r.update_idletasks()
        w = min(self.S(960), aw - self.S(20))
        h = min(r.winfo_reqheight(), avail)
        x = x0 + max(0, (aw - w) // 2)
        y = y0 + max(0, (ah - h) // 2 - self.S(10))
        r.geometry("%dx%d+%d+%d" % (w, h, x, y))

    # ---- audio / dispositivi
    def refresh_devices(self):
        if pyaudio is None:
            return
        keep = self.combo.get() or self.cfg.get("device")
        p = pyaudio.PyAudio()
        try:
            self.devices, default_idx = list_devices(p)
        finally:
            p.terminate()
        names = [d[0] for d in self.devices]
        self.combo["values"] = names
        if keep in names:
            self.combo.current(names.index(keep))
        elif names:
            self.combo.current(default_idx)
        else:
            self.combo.set("")

    # ---- tablet / modalita' automatica
    def on_auto(self, on):
        self.auto_var.set(on)
        self.apply_auto_ui()

    def apply_auto_ui(self):
        auto = self.auto_var.get()
        if self.ip_entry is not None:
            self.ip_entry.config(state="disabled" if auto else "normal")
        if auto:
            self.ctrl.manual = None
        else:
            text = self.ip_var.get().strip()
            self.ctrl.manual = text if IPV4.match(text) else None

    def resolve_target(self):
        """IP del tablet da usare, oppure None."""
        if self.auto_var.get():
            self.ctrl.manual = None
            return self.ctrl.target_ip()
        text = self.ip_var.get().strip()
        ip = resolve_host(text) if text else None
        self.ctrl.manual = ip
        return ip

    # ---- impostazioni condivise col tablet
    def update_labels(self):
        self.thr_lbl.config(text="Soglia audio: %d" % self.thr.value)
        self.delay_lbl.config(text="Ritardo ripartenza: %d s" % self.delay.value)
        self.minms_lbl.config(text="Durata minima suono: %d ms" % (self.minms.value * 50))

    def on_slider(self, v):
        self.local_ts = time.monotonic()
        self.update_labels()
        self.schedule_push()

    def on_switch(self, on):
        self.local_ts = time.monotonic()
        self.schedule_push()

    def schedule_push(self):
        if self.push_job is None:
            self.push_job = self.root.after(120, self.push_settings)

    def push_settings(self):
        self.push_job = None
        self.local_ts = time.monotonic()
        if self.ctrl.status() is None:
            self.offline_edit = True  # lo mando appena il tablet compare
        self.ctrl.send({"cmd": "set", "threshold": self.thr.value, "delay": self.delay.value,
                        "minMs": self.minms.value * 50,
                        "onlyPlaying": self.only_tg.on, "toggle": self.single_tg.on})

    def sync_from_tablet(self, st):
        s = st.get("set")
        if not isinstance(s, dict) or time.monotonic() - self.local_ts < 1.5:
            return
        try:
            self.thr.set(int(s.get("threshold", self.thr.value)))
            self.delay.set(int(s.get("delay", self.delay.value)))
            self.minms.set(int(s.get("minMs", self.minms.value * 50)) // 50)
            self.only_tg.set(bool(s.get("onlyPlaying", self.only_tg.on)))
            self.single_tg.set(bool(s.get("toggle", self.single_tg.on)))
        except Exception:
            return
        self.update_labels()

    # ---- avvio / stop
    def set_locked(self, locked):
        self.refresh_btn.set_enabled(not locked)
        self.combo.config(state="disabled" if locked else "readonly")
        if self.ip_entry is not None:
            self.ip_entry.config(state="disabled" if (locked or self.auto_var.get()) else "normal")

    def toggle(self):
        if self.sender.running:
            self.sender.stop()
            self.ctrl.send({"cmd": "stop"})
            self.set_locked(False)
            self.btn.configure_button(text="Avvia invio")
            self.notice = None
            return
        ip = self.resolve_target()
        if ip is None:
            if self.auto_var.get():
                self.notice = ("Non trovo il tablet: apri Silent sul tablet (stessa rete Wi-Fi)", ORANGE)
            else:
                self.notice = ("Indirizzo non valido: %s" % self.ip_var.get().strip(), ORANGE)
            return
        sel = self.combo.current()
        if sel < 0:
            self.notice = ("Nessun dispositivo audio", ORANGE)
            return
        try:
            self.sender.start(self.devices[sel][1], ip)
        except Exception as e:
            self.sender.stop()
            self.notice = ("Errore: %s" % e, ORANGE)
            return
        self.notice = None
        self.ctrl.send({"cmd": "start", "source": "pc"})
        self.save_cfg()
        self.set_locked(True)
        self.btn.configure_button(text="Ferma invio")

    def toggle_listen(self):
        """Avvia / ferma l'ascolto sul tablet senza toccare il tablet."""
        st = self.ctrl.status()
        if st is None:
            self.notice = ("Tablet non trovato: apri Silent sul tablet", ORANGE)
            return
        self.notice = None
        self.ctrl.send({"cmd": "stop"} if st.get("running") else {"cmd": "start"})

    def style_window(self, w, width):
        """Rifiniture comuni alle finestre secondarie."""
        w.update_idletasks()
        h = w.winfo_reqheight()
        x = self.root.winfo_rootx() + self.S(40)
        y = self.root.winfo_rooty() + self.S(40)
        w.geometry("%dx%d+%d+%d" % (width, h, x, y))
        dark_title_bar(w)

    def open_settings(self):
        if self.settings_win is not None:
            try:
                self.settings_win.deiconify()
                self.settings_win.lift()
                return
            except tk.TclError:
                self.settings_win = None
        S = self.S
        w = tk.Toplevel(self.root)
        w.title("Impostazioni")
        w.configure(bg=BG)
        w.resizable(False, False)
        w.transient(self.root)
        self.settings_win = w
        outer = tk.Frame(w, bg=BG)
        outer.pack(fill="both", expand=True, padx=S(20), pady=S(16))

        card = Card(outer, BG, CARD, S(18), S(14))
        card.pack(fill="x")
        c = card.inner
        tk.Label(c, text="Indirizzo del tablet", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.auto_toggle = self.toggle_row(c, "Trova il tablet da solo", self.auto_var.get(), self.on_auto,
                                           pady=S(8))
        self.ip_entry = tk.Entry(c, textvariable=self.ip_var, bg=TRACK, fg=WHITE,
                                 insertbackground=WHITE, relief="flat",
                                 disabledbackground=CARD, disabledforeground=GREY,
                                 highlightthickness=S(1), highlightbackground=TRACK,
                                 highlightcolor=ORANGE, font=("Segoe UI", 11))
        self.ip_entry.pack(fill="x", pady=(S(8), 0), ipady=S(4))
        tk.Label(c, text="Se la ricerca automatica non basta, scrivi qui l'IP che vedi nell'app Silent.",
                 bg=CARD, fg=GREY, font=("Segoe UI", 9), wraplength=S(340), justify="left"
                 ).pack(anchor="w", pady=(S(6), 0))

        card2 = Card(outer, BG, CARD, S(18), S(14))
        card2.pack(fill="x", pady=(S(12), 0))
        c = card2.inner
        tk.Label(c, text="Prova i tasti multimediali", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w")
        row = tk.Frame(c, bg=CARD)
        row.pack(fill="x", pady=(S(8), 0))
        row.grid_columnconfigure(0, weight=1, uniform="b")
        row.grid_columnconfigure(1, weight=1, uniform="b")
        self.test_pause = RoundButton(row, "Prova pausa", lambda: self.ctrl.send({"cmd": "test_pause"}),
                                      BTN2, WHITE, CARD, S(40), ("Segoe UI", 10))
        self.test_play = RoundButton(row, "Prova play", lambda: self.ctrl.send({"cmd": "test_play"}),
                                     BTN2, WHITE, CARD, S(40), ("Segoe UI", 10))
        self.test_pause.grid(row=0, column=0, sticky="ew", padx=(0, S(5)))
        self.test_play.grid(row=0, column=1, sticky="ew", padx=(S(5), 0))

        card3 = Card(outer, BG, CARD, S(18), S(14))
        card3.pack(fill="x", pady=(S(12), 0))
        c = card3.inner
        tk.Label(c, text="PIN di abbinamento", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w")
        tk.Entry(c, textvariable=self.pin_var, bg=TRACK, fg=WHITE, insertbackground=WHITE,
                 relief="flat", highlightthickness=S(1), highlightbackground=TRACK,
                 highlightcolor=ORANGE, font=("Segoe UI", 11)).pack(fill="x", pady=(S(8), 0), ipady=S(4))
        tk.Label(c, text="Scrivi lo stesso PIN impostato nelle impostazioni dell'app Silent sul tablet. "
                         "Vuoto = nessuna protezione. Il PIN tiene lontani i comandi casuali sulla rete, "
                         "ma non e' cifrato.",
                 bg=CARD, fg=GREY, font=("Segoe UI", 9), wraplength=S(340), justify="left"
                 ).pack(anchor="w", pady=(S(6), 0))

        card4 = Card(outer, BG, CARD, S(18), S(14))
        card4.pack(fill="x", pady=(S(12), 0))
        c = card4.inner
        tk.Label(c, text="Windows", bg=CARD, fg=WHITE, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.startup_tg = self.toggle_row(c, "Avvia Silent con Windows", startup_enabled(),
                                          self.set_startup_option, pady=S(8))
        self.tray_tg = self.toggle_row(c, "La X lo lascia nella tray", self.tray_var.get(),
                                       lambda on: self.tray_var.set(on), pady=S(6))
        tk.Label(c, text="Con l'avvio automatico Silent parte nascosto: lo trovi nell'icona accanto "
                         "all'orologio (clic = apri, tasto destro = menu).",
                 bg=CARD, fg=GREY, font=("Segoe UI", 9), wraplength=S(340), justify="left"
                 ).pack(anchor="w", pady=(S(6), 0))

        RoundButton(outer, "Chiudi", self.close_settings, ORANGE, BG, BG, S(40),
                    ("Segoe UI", 11, "bold")).pack(fill="x", pady=(S(14), 0))
        w.protocol("WM_DELETE_WINDOW", self.close_settings)
        self.apply_auto_ui()
        card.sync_height()
        card2.sync_height()
        card3.sync_height()
        card4.sync_height()
        self.style_window(w, S(440))
        self.root.after(150, lambda: (card.sync_height(), card2.sync_height(), card3.sync_height(), card4.sync_height()))

    def close_settings(self):
        self.apply_auto_ui()
        self.ip_entry = self.auto_toggle = self.test_pause = self.test_play = None
        if self.settings_win is not None:
            try:
                self.settings_win.destroy()
            except tk.TclError:
                pass
        self.settings_win = None

    def open_report(self):
        if self.report_win is not None:
            try:
                self.report_win.deiconify()
                self.report_win.lift()
                return
            except tk.TclError:
                self.report_win = None
        S = self.S
        w = tk.Toplevel(self.root)
        w.title("Report lavoro")
        w.configure(bg=BG)
        w.resizable(False, False)
        w.transient(self.root)
        self.report_win = w
        outer = tk.Frame(w, bg=BG)
        outer.pack(fill="both", expand=True, padx=S(20), pady=S(16))
        tk.Label(outer, text="Report lavoro", bg=BG, fg=WHITE, font=("Segoe UI", 18, "bold")).pack(anchor="w")
        tk.Label(outer, text="Pausa = stai lavorando, play = non stai lavorando", bg=BG, fg=GREY,
                 font=("Segoe UI", 9)).pack(anchor="w", pady=(0, S(10)))

        card = Card(outer, BG, CARD, S(18), S(14))
        card.pack(fill="x")
        c = card.inner
        self.rep_work = tk.Label(c, text="Lavoro oggi: -", bg=CARD, fg=WHITE, font=("Segoe UI", 14, "bold"))
        self.rep_work.pack(anchor="w")
        self.rep_play = tk.Label(c, text="", bg=CARD, fg=LIGHT, font=("Segoe UI", 10))
        self.rep_play.pack(anchor="w", pady=(S(2), S(8)))
        self.rep_bar = LevelBar(c, CARD, S(18))
        self.rep_bar.pack(fill="x")

        self.rep_msg = tk.Label(outer, text="", bg=BG, fg=ORANGE, font=("Segoe UI", 9))
        self.rep_msg.pack(anchor="w", pady=(S(10), S(2)))
        self.rep_w = S(500)
        self.rep_canvas = tk.Canvas(outer, width=self.rep_w, height=S(300), bg=BG, highlightthickness=0, bd=0)
        self.rep_canvas.pack()
        self.rep_canvas.bind("<Enter>", lambda e: self.rep_canvas.focus_set())
        self.rep_canvas.bind("<MouseWheel>",
                             lambda e: self.rep_canvas.yview_scroll(int(-e.delta / 120), "units"))

        row = tk.Frame(outer, bg=BG)
        row.pack(fill="x", pady=(S(12), 0))
        row.grid_columnconfigure(0, weight=1, uniform="r")
        row.grid_columnconfigure(1, weight=1, uniform="r")
        self.rep_copy = RoundButton(row, "Copia report", self.copy_report, ORANGE, BG, BG, S(40),
                                    ("Segoe UI", 10, "bold"))
        self.rep_copy.grid(row=0, column=0, sticky="ew", padx=(0, S(5)))
        RoundButton(row, "Chiudi", self.close_report, BTN2, WHITE, BG, S(40),
                    ("Segoe UI", 10)).grid(row=0, column=1, sticky="ew", padx=(S(5), 0))
        w.protocol("WM_DELETE_WINDOW", self.close_report)
        card.sync_height()
        self.report_drawn = None
        self.report_req = 0.0
        self.style_window(w, S(540))
        self.root.after(150, card.sync_height)

    def close_report(self):
        if self.report_win is not None:
            try:
                self.report_win.destroy()
            except tk.TclError:
                pass
        self.report_win = None

    def copy_report(self):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(report_text(self.report_days))
            self.rep_msg.config(text="Report copiato negli appunti", fg=GREEN)
        except Exception:
            pass

    def render_report(self):
        """Tiene aggiornata la finestra del report (chiede i dati al tablet ogni 5 secondi)."""
        if self.report_win is None:
            return
        now = time.monotonic()
        if now - self.report_req > 5.0:
            self.report_req = now
            self.ctrl.send({"cmd": "get_report"})
        item = self.ctrl.report()
        if item is None:
            if self.ctrl.status() is None:
                self.rep_msg.config(text="Tablet non collegato: apri Silent sul tablet", fg=ORANGE)
            else:
                self.rep_msg.config(text="Attendo i dati dal tablet...", fg=GREY)
            return
        j, t = item
        if t == self.report_drawn:
            return
        self.report_drawn = t
        days = []
        try:
            for d in j.get("days", []):
                days.append((str(d[0]), int(d[1]), int(d[2])))
        except Exception:
            return
        if not days:
            return
        self.report_days = days
        S = self.S
        w, p = days[0][1], days[0][2]
        self.rep_work.config(text="Lavoro oggi: %s" % fmt_dur(w))
        self.rep_play.config(text="Riproduzione: %s · %d%% lavoro" % (fmt_dur(p), pct_work(w, p)))
        self.rep_bar.set_state(pct_work(w, p), 101)
        if self.rep_msg.cget("fg") != GREEN:
            self.rep_msg.config(text="Ultimi 30 giorni (scorri con la rotellina)", fg=GREY)

        cv = self.rep_canvas
        cv.delete("all")
        rowh = S(30)
        label_w, text_w = S(92), S(130)
        bar_x0, bar_x1 = label_w, self.rep_w - text_w
        biggest = max([dw + dp for _, dw, dp in days] + [1])
        for i, (iso, dw, dp) in enumerate(days):
            y = i * rowh
            cy = y + rowh / 2.0
            cv.create_text(0, cy, text=day_label(iso, i), anchor="w", fill=WHITE if i == 0 else LIGHT,
                           font=("Segoe UI", 10, "bold" if i == 0 else "normal"))
            if dw + dp == 0:
                cv.create_text(bar_x0, cy, text="nessun dato", anchor="w", fill=GREY, font=("Segoe UI", 9))
                continue
            full = (bar_x1 - bar_x0) * (dw + dp) / float(biggest)
            bh = S(14)
            rrect(cv, bar_x0, cy - bh / 2, bar_x0 + max(full, bh), cy + bh / 2, bh / 2, fill=TRACK2, outline="")
            wf = full * dw / float(dw + dp)
            if dw > 0:
                rrect(cv, bar_x0, cy - bh / 2, bar_x0 + max(wf, bh), cy + bh / 2, bh / 2, fill=ORANGE, outline="")
            cv.create_text(self.rep_w, cy, text="%s · %d%%" % (fmt_dur(dw), pct_work(dw, dp)), anchor="e",
                           fill=LIGHT, font=("Segoe UI", 9))
        cv.config(scrollregion=(0, 0, self.rep_w, len(days) * rowh))

    def save_cfg(self):
        sel = self.combo.current()
        self.cfg.update({
            "ip": self.ip_var.get().strip(),
            "auto": bool(self.auto_var.get()),
            "autostart": bool(self.autostart_var.get()),
            "threshold": self.thr.value,
            "delay": self.delay.value,
            "minMs": self.minms.value * 50,
            "pin": self.pin_var.get().strip(),
            "toTray": bool(self.tray_var.get()),
            "onlyPlaying": self.only_tg.on,
            "toggle": self.single_tg.on,
        })
        if 0 <= sel < len(self.devices):
            self.cfg["device"] = self.devices[sel][0]
        save_config(self.cfg)

    # ---- aggiornamenti
    def on_update_click(self):
        st = self.upd["state"]
        if st in ("idle", "uptodate", "error", "noexe"):
            self.start_check()
        elif st == "available":
            self.start_download()

    def start_check(self):
        self.upd.update(state="checking", msg="")

        def work():
            try:
                build, url, sha = check_update()
                if build > BUILD and url:
                    self.upd.update(state="available", build=build, url=url, sha=sha)
                elif build > BUILD:
                    self.upd.update(state="noexe", build=build)
                else:
                    self.upd.update(state="uptodate")
            except Exception as e:
                self.upd.update(state="error", msg=str(e)[:60])

        threading.Thread(target=work, daemon=True).start()

    def start_download(self):
        if not is_frozen():
            self.upd.update(state="error", msg="serve l'exe per aggiornarsi da solo")
            return
        self.upd.update(state="downloading", pct=0)

        def work():
            exe_dir = os.path.dirname(sys.executable)
            dest = os.path.join(exe_dir, "Silent-PC.update.exe")
            try:
                try:
                    download_file(self.upd["url"], dest,
                                  lambda p: self.upd.update(pct=p))
                except PermissionError:
                    dest = os.path.join(os.environ.get("TEMP", exe_dir), "Silent-PC.update.exe")
                    download_file(self.upd["url"], dest,
                                  lambda p: self.upd.update(pct=p))
                if os.path.getsize(dest) < 1_000_000:
                    raise RuntimeError("file scaricato incompleto")
                expected = self.upd.get("sha")
                if expected and file_sha256(dest) != expected:
                    try:
                        os.remove(dest)
                    except OSError:
                        pass
                    raise RuntimeError("controllo SHA-256 non superato")
                apply_update(dest)
                self.upd.update(state="restarting")
            except Exception as e:
                self.upd.update(state="error", msg=str(e)[:60])

        threading.Thread(target=work, daemon=True).start()

    def render_update(self, st):
        u = self.upd
        tablet = ""
        if st is not None and st.get("build"):
            tablet = " · app tablet: build %s" % st.get("build")
        mine = "Silent PC · build %d" % BUILD if BUILD else "Silent PC · versione di prova"
        ver = mine + tablet
        if self.ver_lbl.cget("text") != ver:
            self.ver_lbl.config(text=ver)
        state = u["state"]
        text, btn, fg = "", "Controlla aggiornamenti", GREY
        if state == "checking":
            text = "Controllo..."
        elif state == "uptodate":
            text, fg = "Sei aggiornato", GREEN
        elif state == "available":
            text, btn, fg = "Disponibile la build %d" % u["build"], "Aggiorna ora", ORANGE
        elif state == "noexe":
            text, fg = "Build %d in preparazione" % u["build"], GREY
        elif state == "downloading":
            text, btn, fg = "Scarico... %d%%" % u["pct"], "Attendi", ORANGE
        elif state == "restarting":
            text, btn, fg = "Riavvio...", "Attendi", GREEN
        elif state == "error":
            text, fg = u["msg"] or "Errore di rete", ORANGE
        if self.upd_lbl.cget("text") != text or self.upd_lbl.cget("fg") != fg:
            self.upd_lbl.config(text=text, fg=fg)
        self.upd_btn.configure_button(text=btn)
        self.upd_btn.set_enabled(state not in ("checking", "downloading", "restarting"))
        if state == "restarting":
            self.root.after(400, self.quit_now)

    def quit_now(self):
        try:
            if self.tray is not None:
                self.tray.stop()
        except Exception:
            pass
        try:
            self.ctrl.close()
        except Exception:
            pass
        os._exit(0)

    # ---- aggiornamento della finestra
    def tick(self):
        self.handle_tray_events()
        s = self.sender
        st = self.ctrl.status()
        sending = s.running

        # aggiornamenti: controllo automatico una volta, poco dopo l'apertura
        if not self.upd_checked and time.monotonic() - self.start_time > 3.0:
            self.upd_checked = True
            self.start_check()

        # avvio automatico all'apertura (appena il tablet compare)
        if self.autostart_since is not None and not sending:
            if self.resolve_target():
                self.autostart_since = None
                self.toggle()
            elif time.monotonic() - self.autostart_since > 30:
                self.autostart_since = None
                self.notice = ("Tablet non trovato: apri Silent sul tablet", ORANGE)

        if sending:
            self.sender.set_target(self.ctrl.target_ip())

        # impostazioni
        if st is not None:
            if self.offline_edit:
                self.offline_edit = False
                self.push_settings()
            else:
                self.sync_from_tablet(st)
        elif not self.auto_var.get():
            text = self.ip_var.get().strip()
            self.ctrl.manual = text if IPV4.match(text) else self.ctrl.manual

        # livello e soglia
        if st is not None:
            level, thr = int(st.get("level", 0) or 0), int(st.get("threshold", self.thr.value) or 0)
        else:
            level, thr = (s.level if sending else 0), self.thr.value
        self.bar.set_state(level, thr)
        lt = "Livello %d · soglia %d" % (level, thr)
        if self.level_lbl.cget("text") != lt:
            self.level_lbl.config(text=lt)

        # stato grande
        if sending and s.error:
            color, icon, text, fg = ORANGE, "alert", "Errore rete: %s" % s.error, ORANGE
        elif sending and s.audio_msg:
            color, icon, text, fg = ORANGE, "alert", s.audio_msg, ORANGE
        elif st is not None:
            color = COLORS.get(st.get("color"), GREY)
            icon = st.get("icon") if st.get("icon") in ("play", "pause") else "play"
            text = str(st.get("text") or "Tablet collegato")
            action = str(st.get("action") or "")
            if st.get("running") and action:
                text += "\n(%s)" % action
            fg = WHITE
        elif sending:
            color, icon, text, fg = GREY, "play", "Invio in corso\n(il tablet non risponde ai comandi)", WHITE
        elif self.notice:
            color, icon, (text, fg) = GREY, "play", self.notice
        else:
            color, icon, text, fg = GREY, "play", "Fermo", WHITE
        self.circle.set(color, icon)
        if self.status.cget("text") != text or self.status.cget("fg") != fg:
            self.status.config(text=text, fg=fg)

        if sending:
            label = self.combo.get()
            inp = "Ingresso: " + (label if len(label) <= 52 else label[:49] + "...")
        elif st is not None:
            inp = "Ingresso: " + str(st.get("input") or "-")
        else:
            inp = "Ingresso: -"
        if self.input_lbl.cget("text") != inp:
            self.input_lbl.config(text=inp)

        # collegamento col tablet
        if st is not None:
            ip = self.ctrl.target_ip()
            name = st.get("name") or self.ctrl.tablet_name()
            ctext, cfg_ = "● %s · %s" % (name, ip), GREEN
        elif self.ctrl.is_locked():
            ctext, cfg_ = "● Tablet protetto da PIN\n   (scrivi il PIN giusto in Impostazioni)", ORANGE
        elif self.auto_var.get():
            ctext, cfg_ = "● Cerco il tablet sulla rete...\n   (apri Silent sul tablet)", ORANGE
        elif self.ctrl.manual:
            ctext, cfg_ = "● Il tablet %s non risponde ai comandi" % self.ctrl.manual, ORANGE
        else:
            ctext, cfg_ = "● Inserisci l'IP del tablet", GREY
        if self.conn_lbl.cget("text") != ctext or self.conn_lbl.cget("fg") != cfg_:
            self.conn_lbl.config(text=ctext, fg=cfg_)
        if self.test_pause is not None:
            self.test_pause.set_enabled(st is not None)
            self.test_play.set_enabled(st is not None)
        # I due tasti principali hanno gli stessi colori: arancione = fermo, verde = attivo,
        # scuro con testo spento = non disponibile.
        listening = st is not None and bool(st.get("running"))
        self.listen_btn.configure_button(
            text="Ferma ascolto del tablet" if listening else "Avvia ascolto del tablet",
            fill=GREEN if listening else ORANGE, fg=BG)
        self.listen_btn.set_enabled(st is not None)
        self.btn.configure_button(text="Ferma invio" if sending else "Avvia invio",
                                  fill=GREEN if sending else ORANGE, fg=BG)
        self.render_report()

        self.render_update(st)
        self.root.after(80, self.tick)

    # ---- tray
    def start_tray(self):
        try:
            tray = TrayIcon("Silent PC", resource_path("silent.ico"), self.tray_events.put,
                            lambda: "Ferma invio" if self.sender.running else "Avvia invio")
            if tray.start():
                self.tray = tray
        except Exception:
            self.tray = None

    def show_window(self):
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except tk.TclError:
            pass

    def handle_tray_events(self):
        try:
            while True:
                ev = self.tray_events.get_nowait()
                if ev == "show":
                    self.show_window()
                elif ev == "toggle":
                    if pyaudio is not None:
                        self.toggle()
                elif ev == "quit":
                    self.exit_app()
        except queue.Empty:
            pass

    def set_startup_option(self, on):
        if not set_startup(on):
            self.root.after(0, lambda: self.startup_tg.set(startup_enabled()))

    def close(self):
        # La X non chiude: Silent resta nella tray e continua a lavorare ("Esci" dal menu lo chiude)
        if self.tray is not None and self.tray_var.get() and not self.quitting:
            self.save_cfg()
            self.root.withdraw()
            return
        self.exit_app()

    def exit_app(self):
        self.quitting = True
        self.save_cfg()
        if self.tray is not None:
            self.tray.stop()
            self.tray = None
        if self.sender.running:
            self.sender.stop()
            self.ctrl.send({"cmd": "stop"})
        self.ctrl.close()
        self.root.destroy()


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--make-ico":
        write_ico(sys.argv[2])
        sys.exit(0)
    enable_dpi_awareness()
    try:  # una sola copia alla volta: due Silent si contenderebbero le porte di rete
        _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _mutex = _k32.CreateMutexW(None, False, "Local\\SilentPCSender")
        if ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            ctypes.windll.user32.MessageBoxW(
                None, "Silent e' gia' in esecuzione.\nCerca la sua icona nella tray, accanto all'orologio.",
                "Silent PC", 0x40)
            sys.exit(0)
    except SystemExit:
        raise
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()
