# Silent

App Android che ascolta il microfono del tablet (o un microfono USB-C) e mette in pausa
il video in riproduzione (Netflix, YouTube, Spotify...) finché c'è audio in ingresso.
Quando torna il silenzio per il tempo impostato, il video riparte.
