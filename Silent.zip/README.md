# Silent

App Android che mette in pausa il video in riproduzione (Netflix, YouTube, Spotify...) finché c'è audio in ingresso.
Quando torna il silenzio per il tempo impostato, il video riparte.

Sorgente audio (selettore nell'app):
- **Tablet**: ascolta il microfono del tablet (o un microfono USB-C).
- **PC**: riceve l'audio via Wi-Fi dall'app Windows `Silent.py` (UDP, porta 5005).

## Registro del lavoro

Con l'ascolto attivo, l'app registra ogni secondo lo stato della riproduzione:
- riproduzione **in pausa** = stai lavorando;
- riproduzione **in play** = non stai lavorando.

I totali per giorno (ultimi 90 giorni) si vedono nella scheda "Lavoro". Ogni giorno all'ora scelta
(default 20:00) arriva una notifica con il report; il pulsante "Condividi report" lo manda dove vuoi.
