# Silent

App Android che mette in pausa il video in riproduzione (Netflix, YouTube, Spotify...) finché c'è audio in ingresso.
Quando torna il silenzio per il tempo impostato, il video riparte.

Sorgente audio (selettore nell'app):
- **Tablet**: ascolta il microfono del tablet (o un microfono USB-C).
- **PC**: riceve l'audio via Wi-Fi dall'app Windows **Silent PC** (`pc/Silent.py`, compilata in `Silent-PC.exe`).

## Silent PC (Windows)

- Trova il tablet da sola (nessun IP da scrivere).
- Invia l'audio del PC (UDP 5005) e comanda il tablet (UDP 5006): soglia, ritardo, "pausa solo se suona",
  tasto unico play/pausa, Prova pausa / Prova play, avvia / ferma.
- Quello che cambi sul PC si vede sul tablet e viceversa.
- "Avvia ascolto del tablet" fa partire (o ferma) l'ascolto del tablet dal PC, senza toccare il tablet.
- "Impostazioni": indirizzo del tablet (automatico o a mano) e tasti Prova pausa / Prova play.
  Gli stessi tasti di prova e l'IP sono nel pulsante "Impostazioni" dell'app Android.
- "Report": registro del lavoro del tablet (oggi e ultimi 30 giorni) con pulsante "Copia report".
- La prima volta Windows chiede il permesso di rete: scegli "Reti private".

## Schermata dell'app

- Tablet in orizzontale: tre colonne (stato e pulsanti / sorgente e regolazioni / lavoro e aggiornamenti), senza scorrere.
- Tablet in verticale (e telefono): colonna unica scorrevole.
  I layout sono in `res/layout` (verticale) e `res/layout-sw600dp-land` (tablet orizzontale): gli id sono gli stessi.

## Aggiornamenti automatici (OTA)

A ogni caricamento di `Silent.zip` su GitHub, Actions compila APK ed EXE e li pubblica in una release
(`Silent.apk`, `Silent-PC.exe`). L'app Android e l'exe controllano la release più recente
e si aggiornano con un tocco su "Aggiorna ora".
L'APK è firmato con la chiave fissa `silent-key.jks`, così l'aggiornamento si installa sopra la versione esistente.
Prima di installare, app e exe controllano l'impronta SHA-256 del file scaricato rispetto a quella dichiarata
da GitHub per l'asset della release: se non combacia, il file viene scartato. Il controllo protegge da download
corrotti; non sostituisce la firma dell'APK.

## Registro del lavoro

Con l'ascolto attivo, l'app registra ogni secondo uno di tre stati:
- **Lavoro**: niente in riproduzione e dal PC arriva audio (o Silent ha messo in pausa il video);
  si resta "al lavoro" per 2 minuti dopo l'ultimo suono;
- **Riproduzione**: c'è un video/brano in play, quindi non stai lavorando;
- **Inattivo**: niente in riproduzione e nessun audio dal PC da oltre 2 minuti (pausa pranzo, tablet
  dimenticato acceso). Non conta né come lavoro né come riproduzione, quindi non falsa la percentuale.

I totali per giorno (ultimi 90 giorni) si vedono nella scheda "Lavoro". Ogni giorno all'ora scelta
(default 20:00) arriva una notifica con il report; il pulsante "Condividi report" lo manda dove vuoi.

## Novità 2.1

- **Durata minima del suono** (0-1000 ms, default 300) e **isteresi**: un "din" o un click breve non mette
  più in pausa il video. Il cursore è anche sul PC.
- **Il servizio riparte da solo** se Android lo chiude, e dopo il riavvio del tablet torna "a riposo"
  così il PC lo ritrova. Nelle impostazioni c'è il tasto per escludere Silent dal risparmio energetico.
- **PIN di abbinamento**: se impostato sul tablet (Impostazioni) e sul PC (Impostazioni), il tablet
  ignora comandi e audio da chi non conosce il PIN. Vuoto = nessuna protezione. Il PIN non è cifrato:
  tiene lontani i comandi casuali sulla rete, non un attaccante determinato.

## Novità 2.2

- **Silent PC nella tray**: l'icona vicino all'orologio apre la finestra con un clic; con il tasto destro
  c'è il menu (Apri, Avvia/Ferma invio, Esci). La X della finestra lo lascia nella tray e continua a
  inviare l'audio; si può cambiare in Impostazioni > Windows.
- **Avvio con Windows** (Impostazioni > Windows): Silent parte da solo, nascosto nella tray, e se
  "Avvia l'invio all'apertura" è attivo comincia a inviare appena trova il tablet.
- **Una sola copia alla volta**: se lo riapri mentre è già in tray, ti dice dove trovarlo.
- **Grafico a barre degli ultimi 7 giorni** nella scheda Lavoro dell'app (arancione = lavoro,
  grigio = riproduzione). Sul PC il report ha già le barre per giorno.
