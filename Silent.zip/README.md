# Silent

App Android che mette in pausa il video in riproduzione (Netflix, YouTube, Spotify...) finché c'è audio in ingresso.
Quando torna il silenzio per il tempo impostato, il video riparte.

Sorgente audio (selettore nell'app):
- **Tablet**: ascolta il microfono del tablet (o un microfono USB-C).
- **PC**: riceve l'audio via Wi-Fi dall'app Windows **Silent PC** (`pc/Silent.py`, compilata in `Silent-PC.exe`).

## Silent PC (Windows)

- Trova il tablet da sola (nessun IP da scrivere).
- Invia l'audio del PC (UDP 5005) e comanda il tablet (UDP 5006): soglia, ritardo, "pausa solo se suona",
  tasto unico play/pausa, Prova pausa / Prova play, avvia / ferma.
- Quello che cambi sul PC si vede sul tablet e viceversa.
- La prima volta Windows chiede il permesso di rete: scegli "Reti private".

## Aggiornamenti automatici (OTA)

A ogni caricamento di `Silent.zip` su GitHub, Actions compila APK ed EXE e li pubblica in una release
(`Silent.apk`, `Silent-PC.exe`). L'app Android e l'exe controllano la release più recente
e si aggiornano con un tocco su "Aggiorna ora".
L'APK è firmato con la chiave fissa `silent-key.jks`, così l'aggiornamento si installa sopra la versione esistente.

## Registro del lavoro

Con l'ascolto attivo, l'app registra ogni secondo lo stato della riproduzione:
- riproduzione **in pausa** = stai lavorando;
- riproduzione **in play** = non stai lavorando.

I totali per giorno (ultimi 90 giorni) si vedono nella scheda "Lavoro". Ogni giorno all'ora scelta
(default 20:00) arriva una notifica con il report; il pulsante "Condividi report" lo manda dove vuoi.
