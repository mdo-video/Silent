# Silent

App Android che mette in pausa il video in riproduzione (Netflix, YouTube, Spotify...) finché c'è audio in ingresso.
Quando torna il silenzio per il tempo impostato, il video riparte.

Sorgente audio (selettore nell'app):
- **Tablet**: ascolta il microfono del tablet (o un microfono USB-C).
- **PC**: riceve l'audio via Wi-Fi dall'app Windows `silent_pc_sender.py` (UDP, porta 5005).
