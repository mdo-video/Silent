"""
Script per creare l'eseguibile Windows di Silent PC Sender
con icona integrata e tutte le dipendenze.

Requisiti:
    pip install pyinstaller pyaudiowpatch numpy pillow

Uso:
    python build_exe.py
"""
import os
import sys
from pathlib import Path

try:
    import PyInstaller.__main__
    from PIL import Image
    import io
except ImportError:
    print("Installa le dipendenze: pip install pyinstaller pillow")
    sys.exit(1)

# Crea l'icona .ico dalla PNG generata
def create_icon():
    """Crea il file .ico dal logo Silent"""
    import numpy as np
    import struct
    import zlib

    def make_icon_png(size):
        """Genera il logo Silent"""
        ss = 4
        n = size * ss
        yy, xx = np.mgrid[0:n, 0:n]
        u = (xx + 0.5) / n * 108.0
        v = (yy + 0.5) / n * 108.0

        def rr(x1, y1, x2, y2, r):
            qx = np.abs(u - (x1 + x2) / 2) - ((x2 - x1) / 2 - r)
            qy = np.abs(v - (y1 + y2) / 2) - ((y2 - y1) / 2 - r)
            d = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
            return (d <= 0).astype(np.float32)

        tile = rr(2, 2, 106, 106, 24)
        bars = np.maximum(rr(33, 27, 51, 81, 4), rr(57, 27, 75, 81, 4)) * tile
        bg = np.array([0x0F, 0x14, 0x20], dtype=np.float32)
        fg = np.array([0xFF, 0x9F, 0x43], dtype=np.float32)
        rgb = bg[None, None, :] * (tile - bars)[:, :, None] + fg[None, None, :] * bars[:, :, None]
        pre = np.concatenate((rgb, (tile * 255.0)[:, :, None]), axis=2)
        pre = pre.reshape(size, ss, size, ss, 4).mean(axis=(1, 3))
        a = pre[:, :, 3]
        out = np.zeros((size, size, 4), dtype=np.uint8)
        nz = a > 0
        for c in range(3):
            ch = np.zeros_like(a)
            ch[nz] = pre[:, :, c][nz] / (a[nz] / 255.0)
            out[:, :, c] = np.clip(ch, 0, 255).astype(np.uint8)
        out[:, :, 3] = np.clip(a, 0, 255).astype(np.uint8)

        raw = b"".join(b"\x00" + out[y].tobytes() for y in range(size))

        def chunk(tag, data):
            body = tag + data
            return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

        return (b"\x89PNG\r\n\x1a\n"
                + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9))
                + chunk(b"IEND", b""))

    # Genera icone di varie dimensioni
    icon_path = Path("silent_icon.ico")

    sizes = [16, 32, 48, 64, 128, 256]
    images = []

    for size in sizes:
        png_data = make_icon_png(size)
        img = Image.open(io.BytesIO(png_data))
        images.append(img)

    # Salva come .ico multi-risoluzione
    images[0].save(
        icon_path,
        format='ICO',
        sizes=[(img.width, img.height) for img in images],
        append_images=images[1:]
    )

    print(f"✓ Icona creata: {icon_path}")
    return str(icon_path)


def build_exe():
    """Compila l'applicazione in un eseguibile"""

    print("=" * 60)
    print("Build Silent PC Sender")
    print("=" * 60)

    # Crea l'icona
    icon_path = create_icon()

    # Configura PyInstaller
    args = [
        'Silent_PC.py',                    # Script principale
        '--name=Silent_PC_Sender',          # Nome eseguibile
        '--onefile',                        # Singolo file eseguibile
        '--windowed',                       # Nascondi console
        f'--icon={icon_path}',             # Icona
        '--clean',                          # Pulisci cache
        '--noconfirm',                      # Sovrascrivi senza chiedere

        # Includi dipendenze nascoste
        '--hidden-import=pyaudiowpatch',
        '--hidden-import=numpy',
        '--hidden-import=tkinter',
        '--hidden-import=urllib.request',

        # Metadati Windows
        '--version-file=version_info.txt', # Se presente

        # Ottimizzazioni
        '--strip',                          # Rimuovi simboli debug
        '--optimize=2',                     # Ottimizzazione bytecode
    ]

    print("\n📦 Compilazione in corso...")
    print("   Questo può richiedere alcuni minuti...\n")

    try:
        PyInstaller.__main__.run(args)

        print("\n" + "=" * 60)
        print("✓ BUILD COMPLETATA!")
        print("=" * 60)
        print(f"\n📁 Eseguibile creato in: dist/Silent_PC_Sender.exe")
        print(f"   Dimensione: {os.path.getsize('dist/Silent_PC_Sender.exe') / (1024*1024):.1f} MB")
        print("\n💡 Puoi distribuire questo file singolo.")
        print("   Include tutto il necessario per funzionare.\n")

    except Exception as e:
        print(f"\n❌ Errore durante la build: {e}")
        sys.exit(1)


def create_version_info():
    """Crea file di versione per Windows"""
    version_info = """# UTF-8
#
# Per maggiori dettagli sul formato vedi:
# https://pyinstaller.org/en/stable/usage.html#capturing-windows-version-data

VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=(2, 0, 0, 0),
    prodvers=(2, 0, 0, 0),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
    ),
  kids=[
    StringFileInfo(
      [
      StringTable(
        u'040904B0',
        [StringStruct(u'CompanyName', u'MDO Video'),
        StringStruct(u'FileDescription', u'Silent PC Sender - Audio Control'),
        StringStruct(u'FileVersion', u'2.0.0.0'),
        StringStruct(u'InternalName', u'Silent PC Sender'),
        StringStruct(u'LegalCopyright', u'© 2026 MDO Video'),
        StringStruct(u'OriginalFilename', u'Silent_PC_Sender.exe'),
        StringStruct(u'ProductName', u'Silent PC Sender'),
        StringStruct(u'ProductVersion', u'2.0.0.0')])
      ]),
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)
"""

    with open("version_info.txt", "w", encoding="utf-8") as f:
        f.write(version_info)

    print("✓ File versione creato: version_info.txt")


if __name__ == "__main__":
    print("\n🚀 Silent PC Sender - Build Script\n")

    # Verifica prerequisiti
    if not Path("Silent_PC.py").exists():
        print("❌ Errore: Silent_PC.py non trovato!")
        print("   Esegui questo script dalla stessa cartella di Silent_PC.py")
        sys.exit(1)

    # Crea info versione
    create_version_info()

    # Compila
    build_exe()
