@echo off
chcp 65001 > nul
echo.
echo ═══════════════════════════════════════════════
echo   Silent PC Sender - Avvio Rapido
echo ═══════════════════════════════════════════════
echo.

REM Controlla se Python è installato
python --version > nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python non trovato!
    echo.
    echo Scarica Python da: https://www.python.org/downloads/
    echo Oppure usa l'eseguibile precompilato Silent_PC_Sender.exe
    echo.
    pause
    exit /b 1
)

echo ✓ Python trovato
echo.

REM Controlla se le dipendenze sono installate
python -c "import pyaudiowpatch" 2>nul
if %errorlevel% neq 0 (
    echo 📦 Installazione dipendenze necessarie...
    echo    Questo richiederà qualche minuto...
    echo.
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo.
        echo ❌ Errore installazione dipendenze
        pause
        exit /b 1
    )
    echo.
    echo ✓ Dipendenze installate
)

echo.
echo 🚀 Avvio Silent PC Sender...
echo.
python Silent_PC.py

if %errorlevel% neq 0 (
    echo.
    echo ❌ Errore durante l'esecuzione
    pause
)
