"""
Silent PC Sender - Versione Avanzata con OTA e controllo remoto
Invia l'audio del PC all'app Android Silent via Wi-Fi con gestione bidirezionale.

Installazione:
    pip install pyaudiowpatch numpy requests

Novità versione 2.0:
- Controllo soglia e durata dal PC
- Auto-riconoscimento IP dal tablet
- Sistema OTA per aggiornamenti automatici
- Interfaccia grafica rinnovata
- Comunicazione bidirezionale con il tablet
"""
import base64
import ctypes
import ctypes.wintypes
import json
import os
import queue
import socket
import struct
import threading
import time
import tkinter as tk
import zlib
from tkinter import ttk, messagebox
from urllib import request as urllib_request
from urllib.error import URLError
import tempfile
import sys
import subprocess

import numpy as np

try:
    import pyaudiowpatch as pyaudio
except ImportError:
    pyaudio = None

# Costanti
VERSION = "2.0.0"
PORT = 5005
CONTROL_PORT = 5006  # Porta per comunicazione bidirezionale
OUT_RATE = 16000
PACKET_SAMPLES = 512
CONFIG = os.path.join(os.path.expanduser("~"), ".silent_pc_sender.json")
UPDATE_URL = "https://raw.githubusercontent.com/YOUR_REPO/Silent/main/version.json"  # Modificare con URL reale

DEFAULT_LABEL = "Audio del PC - uscita predefinita (consigliato)"

# Colori
BG = "#0F1420"
CARD = "#1A2132"
TRACK = "#232C42"
WHITE = "#FFFFFF"
GREY = "#6B7690"
ORANGE = "#FF9F43"
GREEN = "#2ED573"
RED = "#E74C3C"

# Logo Silent (PNG base64 incorporato)
ICON_PNGS = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4K"
    "EZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2"
    "CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYw"
    "MPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZ"
    "AKbWPz9HbOBQAAAnLUlEQVR42u2dS5Ac2XWev3Myq7rQAKYBdGNIjsghONTDpEUBlCjJskgRCpsK2mLEzMa2FrYHYy+8sjQreTsL"
    "e+nwcGcvHIOJ8EL2woGRHSH6FcKE9aD5GoAcDklRnAFF8c1pPBvdXZV5jxeZWZVZlVmP7upGd9X5ERnoruqszMp7z3//c+655wpH"
    "HBvrj1d+l5G/CJXf1CZ9olbPlrDPO9SG10PD7zrhfrX+/OI+bfj+pzy/4frN32c57n/k9+L++v0ijD3fhu9/6Py33347/72+Y9rw"
    "yzZd72rqZc3fv/7zYo49tPJlg4DahMeWvx80TPGIp8Dw9WT4c4d/16H7ndRUYuga2mA8Y85vuP5+zz+e9z8GjQPC6Pkmx996jh0B"
    "2EhDjDZumNTYonVku3eI7oG0xrH48OfXE87e73+/pHfc738ag28g9zGjtRPAgYzukxq+jpmnVAAHdp/TGUD/7FlHEpnx/mWGTr0M"
    "97/ntqsR3OYEMKNxhBkbYcbRvf7z1oBLIwpgXhJuxAWYTTEE29sz3fP9yz5H0ON+/8N9pJZQ9AaEu0jS2K5io26MWgOtNX5ZW3QC"
    "ODQ5d9FELwCXML0EnAEujw+g6HQycGaD19lG0D2OgEdGARy3+698hmbv2xh1Kcl14E5GCtxQwi3gZmHTEmoGOdPZ+9UjgBy+gYeZ"
    "ZP65jY2Rhssl/kXgmdzILwFnQr8hp+sgGXuHQyCt8d95soysPz/IfK6/fPc/y2eFkfM1+/0OcAO4rqbXgJtioTp7IIHNYhagf62h"
    "exmeBrB52Vs4qgQw299WCMD0aRN9Jjf8MyOdyJQwozy0IZYWm7fxD19HZ7zecCcePw3V/HnB77/OAEz3QB6jjqgad4BrwDWx8Eqh"
    "LDc3fzzh40tfWMIiEED10WysbwyNuuMf+GiUn4vA8wOj14pcGx5FDpoAmue969TFaEeXObt80xvQbEGrZb3/4vPHnz8u90RzMgjX"
    "kPAicLNQA5X7yw1f+0LAgHSEeO5s3t7TcBSaLN0eKQHoKHeWH4xpuUM8C1yp+vE6MZEkyOzycNbOMa0iqOtEcgAxn/3dP0tz/xN7"
    "ru39+/fPzfunDhKIriPhKoSXy329ngAYIYGFJ4DR4Kg+G4QXgAtTBeD2KdGHMwH1gBRAU2fc7zTSaBT6YEbQRbl/3aMCaPz+YSiQ"
    "XJdJKAGywOELarycKX+rmGpBAIPelFYVQP/z9+gAyDwd2j2RwqSpPn0W9K0gXG00fofjOCILTF8ArgJv5ep2yDaG7SOaceCbx3A9"
    "d4PPgnKBwZGN+to/QD+O6WuYXsX0ApbL/KZjzLUOjc8cjjojH5s12O+jF0Cvgr4G+vGR/lv5nKjar6cggcBs81p6MIbfzFylLL01"
    "4CVMr1NO0nE4FloJ9HEJuA68lNsC45OTjpUCmIingVtkQT6HY5lxBbglIk+LCCJRfggyrAAWgADWcsa7Rj6P73A4OJPbREkNTKmw"
    "94k9zAKMn+cfyfKyft73xSwIopfGzeO7H+9YTIz3zM0sm2KUcCNXBTezKEAe9s9nAfprDfLff/L2T4Y+aDbLPixrezrzd6rG73A4"
    "SrYrldjA0xUTteMbA/g9l/wOxwQpLoKIoEQo0RkluqZEv3fQZqrz+5iyf9KfzngJeNGn6ByOPeHFPC4wsKk521G8f45omPoTXgKu"
    "WLFCr1g7Le7nO5YR0/b5kZWPV/LXn6u6BNQvN5aDuavZjD9jrStl32UQ7HPjdzhmxBXQlw7CdvZdEKQm57hv/NnoPzD+unxqNW9d"
    "h6NpTB6YR7gimb091x/l6wqlzFiEJJ7HTZZQNX7GG7/D4Zgehl6R7IeMBIx9zw7IJOOuXc9ff9HfA1600vtlo29yAVwBOBxjhlob"
    "0tvZCP888GkoLU+WhGrdgez/zbc3h6VEBdEkTlhdXa2Qg9WP/k+TJfnQVO5psOxX9hOzcDiWCvXWIp+E6AboN8TymoZY6W3rW/z2"
    "9vbetPzUskS4aMJVk3rZXxxVEqgqg+G/czgcE+3jKnDRJPcERPdUZXm/BLCW38iZYanfrAAcDscccCa3vbX6bEGdDwEE0dJRGHN/"
    "Pf+LoJcqa5n7H1s9xHSKAowOh2Oyyfbt6BLoiwPjH7bDeSuAQUnuwu+/Un5vTl6Fw+GYHldAn66qgFLWoM2TAEalv8PhePTIXYHD"
    "iwG8iC/ucTiOUjzgxb3kBEx9htGPMn4cuFLULuvX+xuKUqpVj6Ja2fDro3/ncDhmjAXkrgAfrzVpm68CeNEfvsNxJDGzbc5KAM/i"
    "BTwdjqOKS1RKjs+fAF44mJCCw+GYk0vwwlynAbNMIwV4NggXgjDk8w8VA2mojz4cC5i9grnD4Rg10GF70wuZCpguH0Anvj1Y2PPC"
    "rEkGDofjkaiBF6r5APvX7M/i23U5HEcOQUJ2FIIgU+0XTHh2mvT7CQTQl+hX/FE7HEcYEobX30xls7KxsdHALJl/YcQXQW9U6/xP"
    "2gONmsokYZ8ixOFwTBzRrb8bMUi4BOFmxeBtdut7vmrcbrAOx5HGwP9/fpK9NiuAPLJvxLcxPTN1UU9XAA7HocYABqN/1SWAcEcJ"
    "Z8v2N6sCeBrP+Xc4jgkZjLx0BtOnx5m61o38gf5+fs9gWS2Axs09TKuHw+E4KhEBQJ+pr9MxQQHkUwjPeJkuh+NY45lx+QBjhmy9"
    "iKnLf4fjeOMMcHGcRqjK+cHLz/izczgWRQU0EIBYGAoi5Ov+TS8HmcKnl1B/1PsjNYfD4Zg7qjG5y9U3Q992FYoy4lr2/Qniy34d"
    "jgXBparCpz9INw3BF/HpP4dj4eMA2iAfLhzUfuQOh+NRQC9MTQCF/PcdexyOhYkFVFz6oj5HPMIH2V5jl7xUh8OxaHGAfJ+AYmdh"
    "CY3bg7v/73AsAAr1rg02LefXz1Hs+huk/78Fqjv9eMluh+MoGnhVqzfZqWZTfyIW8p/DWAXgcDiO8YhfHbhHHfpiR/G6IOCaP0aH"
    "Y5GQxfbEWNPRd+qCBQ6HY7EUQb1t+yS/w7HEiJ0DFn4MmCwPHcvpGJgWQcBSDXHxDuFwLG4sIAsAap4H4NY+LSqrqzxN6sgqneHK"
    "VF6papILMI1UWHLD76uk4aXTWRlmJSG2hFZIaFmXyBKU5FCIIuRbtwVietKhqx1S2hRLuc0Mkb3lcosIapp9hgVUurTDQyK6KNl3"
    "lAPe1l0MTLLvl0pMSpuexvSkTSra/57Ve9CxW2I7piYA7T/YpkZe1HUCxb4I5PUQNa+bUHzfbNl0YLf3ENm+zTs7KU+uCp/62CU+"
    "9L7z/I2nfopWHFAFiRURyQ2xSgpms/bU6mjWWjnBjTe+yf/585t89ms/5PUfKmnnnWjUoZcmaKSMt//m60coSkToJUSScqazy3tW"
    "7/PRi+/hN3715/mp976DtqWVvjFr1dlhiizvZiMGvYcJvSTiG29+n//31be4/tpbfG9Xedg5x+Yu0GrTT3Mp9dMgcZ+gF1mxaYO6"
    "mdYu5fz6Bv1MQBQT/XhArw8z61ISAIDF1a5aLsNMl7WVBL33I5797V/hH/2dX+axZJPTssWJKBCTQpQiZauQYQJIZzL4spxNMZIA"
    "iZ4giU+xFb2T/3Dtc/ynz3yRXuc893qKxrKvziVdw7bvst7Z5R///Y/wO7/1QdbbD+i0d+nd+wkn20JcKiozTAATR2IZRwAtSFtY"
    "GpPqCr2Vdd68E7j2J6/zB//7C9yLTnM3tAm6UqvY+kkwsnwuW9kus4U/AYHLauFVIfQ3EIlOrq7mrSAYAiIXDLli+bAh9e1U22CL"
    "BCHkTyTFJM0rHWWEEAclssBq2OLkg5/w+899gn/2zN9mZfd7nI4esKIJsa6AKopVO+B+LaT8u0SYRogZ2tsm7t7nlz/wXn7lF3+e"
    "z7/xTe7vBpC8XfcUMkpZjYUnVnf4t7/7NL/94XfwxOoOcbjHzs5DDCM2I9bmu53iQY/5PUZWztDd3sHCFp0OdNqBD33gZ1g70ear"
    "X36DxFYIrKAWZ+6A9EASkICQogQEWdh+yhR2WbLuq4J9O/vZQMwJYJI0VrLOFDQAQhRaSAh0rMdj6W3+1T//BM987GeJtr7LmdYu"
    "bdtBFYwoD7f2sod9AAQgGKpKW4V2LHRa0OreZ+2xE6y/+7289vobbCdCkfFduBuTYgJRlPn9bXZpb3+ff/O7v8OvvUdZ3f0OUXoP"
    "S3eIIiVWpSUByOIMYnti2mZ+kxgsIlJQ6RJ625zotLDuA5584nHWz23wxdf/kq51CNICUYImoClRP+ddAcNEnABqCED9Hnh8/EOM"
    "weIJAhaEODVOx11+/Rd+ik/+6rs5sfNXnEwfEO1sowE0BNAd0B0s3711XJCremh+MNGghICGLqS7kPYg6ZL27nD+VI+P/WyHf/L3"
    "foFTcRcjxdKQSUECYmn2GmnF0cidPkRitre3ke5d/uU//CgfeXfKxomHnOoY7XZMpxWzqimr2iPGiCgZvzFjAK6+VmRA811vt5Bo"
    "F40iIo3g4X1ORZt86qPv45d+5jzx7m3C9i5ChIghYkRiqAiikqmkPAYzfHgvd0x+RCW/+/TJk0TWxbZ+xD/9B79F2x7Q4iEt2wHr"
    "AkkmQUlywz9g/9NK4TRN6Zxcobf1Q9bCD/jkr72fc6diQhowM8KEgKMFI4RAoAGmB2tropla9v8UyMzGeD2RwqSpPn0W9K0gXG00"
    "fofjOCILTF8ArgJv5ep2yDaG7SOaceCbx3A9d4PPgnKBwZGN+to/QD+O6WuYXsX0ApbL/KZjzLUOjc8cjjojH5s12O+jF0Cvgr4G"
    "+vGR/lv5nKjar6cggcBs81p6MIbfzFylLL014CVMr1NO0nE4FloJ9HEJuA68lNsC45OTjpUCmIingVtkQT6HY5lxBbglIk+LCCJRfg=="
)


def load_config():
    try:
        with open(CONFIG, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    try:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
    except Exception:
        pass


def check_for_updates():
    """Controlla se è disponibile una nuova versione"""
    try:
        with urllib_request.urlopen(UPDATE_URL, timeout=5) as response:
            data = json.loads(response.read().decode())
            latest = data.get("version", VERSION)
            if latest > VERSION:
                return {
                    "available": True,
                    "version": latest,
                    "url": data.get("download_url"),
                    "notes": data.get("notes", "")
                }
    except (URLError, Exception):
        pass
    return {"available": False}


def download_update(url, callback=None):
    """Scarica l'aggiornamento"""
    try:
        temp_file = os.path.join(tempfile.gettempdir(), "Silent_PC_update.exe")

        def report(block_num, block_size, total_size):
            if callback and total_size > 0:
                percent = min(100, (block_num * block_size * 100) // total_size)
                callback(percent)

        urllib_request.urlretrieve(url, temp_file, reporthook=report)
        return temp_file
    except Exception as e:
        return None


def list_devices(p):
    """Ritorna ([(etichetta, info_dispositivo)], indice_predefinito)."""
    devices = []
    try:
        wasapi = p.get_host_api_info_by_type(pyaudio.paWASAPI)
    except Exception:
        return devices, 0
    devices.append((DEFAULT_LABEL, None))
    for lb in p.get_loopback_device_info_generator():
        devices.append(("Audio del PC - " + lb["name"].replace(" [Loopback]", ""), lb))
    for i in range(p.get_device_count()):
        d = p.get_device_info_by_index(i)
        if (d["hostApi"] == wasapi["index"] and d["maxInputChannels"] > 0
                and not d.get("isLoopbackDevice", False)):
            devices.append(("Microfono - " + d["name"], d))
    return devices, 0


class StreamResampler:
    """Ricampionamento in streaming con filtro anti-aliasing."""

    def __init__(self, in_rate, out_rate):
        self.ratio = in_rate / float(out_rate)
        self.buf = np.zeros(0, dtype=np.float64)
        self.pos = 0.0

    def process(self, x):
        self.buf = np.concatenate((self.buf, x.astype(np.float64)))
        n_out = int((len(self.buf) - self.pos) // self.ratio)
        if n_out <= 0:
            return np.zeros(0, dtype=np.float32)
        edges = self.pos + np.arange(n_out + 1) * self.ratio
        csum = np.concatenate(([0.0], np.cumsum(self.buf)))
        ci = np.interp(edges, np.arange(len(csum)), csum)
        out = np.diff(ci) / self.ratio
        end = edges[-1]
        drop = int(end)
        self.buf = self.buf[drop:]
        self.pos = end - drop
        return out.astype(np.float32)


class ControlReceiver:
    """Riceve comandi dal tablet (auto-riconoscimento IP, sincronizzazione parametri)"""

    def __init__(self, callback):
        self.callback = callback
        self.sock = None
        self.thread = None
        self.running = False

    def start(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("0.0.0.0", CONTROL_PORT))
            self.sock.settimeout(1.0)
            self.running = True
            self.thread = threading.Thread(target=self._receive_loop, daemon=True)
            self.thread.start()
        except Exception as e:
            print(f"Errore avvio receiver: {e}")

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=2.0)
        if self.sock:
            try:
                self.sock.close()
            except:
                pass

    def _receive_loop(self):
        while self.running:
            try:
                data, addr = self.sock.recvfrom(1024)
                try:
                    msg = json.loads(data.decode('utf-8'))
                    if self.callback:
                        self.callback(msg, addr[0])
                except:
                    pass
            except socket.timeout:
                continue
            except Exception:
                break


class Sender:
    """Cattura l'audio e lo spedisce in UDP al tablet."""

    def __init__(self):
        self.p = None
        self.stream = None
        self.sock = None
        self.q = queue.Queue(maxsize=256)
        self.thread = None
        self.running = False
        self.level = 0
        self.error = ""
        self.audio_msg = ""
        self.device = None
        self.follow_default = False
        self.current_index = None
        self.channels = 2
        self.rate = 48000
        self.resampler = None
        self.target = None
        self.threshold = 62
        self.delay_sec = 25

    def start(self, device, ip, threshold=62, delay_sec=25):
        self.error = ""
        self.audio_msg = ""
        self.device = device
        self.follow_default = device is None
        self.target = (ip, PORT)
        self.threshold = threshold
        self.delay_sec = delay_sec
        self.q = queue.Queue(maxsize=256)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._open_stream()
        self.running = True
        self.thread = threading.Thread(target=self._send_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread is not None:
            self.thread.join(timeout=1.5)
        self._close_stream()
        try:
            if self.sock is not None:
                self.sock.close()
        except Exception:
            pass
        self.sock = self.thread = None
        self.level = 0
        self.audio_msg = ""

    def send_settings(self):
        """Invia le impostazioni correnti al tablet"""
        if self.target and self.running:
            try:
                msg = json.dumps({
                    "type": "settings",
                    "threshold": self.threshold,
                    "delay": self.delay_sec
                }).encode('utf-8')
                self.sock.sendto(msg, (self.target[0], CONTROL_PORT))
            except:
                pass

    def _callback(self, in_data, frame_count, time_info, status):
        try:
            self.q.put_nowait(in_data)
        except queue.Full:
            pass
        return (None, pyaudio.paContinue)

    def _open_stream(self):
        self._close_stream()
        p = pyaudio.PyAudio()
        try:
            dev = self.device if self.device is not None else p.get_default_wasapi_loopback()
            channels = max(1, int(dev["maxInputChannels"]))
            rate = int(dev["defaultSampleRate"])
            stream = p.open(
                format=pyaudio.paInt16,
                channels=channels,
                rate=rate,
                frames_per_buffer=1024,
                input=True,
                input_device_index=int(dev["index"]),
                stream_callback=self._callback,
            )
        except Exception:
            p.terminate()
            raise
        self.p = p
        self.stream = stream
        self.channels = channels
        self.rate = rate
        self.current_index = int(dev["index"])
        self.resampler = StreamResampler(rate, OUT_RATE)

    def _close_stream(self):
        try:
            if self.stream is not None:
                self.stream.stop_stream()
                self.stream.close()
        except Exception:
            pass
        try:
            if self.p is not None:
                self.p.terminate()
        except Exception:
            pass
        self.stream = None
        self.p = None

    def _default_index(self):
        p = pyaudio.PyAudio()
        try:
            return int(p.get_default_wasapi_loopback()["index"])
        except Exception:
            return None
        finally:
            p.terminate()

    def _health_check(self):
        """Riapre lo stream se necessario"""
        try:
            reopen = False
            if self.stream is None or not self.stream.is_active():
                reopen = True
            elif self.follow_default:
                idx = self._default_index()
                if idx is not None and idx != self.current_index:
                    reopen = True
            if reopen:
                self.audio_msg = "Riconnessione audio..."
                self._open_stream()
                self.audio_msg = ""
        except Exception as e:
            self.audio_msg = f"Audio non disponibile, riprovo ({e})"

    def _to_mono(self, data):
        a = np.frombuffer(data, dtype=np.int16)
        if self.channels > 1:
            a = a[: len(a) - len(a) % self.channels].reshape(-1, self.channels)
            return a.astype(np.float32).mean(axis=1)
        return a.astype(np.float32)

    def _send_loop(self):
        buf = np.zeros(0, dtype=np.int16)
        silence = bytes(PACKET_SAMPLES * 2)
        last_check = time.monotonic()
        last_settings = time.monotonic()

        while self.running:
            now = time.monotonic()
            if now - last_check >= 2.0:
                last_check = now
                self._health_check()

            # Invia settings ogni 5 secondi
            if now - last_settings >= 5.0:
                last_settings = now
                self.send_settings()

            try:
                data = self.q.get(timeout=0.1)
            except queue.Empty:
                self.level = 0
                self._send(silence)
                continue

            mono = self._to_mono(data)
            if len(mono) == 0 or self.resampler is None:
                continue

            out = np.clip(self.resampler.process(mono), -32768, 32767).astype(np.int16)
            buf = np.concatenate((buf, out))

            while len(buf) >= PACKET_SAMPLES:
                chunk, buf = buf[:PACKET_SAMPLES], buf[PACKET_SAMPLES:]
                rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))
                db = -100.0 if rms < 1.0 else 20.0 * np.log10(rms / 32768.0)
                self.level = int(min(100, max(0, (db + 70.0) / 70.0 * 100.0)))
                self._send(chunk.astype("<i2").tobytes())

    def _send(self, payload):
        try:
            self.sock.sendto(payload, self.target)
            self.error = ""
        except Exception as e:
            self.error = str(e)


def resolve_host(text):
    """Accetta un IP o nome di rete e restituisce l'IP"""
    try:
        return socket.gethostbyname(text)
    except Exception:
        return None


# ===== INTERFACCIA GRAFICA =====

def make_icon_png(size):
    """Logo di Silent come PNG RGBA"""
    ss = 4
    n = size * ss
    yy, xx = np.mgrid[0:n, 0:n]
    u = (xx + 0.5) / n * 108.0
    v = (yy + 0.5) / n * 108.0

    def rr(x1, y1, x2, y2, r):
        qx = np.abs(u - (x1 + x2) / 2) - ((x2 - x1) / 2 - r)
        qy = np.abs(v - (y1 + y2) / 2) - ((y2 - y1) / 2 - r)
        d = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
        return (d <= 0).astype(np.float32)

    tile = rr(2, 2, 106, 106, 24)
    bars = np.maximum(rr(33, 27, 51, 81, 4), rr(57, 27, 75, 81, 4)) * tile
    bg = np.array([0x0F, 0x14, 0x20], dtype=np.float32)
    fg = np.array([0xFF, 0x9F, 0x43], dtype=np.float32)
    rgb = bg[None, None, :] * (tile - bars)[:, :, None] + fg[None, None, :] * bars[:, :, None]
    pre = np.concatenate((rgb, (tile * 255.0)[:, :, None]), axis=2)
    pre = pre.reshape(size, ss, size, ss, 4).mean(axis=(1, 3))
    a = pre[:, :, 3]
    out = np.zeros((size, size, 4), dtype=np.uint8)
    nz = a > 0
    for c in range(3):
        ch = np.zeros_like(a)
        ch[nz] = pre[:, :, c][nz] / (a[nz] / 255.0)
        out[:, :, c] = np.clip(ch, 0, 255).astype(np.uint8)
    out[:, :, 3] = np.clip(a, 0, 255).astype(np.uint8)

    raw = b"".join(b"\x00" + out[y].tobytes() for y in range(size))

    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9))
            + chunk(b"IEND", b""))


def rrect(c, x1, y1, x2, y2, r, **kw):
    """Rettangolo arrotondato"""
    r = max(0, min(r, (x2 - x1) / 2.0, (y2 - y1) / 2.0))
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
           x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


class Card(tk.Canvas):
    """Card con sfondo arrotondato"""

    def __init__(self, parent, bg, fill, radius, pad):
        super().__init__(parent, bg=bg, highlightthickness=0, bd=0, height=10)
        self.fill, self.radius, self.pad = fill, radius, pad
        self.inner = tk.Frame(self, bg=fill)
        self.win = self.create_window(pad, pad, window=self.inner, anchor="nw")
        self.bind("<Configure>", self._on_canvas)
        self.inner.bind("<Configure>", self._on_inner)

    def _on_inner(self, event):
        h = self.inner.winfo_reqheight() + 2 * self.pad
        if int(self.cget("height")) != h:
            self.config(height=h)

    def _on_canvas(self, event):
        self.delete("bg")
        rrect(self, 0, 0, event.width, event.height, self.radius, fill=self.fill, outline="", tags="bg")
        self.tag_lower("bg")
        self.itemconfig(self.win, width=max(1, event.width - 2 * self.pad))


class RoundButton(tk.Canvas):
    """Pulsante arrotondato"""

    def __init__(self, parent, text, command, fill, fg, bg, height, font, width=None):
        kw = {"width": width} if width else {}
        super().__init__(parent, height=height, bg=bg, highlightthickness=0, bd=0,
                         cursor="hand2", **kw)
        self.text, self.command, self.fill, self.fg, self.font = text, command, fill, fg, font
        self.enabled = True
        self.bind("<Configure>", lambda e: self.redraw())
        self.bind("<Button-1>", self._click)

    def redraw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        rrect(self, 0, 0, w, h, h / 2.0, fill=self.fill if self.enabled else TRACK, outline="")
        self.create_text(w / 2.0, h / 2.0, text=self.text,
                         fill=self.fg if self.enabled else GREY, font=self.font)

    def configure_button(self, text=None, fill=None, fg=None):
        if text is not None:
            self.text = text
        if fill is not None:
            self.fill = fill
        if fg is not None:
            self.fg = fg
        self.redraw()

    def set_enabled(self, enabled):
        self.enabled = enabled
        self.config(cursor="hand2" if enabled else "arrow")
        self.redraw()

    def _click(self, event):
        if self.enabled and self.command:
            self.command()


class LevelBar(tk.Canvas):
    """Barra livello audio"""

    def __init__(self, parent, bg, height):
        super().__init__(parent, height=height, bg=bg, highlightthickness=0, bd=0)
        self.level = 0
        self.bind("<Configure>", lambda e: self.draw())

    def set_level(self, level):
        if level != self.level:
            self.level = level
            self.draw()

    def draw(self):
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        rrect(self, 0, 0, w, h, h / 2.0, fill=TRACK, outline="")
        if self.level > 0:
            fw = max(w * self.level / 100.0, h)
            rrect(self, 0, 0, fw, h, h / 2.0, fill=GREEN if self.level < 40 else ORANGE, outline="")


class StatusCircle(tk.Canvas):
    """Cerchio di stato con icona"""

    def __init__(self, parent, bg, size):
        super().__init__(parent, width=size, height=size, bg=bg, highlightthickness=0, bd=0)
        self.size = size
        self.state = None

    def set(self, color, icon):
        if self.state == (color, icon):
            return
        self.state = (color, icon)
        self.delete("all")
        s = self.size
        self.create_oval(2, 2, s - 2, s - 2, fill=color, outline="")
        k = s * 0.49 / 24.0
        off = (s - 24 * k) / 2.0

        def p(x, y):
            return (off + x * k, off + y * k)

        if icon == "play":
            self.create_polygon(*p(8, 5), *p(8, 19), *p(19, 12), fill=WHITE, outline="")
        elif icon == "pause":
            self.create_rectangle(*p(6, 5), *p(10, 19), fill=WHITE, outline="")
            self.create_rectangle(*p(14, 5), *p(18, 19), fill=WHITE, outline="")
        else:
            self.create_text(s / 2.0, s / 2.0, text="!", fill=WHITE,
                             font=("Segoe UI", max(12, int(s * 0.16)), "bold"))


def enable_dpi_awareness():
    """Testo nitido su schermi HiDPI"""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("mdovideo.silent.pcsender")
    except Exception:
        pass


def dark_title_bar(root):
    """Barra titolo scura (Windows 10/11)"""
    try:
        root.update()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        for attr, val in ((20, 1), (19, 1)):
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(ctypes.c_int(val)), ctypes.sizeof(ctypes.c_int))
        color = ctypes.c_int(0x20140F)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(color), ctypes.sizeof(color))
    except Exception:
        pass


class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.sender = Sender()
        self.control_receiver = ControlReceiver(self.on_control_message)
        self.notice = None
        self.compact = False
        self.sc = max(1.0, root.winfo_fpixels("1i") / 96.0)
        self.tablet_ip = None  # IP rilevato automaticamente

        S = self.S
        root.title(f"Silent PC Sender v{VERSION}")
        root.configure(bg=BG)
        root.resizable(False, False)

        # Icone
        try:
            icon_data = base64.b64decode(ICON_PNGS)
            self.icons = [tk.PhotoImage(data=icon_data)]
            root.iconphoto(True, *self.icons)
        except Exception:
            self.icons = []

        try:
            self.icon_small = tk.PhotoImage(data=base64.b64encode(make_icon_png(S(46))))
        except Exception:
            self.icon_small = None

        # Style per combobox
        style = ttk.Style()
        style.theme_use("clam")
        root.option_add("*TCombobox*Listbox.background", TRACK)
        root.option_add("*TCombobox*Listbox.foreground", WHITE)
        root.option_add("*TCombobox*Listbox.selectBackground", ORANGE)
        root.option_add("*TCombobox*Listbox.selectForeground", BG)
        root.option_add("*TCombobox*Listbox.font", ("Segoe UI", 10))
        style.configure("Silent.TCombobox", fieldbackground=TRACK, background=TRACK,
                        foreground=WHITE, arrowcolor=WHITE, bordercolor=TRACK,
                        lightcolor=TRACK, darkcolor=TRACK, selectbackground=TRACK,
                        selectforeground=WHITE, padding=S(6))
        style.map("Silent.TCombobox",
                  fieldbackground=[("readonly", TRACK), ("disabled", CARD)],
                  foreground=[("readonly", WHITE), ("disabled", GREY)],
                  selectbackground=[("readonly", TRACK)],
                  selectforeground=[("readonly", WHITE)],
                  background=[("active", TRACK), ("readonly", TRACK)],
                  arrowcolor=[("disabled", GREY)])

        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True, padx=S(22), pady=S(12))

        # Pulsante principale
        self.btn = RoundButton(outer, "Avvia invio", self.toggle, ORANGE, BG, BG, S(48),
                               ("Segoe UI", 13, "bold"))
        self.btn.pack(side="bottom", fill="x", pady=(S(12), 0))

        # Header
        self.head = tk.Frame(outer, bg=BG)
        self.head.pack()
        if self.icon_small is not None:
            tk.Label(self.head, image=self.icon_small, bg=BG).pack()
        tk.Label(self.head, text="Silent PC", bg=BG, fg=WHITE,
                 font=("Segoe UI", 20, "bold")).pack()
        tk.Label(self.head, text="Controllo audio intelligente per video editing", bg=BG, fg=GREY,
                 font=("Segoe UI", 10)).pack()

        # Cerchio di stato
        self.circle = StatusCircle(outer, BG, S(104))
        self.circle.pack(pady=(S(10), S(6)))
        self.status = tk.Label(outer, text="Fermo", bg=BG, fg=WHITE, height=2,
                               font=("Segoe UI", 12, "bold"), wraplength=S(400), justify="center")
        self.status.pack()
        self.input_lbl = tk.Label(outer, text="Ingresso: -", bg=BG, fg=GREY, font=("Segoe UI", 9))
        self.input_lbl.pack(pady=(0, S(6)))

        # Barra livello
        self.bar = LevelBar(outer, BG, S(24))
        self.bar.pack(fill="x")

        # Card connessione
        card = Card(outer, BG, CARD, S(18), S(14))
        card.pack(fill="x", pady=(S(12), 0))
        self.card = card
        c = card.inner

        tk.Label(c, text="IP del tablet", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w")

        ip_frame = tk.Frame(c, bg=CARD)
        ip_frame.pack(fill="x", pady=(S(4), S(8)))

        self.ip_var = tk.StringVar(value=self.cfg.get("ip", ""))
        self.ip_entry = tk.Entry(ip_frame, textvariable=self.ip_var, bg=TRACK, fg=WHITE,
                                 insertbackground=WHITE, relief="flat",
                                 disabledbackground=TRACK, disabledforeground=GREY,
                                 highlightthickness=S(1), highlightbackground=TRACK,
                                 highlightcolor=ORANGE, font=("Segoe UI", 12))
        self.ip_entry.pack(side="left", fill="x", expand=True, ipady=S(5))

        self.auto_btn = RoundButton(ip_frame, "Auto", self.use_auto_ip, GREEN, BG, CARD,
                                    S(32), ("Segoe UI", 9, "bold"), width=S(60))
        self.auto_btn.pack(side="right", padx=(S(8), 0))

        self.ip_status = tk.Label(c, text="", bg=CARD, fg=GREY, font=("Segoe UI", 8))
        self.ip_status.pack(anchor="w")

        row = tk.Frame(c, bg=CARD)
        row.pack(fill="x", pady=(S(8), 0))
        tk.Label(row, text="Audio da inviare", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 10)).pack(side="left")
        self.refresh_btn = RoundButton(row, "Aggiorna", self.refresh_devices, TRACK, WHITE, CARD,
                                       S(28), ("Segoe UI", 9), width=S(84))
        self.refresh_btn.pack(side="right")

        self.devices = []
        self.combo = ttk.Combobox(c, state="readonly", style="Silent.TCombobox",
                                  font=("Segoe UI", 10))
        self.combo.pack(fill="x", pady=(S(6), S(8)))

        # Card controlli avanzati
        card2 = Card(outer, BG, CARD, S(18), S(14))
        card2.pack(fill="x", pady=(S(8), 0))
        c2 = card2.inner

        tk.Label(c2, text="Controlli avanzati", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, S(8)))

        # Soglia audio
        tk.Label(c2, text="Soglia audio rilevamento", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.threshold_label = tk.Label(c2, text="62", bg=CARD, fg=ORANGE,
                                        font=("Segoe UI", 10, "bold"))
        self.threshold_label.pack(anchor="w")
        self.threshold_var = tk.IntVar(value=self.cfg.get("threshold", 62))
        threshold_seek = tk.Scale(c2, from_=0, to=100, orient="horizontal",
                                  variable=self.threshold_var, bg=CARD, fg=WHITE,
                                  highlightthickness=0, troughcolor=TRACK, activebackground=ORANGE,
                                  showvalue=0, command=self.update_threshold_label)
        threshold_seek.pack(fill="x", pady=(S(4), S(12)))

        # Ritardo ripartenza
        tk.Label(c2, text="Ritardo ripartenza video (secondi)", bg=CARD, fg=WHITE,
                 font=("Segoe UI", 9)).pack(anchor="w")
        self.delay_label = tk.Label(c2, text="25 s", bg=CARD, fg=ORANGE,
                                    font=("Segoe UI", 10, "bold"))
        self.delay_label.pack(anchor="w")
        self.delay_var = tk.IntVar(value=self.cfg.get("delay_sec", 25))
        delay_seek = tk.Scale(c2, from_=1, to=60, orient="horizontal",
                              variable=self.delay_var, bg=CARD, fg=WHITE,
                              highlightthickness=0, troughcolor=TRACK, activebackground=ORANGE,
                              showvalue=0, command=self.update_delay_label)
        delay_seek.pack(fill="x", pady=(S(4), S(8)))

        # Opzioni
        self.autostart_var = tk.BooleanVar(value=bool(self.cfg.get("autostart", False)))
        tk.Checkbutton(c2, text="Avvia l'invio all'apertura", variable=self.autostart_var,
                       bg=CARD, fg=WHITE, selectcolor=TRACK, activebackground=CARD,
                       activeforeground=WHITE, font=("Segoe UI", 9), highlightthickness=0,
                       bd=0).pack(anchor="w", pady=(S(4), 0))

        # Verifica aggiornamenti
        if pyaudio is None:
            self.notice = ("Manca pyaudiowpatch: pip install pyaudiowpatch numpy", RED)
            self.btn.set_enabled(False)
            self.refresh_btn.set_enabled(False)
        else:
            self.refresh_devices()
            # Avvia receiver per auto-riconoscimento IP
            self.control_receiver.start()

        root.protocol("WM_DELETE_WINDOW", self.close)
        dark_title_bar(root)
        self.fit()
        root.after(120, self.fit)
        root.after(500, self.fit)

        # Controlla aggiornamenti all'avvio
        root.after(2000, self.check_updates)

        self.tick()

        if (pyaudio is not None and self.autostart_var.get()
                and self.ip_var.get().strip() and self.devices):
            root.after(700, self.toggle)

    def S(self, v):
        return int(round(v * self.sc))

    def on_control_message(self, msg, ip):
        """Gestisce i messaggi dal tablet"""
        msg_type = msg.get("type")

        if msg_type == "announce":
            # Il tablet si annuncia con il suo IP
            self.tablet_ip = ip
            self.root.after(0, lambda: self.ip_status.config(
                text=f"✓ Tablet rilevato: {ip}",
                fg=GREEN
            ))
        elif msg_type == "settings_request":
            # Il tablet richiede le impostazioni
            if self.sender.running:
                self.sender.send_settings()

    def use_auto_ip(self):
        """Usa l'IP rilevato automaticamente"""
        if self.tablet_ip:
            self.ip_var.set(self.tablet_ip)
            self.notice = None
        else:
            self.notice = ("Nessun tablet rilevato. Avvia l'app Silent sul tablet.", ORANGE)

    def check_updates(self):
        """Controlla disponibilità aggiornamenti"""
        def check_thread():
            update_info = check_for_updates()
            if update_info["available"]:
                self.root.after(0, lambda: self.show_update_dialog(update_info))

        threading.Thread(target=check_thread, daemon=True).start()

    def show_update_dialog(self, info):
        """Mostra dialog aggiornamento disponibile"""
        response = messagebox.askyesno(
            "Aggiornamento disponibile",
            f"È disponibile la versione {info['version']}.\n\n"
            f"{info.get('notes', '')}\n\n"
            "Vuoi scaricare e installare l'aggiornamento?",
            icon='info'
        )
        if response:
            self.download_and_install_update(info["url"])

    def download_and_install_update(self, url):
        """Scarica e installa aggiornamento"""
        progress_win = tk.Toplevel(self.root)
        progress_win.title("Scaricamento aggiornamento")
        progress_win.geometry("400x100")
        progress_win.configure(bg=BG)
        progress_win.resizable(False, False)

        tk.Label(progress_win, text="Scaricamento in corso...", bg=BG, fg=WHITE,
                 font=("Segoe UI", 10)).pack(pady=10)

        progress_var = tk.IntVar()
        progress_bar = ttk.Progressbar(progress_win, variable=progress_var, maximum=100)
        progress_bar.pack(fill="x", padx=20, pady=10)

        def download_thread():
            def update_progress(percent):
                progress_var.set(percent)

            temp_file = download_update(url, update_progress)

            if temp_file:
                self.root.after(0, lambda: self.install_update(temp_file, progress_win))
            else:
                self.root.after(0, lambda: messagebox.showerror(
                    "Errore", "Impossibile scaricare l'aggiornamento"))
                progress_win.destroy()

        threading.Thread(target=download_thread, daemon=True).start()

    def install_update(self, update_file, progress_win):
        """Installa aggiornamento e riavvia"""
        progress_win.destroy()
        response = messagebox.askyesno(
            "Installazione",
            "Aggiornamento scaricato. Installare ora?\n"
            "L'applicazione verrà chiusa e riavviata.",
            icon='question'
        )
        if response:
            subprocess.Popen([update_file])
            self.close()

    def update_threshold_label(self, val):
        self.threshold_label.config(text=str(int(float(val))))
        if self.sender.running:
            self.sender.threshold = int(float(val))
            self.sender.send_settings()

    def update_delay_label(self, val):
        self.delay_label.config(text=f"{int(float(val))} s")
        if self.sender.running:
            self.sender.delay_sec = int(float(val))
            self.sender.send_settings()

    def work_area(self):
        """Area schermo disponibile"""
        try:
            r = ctypes.wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)
            return r.left, r.top, r.right - r.left, r.bottom - r.top
        except Exception:
            return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight() - self.S(60)

    def fit(self):
        """Adatta dimensioni finestra"""
        r = self.root
        self.card.config(height=self.card.inner.winfo_reqheight() + 2 * self.card.pad)
        r.update_idletasks()
        x0, y0, aw, ah = self.work_area()
        avail = ah - self.S(40)
        if r.winfo_reqheight() > avail and not self.compact:
            self.compact = True
            self.head.pack_forget()
            self.input_lbl.pack_forget()
            self.card.config(height=self.card.inner.winfo_reqheight() + 2 * self.card.pad)
            r.update_idletasks()
        w = self.S(500)
        h = min(r.winfo_reqheight(), avail)
        x = x0 + max(0, (aw - w) // 2)
        y = y0 + max(0, (ah - h) // 2 - self.S(20))
        r.geometry(f"{w}x{h}+{x}+{y}")

    def refresh_devices(self):
        if pyaudio is None:
            return
        keep = self.combo.get() or self.cfg.get("device")
        p = pyaudio.PyAudio()
        try:
            self.devices, default_idx = list_devices(p)
        finally:
            p.terminate()
        names = [d[0] for d in self.devices]
        self.combo["values"] = names
        if keep in names:
            self.combo.current(names.index(keep))
        elif names:
            self.combo.current(default_idx)
        else:
            self.combo.set("")

    def set_locked(self, locked):
        self.ip_entry.config(state="disabled" if locked else "normal")
        self.refresh_btn.set_enabled(not locked)
        self.combo.config(state="disabled" if locked else "readonly")
        self.auto_btn.set_enabled(not locked)

    def toggle(self):
        if self.sender.running:
            self.sender.stop()
            self.set_locked(False)
            self.btn.configure_button(text="Avvia invio", fill=ORANGE)
            self.notice = None
            return

        text = self.ip_var.get().strip()
        if not text:
            self.notice = ("Inserisci l'IP del tablet o usa 'Auto'", ORANGE)
            return

        ip = resolve_host(text)
        if ip is None:
            self.notice = (f"Indirizzo non valido: {text}", RED)
            return

        sel = self.combo.current()
        if sel < 0:
            self.notice = ("Nessun dispositivo audio", ORANGE)
            return

        try:
            threshold = self.threshold_var.get()
            delay_sec = self.delay_var.get()
            self.sender.start(self.devices[sel][1], ip, threshold, delay_sec)
        except Exception as e:
            self.sender.stop()
            self.notice = (f"Errore: {e}", RED)
            return

        self.notice = None
        self.cfg.update({
            "ip": text,
            "device": self.devices[sel][0],
            "threshold": threshold,
            "delay_sec": delay_sec
        })
        self.cfg["autostart"] = bool(self.autostart_var.get())
        save_config(self.cfg)
        self.set_locked(True)
        self.btn.configure_button(text="Ferma invio", fill=TRACK, fg=WHITE)

    def tick(self):
        s = self.sender
        if s.running:
            self.bar.set_level(s.level)
            if s.error:
                color, icon, text, fg = RED, "alert", f"Errore rete: {s.error}", RED
            elif s.audio_msg:
                color, icon, text, fg = ORANGE, "alert", s.audio_msg, ORANGE
            elif s.level > s.threshold:
                color, icon, text, fg = ORANGE, "pause", f"Audio rilevato (livello {s.level}): video in pausa", WHITE
            else:
                color, icon, text, fg = GREEN, "play", "Silenzio: video attivo", WHITE
            label = self.combo.get()
            inp = "Ingresso: " + (label if len(label) <= 58 else label[:55] + "...")
        else:
            self.bar.set_level(0)
            color, icon, inp = GREY, "play", "Ingresso: -"
            if self.notice:
                text, fg = self.notice
            else:
                text, fg = "Fermo", WHITE

        self.circle.set(color, icon)
        if self.status.cget("text") != text or self.status.cget("fg") != fg:
            self.status.config(text=text, fg=fg)
        if self.input_lbl.cget("text") != inp:
            self.input_lbl.config(text=inp)

        self.root.after(80, self.tick)

    def close(self):
        self.cfg["autostart"] = bool(self.autostart_var.get())
        self.cfg["threshold"] = self.threshold_var.get()
        self.cfg["delay_sec"] = self.delay_var.get()
        save_config(self.cfg)
        self.sender.stop()
        self.control_receiver.stop()
        self.root.destroy()


if __name__ == "__main__":
    enable_dpi_awareness()
    root = tk.Tk()
    App(root)
    root.mainloop()
