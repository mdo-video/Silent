/*
 * MODIFICHE PER ListenService.kt
 *
 * Aggiungi queste modifiche al file ListenService.kt per abilitare:
 * - Invio periodico dell'IP al PC (auto-riconoscimento)
 * - Ricezione parametri dal PC (soglia, ritardo)
 * - Sistema OTA per aggiornamenti Android
 */

// ========== AGGIUNTE IN CIMA AL FILE ==========

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import org.json.JSONObject
import android.os.Handler
import android.os.Looper

// ========== AGGIUNTE NELLA CLASSE ListenService ==========

class ListenService : Service() {

    companion object {
        const val PC_PORT = 5005
        const val CONTROL_PORT = 5006  // NUOVO: Porta controllo bidirezionale
    }

    // NUOVO: Socket per comunicazione controllo
    private var controlSocket: DatagramSocket? = null
    private var controlThread: Thread? = null
    private var announceHandler: Handler? = null
    private var pcAddress: InetAddress? = null

    // NUOVO: Parametri ricevuti dal PC
    private var pcThreshold: Int? = null
    private var pcDelay: Int? = null

    // ========== MODIFICA onCreate() ==========

    override fun onCreate() {
        super.onCreate()
        // ... codice esistente ...

        // NUOVO: Avvia comunicazione controllo
        startControlCommunication()
    }

    // ========== NUOVE FUNZIONI DA AGGIUNGERE ==========

    private fun startControlCommunication() {
        try {
            controlSocket = DatagramSocket(CONTROL_PORT)
            announceHandler = Handler(Looper.getMainLooper())

            // Thread per ricevere comandi dal PC
            controlThread = Thread {
                val buffer = ByteArray(1024)
                while (!Thread.currentThread().isInterrupted) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        controlSocket?.receive(packet)

                        val message = String(packet.data, 0, packet.length)
                        pcAddress = packet.address

                        handleControlMessage(message)
                    } catch (e: Exception) {
                        if (!Thread.currentThread().isInterrupted) {
                            Log.e(TAG, "Errore ricezione controllo", e)
                        }
                    }
                }
            }
            controlThread?.start()

            // Annuncia IP al PC ogni 5 secondi
            startAnnouncing()

        } catch (e: Exception) {
            Log.e(TAG, "Errore avvio comunicazione controllo", e)
        }
    }

    private fun startAnnouncing() {
        val announceRunnable = object : Runnable {
            override fun run() {
                announceToPC()
                announceHandler?.postDelayed(this, 5000) // Ogni 5 secondi
            }
        }
        announceHandler?.post(announceRunnable)
    }

    private fun announceToPC() {
        try {
            val json = JSONObject().apply {
                put("type", "announce")
                put("ip", getLocalIpAddress())
                put("version", BuildConfig.VERSION_NAME)
                put("device", android.os.Build.MODEL)
            }

            val message = json.toString().toByteArray()

            // Broadcast sulla rete locale
            val broadcastAddress = InetAddress.getByName("255.255.255.255")
            val packet = DatagramPacket(
                message,
                message.size,
                broadcastAddress,
                CONTROL_PORT
            )

            controlSocket?.broadcast = true
            controlSocket?.send(packet)

        } catch (e: Exception) {
            Log.e(TAG, "Errore annuncio IP", e)
        }
    }

    private fun handleControlMessage(message: String) {
        try {
            val json = JSONObject(message)
            val type = json.optString("type")

            when (type) {
                "settings" -> {
                    // Ricevi parametri dal PC
                    pcThreshold = json.optInt("threshold", -1).takeIf { it != -1 }
                    pcDelay = json.optInt("delay", -1).takeIf { it != -1 }

                    // Applica i parametri ricevuti
                    pcThreshold?.let { prefs.threshold = it }
                    pcDelay?.let { prefs.delaySec = it }

                    Log.d(TAG, "Parametri ricevuti dal PC: soglia=$pcThreshold, ritardo=$pcDelay")
                }

                "ping" -> {
                    // Rispondi al ping del PC
                    sendPong()
                }

                "update_check" -> {
                    // Il PC chiede di verificare aggiornamenti
                    checkForUpdates()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore parsing messaggio controllo", e)
        }
    }

    private fun sendPong() {
        try {
            pcAddress?.let { address ->
                val json = JSONObject().apply {
                    put("type", "pong")
                    put("status", if (SilentState.running) "running" else "stopped")
                    put("level", SilentState.level)
                    put("threshold", SilentState.effectiveThreshold)
                }

                val message = json.toString().toByteArray()
                val packet = DatagramPacket(message, message.size, address, CONTROL_PORT)
                controlSocket?.send(packet)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore invio pong", e)
        }
    }

    private fun sendSettingsRequest() {
        try {
            pcAddress?.let { address ->
                val json = JSONObject().apply {
                    put("type", "settings_request")
                }

                val message = json.toString().toByteArray()
                val packet = DatagramPacket(message, message.size, address, CONTROL_PORT)
                controlSocket?.send(packet)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore richiesta settings", e)
        }
    }

    private fun checkForUpdates() {
        // TODO: Implementa controllo aggiornamenti
        // Puoi usare Google Play In-App Updates o un server custom
        Thread {
            try {
                // Esempio: controlla versione su server
                val url = URL("https://your-server.com/silent/version.json")
                val connection = url.openConnection()
                val response = connection.getInputStream().bufferedReader().readText()
                val json = JSONObject(response)

                val latestVersion = json.getString("version")
                val currentVersion = BuildConfig.VERSION_NAME

                if (isNewerVersion(latestVersion, currentVersion)) {
                    // Notifica utente
                    showUpdateNotification(json)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Errore controllo aggiornamenti", e)
            }
        }.start()
    }

    private fun isNewerVersion(latest: String, current: String): Boolean {
        val latestParts = latest.split(".").map { it.toIntOrNull() ?: 0 }
        val currentParts = current.split(".").map { it.toIntOrNull() ?: 0 }

        for (i in 0 until maxOf(latestParts.size, currentParts.size)) {
            val l = latestParts.getOrNull(i) ?: 0
            val c = currentParts.getOrNull(i) ?: 0
            if (l > c) return true
            if (l < c) return false
        }
        return false
    }

    private fun showUpdateNotification(updateInfo: JSONObject) {
        // Crea notifica per aggiornamento disponibile
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(updateInfo.getString("download_url"))
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("Aggiornamento disponibile")
            .setContentText("Silent ${updateInfo.getString("version")} è disponibile")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText(updateInfo.optString("notes", "Nuova versione disponibile")))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(999, notification)
    }

    private fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val ni = interfaces.nextElement()
                if (!ni.isUp || ni.isLoopback) continue

                val addresses = ni.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is Inet4Address && addr.isSiteLocalAddress) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Errore get IP", e)
        }
        return "unknown"
    }

    // ========== MODIFICA onDestroy() ==========

    override fun onDestroy() {
        // NUOVO: Ferma comunicazione controllo
        announceHandler?.removeCallbacksAndMessages(null)
        controlThread?.interrupt()
        controlSocket?.close()

        // ... resto del codice esistente ...
        super.onDestroy()
    }
}

/*
 * ========== MODIFICHE AGGIUNTIVE ==========
 *
 * 1. In build.gradle (Module: app) aggiungi:
 *    android {
 *        defaultConfig {
 *            versionCode 2
 *            versionName "2.0.0"
 *        }
 *    }
 *
 * 2. In AndroidManifest.xml verifica permessi:
 *    <uses-permission android:name="android.permission.INTERNET" />
 *    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
 *    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
 *
 * 3. Per OTA via Google Play, usa:
 *    implementation 'com.google.android.play:app-update:2.1.0'
 *    implementation 'com.google.android.play:app-update-ktx:2.1.0'
 *
 * 4. In MainActivity.kt, nella funzione applySourceUi(), modifica:
 *    if (pc) {
 *        pcInfo.text = "Nell'app Windows:\n" +
 *                     "1. Clicca 'Auto' per rilevare automaticamente\n" +
 *                     "2. Oppure inserisci: ${localIp()} (porta $PC_PORT)"
 *    }
 */
