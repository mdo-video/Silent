"""
README - Silent PC Sender v2.0
===============================

Sistema avanzato di controllo audio per video editing con sincronizzazione 
bidirezionale tra PC e tablet Android.

## 🆕 Novità Versione 2.0

- ✅ **Controllo parametri dal PC**: Gestisci soglia audio e ritardo direttamente dall'app PC
- ✅ **Auto-riconoscimento IP**: Il PC rileva automaticamente l'IP del tablet
- ✅ **Aggiornamenti OTA**: Sistema di aggiornamento automatico per PC e Android
- ✅ **Comunicazione bidirezionale**: Sincronizzazione in tempo reale dei parametri
- ✅ **Interfaccia rinnovata**: Design moderno con dark mode completo
- ✅ **Icona integrata**: Logo Silent nell'exe e nella barra delle applicazioni

## 📋 Requisiti

### PC Windows
- Windows 10 o superiore
- Python 3.8+ (per sviluppo)
- Connessione Wi-Fi sulla stessa rete del tablet

### Tablet Android
- Android 8.0 o superiore
- App Silent installata (vedi cartella `app/`)

## 🚀 Installazione

### Opzione 1: Usa l'eseguibile precompilato
1. Scarica `Silent_PC_Sender.exe` dalla sezione Releases
2. Esegui il file - non serve installazione!
3. L'applicazione è portabile e non modifica il registro

### Opzione 2: Esegui da sorgente (sviluppatori)
```bash
# Installa le dipendenze
pip install pyaudiowpatch numpy requests

# Esegui l'applicazione
python Silent_PC.py
```

### Opzione 3: Compila tu stesso l'exe
```bash
# Installa PyInstaller
pip install pyinstaller pillow pyaudiowpatch numpy

# Compila
python build_exe.py

# L'exe sarà in dist/Silent_PC_Sender.exe
```

## 🎯 Come Usare

### Setup Iniziale

1. **Avvia l'app Android "Silent"** sul tablet
   - Vai nelle impostazioni
   - Seleziona "Sorgente audio: PC"
   - Annota l'IP mostrato (es. 192.168.1.112)

2. **Avvia Silent PC Sender** sul PC
   - L'app rileverà automaticamente il tablet se è sulla stessa rete
   - Oppure inserisci manualmente l'IP annotato
   - Clicca "Auto" per usare l'IP rilevato automaticamente

3. **Seleziona la sorgente audio**
   - "Uscita predefinita" (consigliato): segue l'audio di Windows
   - Oppure scegli un dispositivo specifico

4. **Regola i parametri** (opzionale)
   - **Soglia audio**: 0-100 (default 62)
     - Più bassa = più sensibile
     - Più alta = ignora rumori di fondo
   - **Ritardo ripartenza**: 1-60 secondi (default 25)
     - Tempo di attesa dopo il silenzio prima di far ripartire il video

5. **Clicca "Avvia invio"**
   - Il cerchio diventa verde = silenzio, video attivo
   - Il cerchio diventa arancione = audio rilevato, video in pausa

### Funzionalità Avanzate

#### Auto-riconoscimento IP
- Il tablet invia periodicamente il suo IP al PC
- Il PC lo rileva automaticamente
- Clicca "Auto" per usarlo
- Nessuna configurazione manuale necessaria

#### Sincronizzazione parametri
- I parametri impostati sul PC vengono inviati al tablet
- Il tablet usa questi valori per il controllo del video
- Cambio in tempo reale senza riavviare

#### Aggiornamenti automatici
- All'avvio il PC controlla se ci sono aggiornamenti
- Notifica se disponibile una nuova versione
- Download e installazione con un click

## 🔧 Configurazione Avanzata

### File di configurazione
L'app salva le impostazioni in:
```
%USERPROFILE%\.silent_pc_sender.json
```

Contenuto esempio:
```json
{
  "ip": "192.168.1.112",
  "device": "Audio del PC - uscita predefinita",
  "threshold": 62,
  "delay_sec": 25,
  "autostart": false
}
```

### Avvio automatico
Spunta "Avvia l'invio all'apertura" per far partire automaticamente 
l'invio audio quando apri l'applicazione.

### Porte di rete utilizzate
- **5005 (UDP)**: Invio stream audio PC → Tablet
- **5006 (UDP)**: Comunicazione controllo bidirezionale

## 🐛 Risoluzione Problemi

### Il tablet non viene rilevato automaticamente
- Verifica che PC e tablet siano sulla stessa rete Wi-Fi
- Controlla che il firewall non blocchi le porte 5005 e 5006
- Prova a inserire l'IP manualmente

### Audio non arriva al tablet
- Verifica l'IP sia corretto
- Controlla che Windows stia riproducendo audio
- Prova a cambiare la sorgente audio

### Errore "Manca pyaudiowpatch"
Se usi la versione Python:
```bash
pip install pyaudiowpatch numpy
```
L'exe include già tutte le dipendenze.

### Il video non si ferma/riparte
- Verifica che l'app Android abbia i permessi necessari
- Controlla che ci sia un'app di riproduzione video attiva
- Regola la soglia audio se è troppo sensibile/insensibile

## 🏗️ Sviluppo

### Struttura Progetto
```
Silent_NEW/
├── Silent_PC.py          # Applicazione principale
├── build_exe.py          # Script per compilare exe
├── version.json          # Info versione per OTA
├── README.md            # Questo file
└── requirements.txt     # Dipendenze Python
```

### Compilare l'exe
```bash
python build_exe.py
```

L'icona viene generata automaticamente dal codice e integrata nell'exe.

### Testare localmente
```bash
# Modalità sviluppo con reload automatico
python Silent_PC.py
```

### Pubblicare aggiornamenti
1. Modifica `VERSION` in `Silent_PC.py`
2. Aggiorna `version.json` con le note di rilascio
3. Compila: `python build_exe.py`
4. Carica l'exe su GitHub Releases
5. Aggiorna l'URL in `version.json`
6. Committa `version.json` su GitHub

## 📱 Integrazione Android

L'app Android è stata aggiornata per:
- Inviare periodicamente il proprio IP al PC
- Ricevere parametri (soglia, ritardo) dal PC
- Applicare i parametri in tempo reale
- Gestire aggiornamenti OTA

Vedi `app/src/main/java/com/mdovideo/silent/` per i dettagli.

## 🔄 Sistema OTA

### PC → Verifica aggiornamenti
1. All'avvio controlla `UPDATE_URL`
2. Confronta versione corrente con quella online
3. Se disponibile, mostra dialog di download
4. Scarica exe, chiede conferma, installa e riavvia

### Android → Verifica aggiornamenti
1. Controlla Google Play o server custom
2. Notifica utente se disponibile
3. Download e installazione APK

### Configurazione URL
Modifica in `Silent_PC.py`:
```python
UPDATE_URL = "https://raw.githubusercontent.com/YOUR_REPO/Silent/main/version.json"
```

## 📄 Licenza

© 2026 MDO Video  
Uso personale e commerciale consentito.

## 🤝 Contribuire

Pull requests benvenute! Per cambiamenti importanti, apri prima una issue.

## 📞 Supporto

- Issues: https://github.com/YOUR_REPO/Silent/issues
- Email: support@mdovideo.com

## 🎉 Ringraziamenti

- pyaudiowpatch per la cattura audio WASAPI
- Tkinter per l'interfaccia grafica
- Comunità open source

---

Made with ❤️ for video editors
